#include <stdio.h>
#include <stdint.h>
#include <unistd.h>
#include <stdlib.h>
static FILE *logfile;
static uintptr_t caller;
static int depth;
void ap_begin(uint32_t unit){char file[512];snprintf(file,sizeof file,"%s/why-%d-%u",getenv("BLOT_SHAPES_DIR"),getpid(),unit);logfile=fopen(file,"wb");if(!logfile)abort();}
void ap_end(void){if(depth)abort();fclose(logfile);logfile=NULL;}
void ap_enter(void){if(logfile && !depth++)caller=(uintptr_t)__builtin_return_address(1);}
void ap_leave(void){if(logfile)depth--;}
void ap_why(_Bool a,_Bool b,_Bool c,_Bool same,_Bool tail,_Bool time,_Bool empty){if(depth){uint32_t x[2]={caller,a|b<<1|c<<2|same<<3|tail<<4|time<<5|empty<<6};fwrite(x,sizeof(x),1,logfile);}}
