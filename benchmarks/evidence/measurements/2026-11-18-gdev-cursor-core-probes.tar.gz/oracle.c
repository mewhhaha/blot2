#include <stdint.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <stdlib.h>
void blot_profile_final(uint32_t unit,_Bool usage,_Bool scoped,_Bool editor,int64_t cases,int64_t uses,int64_t refs,int64_t holes,const uint32_t* counts){
const char *path=getenv("BLOT_CURSOR_LOG");if(!path)abort();int fd=open(path,O_WRONLY|O_APPEND|O_CREAT,0600);char buf[512]; int n=snprintf(buf,sizeof buf,"%u %d %d %d %ld %ld %ld %ld",unit,usage,scoped,editor,cases,uses,refs,holes);for(int i=0;i<8;i++)n+=snprintf(buf+n,sizeof(buf)-n," %u",counts[i]);buf[n++]='\n';if(write(fd,buf,n)!=n)abort();close(fd);}
