import os;
import reuse.parse_packet;
import parse.ast;
import parse.lexer;
import parse.parser;
import parse.token;
import parse.symbols;
import support.error;
fn common(pool:blot_parse_symbols::Pool&) {
    pool.intern("seed only"); pool.intern("+"); pool.intern("value");
}
fn shifted(pool:blot_parse_symbols::Pool&) {
    pool.intern("previous"); pool.intern("x"); pool.intern("-"); pool.intern("later"); pool.intern("Main");
}
fn equal(a:const blot_parse_ast::Tree&, b:const blot_parse_ast::Tree&) -> bool {
    return a.nodes.items==b.nodes.items && a.spans.items==b.spans.items && a.extra.items==b.extra.items &&
        a.roots.items==b.roots.items && a.runtime_names.items==b.runtime_names.items && a.constant_names.items==b.constant_names.items &&
        a.declaration_traits.items==b.declaration_traits.items && a.declaration_nodes.items==b.declaration_nodes.items &&
        a.operator_origins.items==b.operator_origins.items && a.type_conversion_origins.items==b.type_conversion_origins.items &&
        a.diagnostics.items==b.diagnostics.items && a.has_typed_staging==b.has_typed_staging && a.has_numeric_proofs==b.has_numeric_proofs;
}
fn check(path: const u8[:], seed: const blot_parse_symbols::Pool&) -> bool {
    var source:u8[>..]=[];
    assert(read_file(path,source));
    var expected,p1=blot_parse_symbols::initPooled();
    var actual,p2=blot_parse_symbols::initPooled();
    common(expected); common(actual); shifted(expected); shifted(actual);
    var tree,te=blot_parse_ast::initPooled();
    var tokens:blot_parse_token::Token[>..<]=[];var comments:blot_parse_token::Token[>..<]=[];var diagnostics:blot_parse_lexer::Diagnostic[>..<]=[];
    var lexed=blot_parse_lexer::init(tokens,comments,diagnostics);
    let le=blot_parse_lexer::lex(source,lexed);
    var valid=le==blot_error::Error.none && diagnostics.len==0;
    let fixities:blot_parse_parser::InheritedFixity[1]=[blot_parse_parser::InheritedFixity{operator:2,precedence:55,association:0,named:false,..}];
    if valid {let pe=blot_parse_parser::parse_with_fixities(source,tokens,expected,tree,fixities); valid=pe==blot_error::Error.none && tree.diagnostics.len==0;}
    var result=blot_parse_ast::Tree{};
    var packet:u8[>..<]=[];
    let encoded=blot_reuse_parse_packet::encode(source,seed,fixities,packet);
    if valid!=encoded {print("encode disagreement ", path);exit(1);}
    if encoded {
        let decoded=blot_reuse_parse_packet::decode(packet,actual,result);
        if !decoded {print("decode ", path);exit(1);}
        if actual.entries.items!=expected.entries.items || actual.bytes.items!=expected.bytes.items {print("names ", path);exit(1);}
        if !equal(result,tree) {print("trees ", path);exit(1);}
    }
    result.deinit(); tree.deinit(); actual.deinit(); expected.deinit();
    return encoded;
}
fn main() {
    var seed,se=blot_parse_symbols::initPooled();
    common(seed);
    let paths=args();
    var accepted=0;
    for path in paths[1..] {if check(path,seed) {accepted++;}}
    print("files ",paths.len-1," matched ",accepted," parsed ",paths.len-1-accepted," fallback");
    seed.deinit();
}
