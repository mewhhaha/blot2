import { resolve } from "node:path";
import { strict as assert } from "node:assert";
import { createZigProjectCompiler } from "../../host/zig_project_client.ts";
import { gdevProject } from "../../scripts/integration/gdev_project.ts";
const [destArg, captureExe, action] = Deno.args;
const verify = action === "--verify";
function shellQuote(s: string) {
  return "'" + s.replaceAll("'", "'\"'\"'") + "'";
}
const dest = resolve(destArg);
const root = resolve("../gdev");
const file = resolve(root, "src/effects/lighting_look.blot");
const original = await Deno.readTextFile(file);
const world = resolve(root, "src/world_storage.blot");
const worldText = await Deno.readTextFile(world);
const projectRoot = resolve(root, "src/main.blot");
const mainSource = await Deno.readTextFile(projectRoot);
function edit(text: string, from: string, to: string) {
  assert.equal(text.split(from).length, 2);
  return text.replace(from, to);
}
const proposed =
  "const proposed = $Look { sun: true, fill: true, bounce: true, phase: $Nothing }";
const stageWorld = edit(
  worldText,
  "let lighting_look = #[lighting_look.proposed]",
  "let lighting_look = #[if (#run lighting_look.probe_flag) then lighting_look.proposed else lighting_look.original]",
);
function stageInputs(k: number) {
  return {
    [world]: stageWorld,
    [file]: original + "\nconst probe_flag: Bool = " + String(k === 7) + "\n",
  };
}
const cases: [string, Record<string, string>][] = [
  ["base", {}],
  ["boolean", {
    [file]: edit(
      original,
      "const proposed = $Look { sun: true,",
      "const proposed = $Look { sun: false,",
    ),
  }],
  ["integer", { [file]: edit(original, "if choice == 4:", "if choice == 9:") }],
  ["width", {
    [file]: edit(original, "if choice == 4:", "if choice == 4096:"),
  }],
  ["float", { [file]: edit(original, "$Some 0.25", "$Some 0.125") }],
  ["call", {
    [file]: edit(original, "if choice == 4:", "if (choice + 1) == 4:"),
  }],
  ["shape", {
    [file]: edit(
      original,
      "const proposed = $Look { sun: true,",
      "const proposed = $Look { sun: (2 == 2),",
    ),
  }],
  ["phase", {
    [file]: edit(
      original,
      proposed,
      proposed.replace("$Nothing", "$Some 0.125"),
    ),
  }],
  ["helper", {
    [file]: edit(
      original,
      proposed,
      proposed.replace("sun: true", "sun: (probe_flag 7)"),
    ) + "\nfunc probe_flag (x: U32): Bool => return x == 7\n",
  }],
  ["value-width", {
    [file]: edit(
      original,
      proposed,
      proposed.replace("sun: true", "sun: (4096 == 2)"),
    ),
  }],
  ["value-float", {
    [file]: edit(
      original,
      proposed,
      proposed.replace("$Nothing", "$Some 0.75"),
    ),
  }],
  ["stage-base", stageInputs(7)],
  ["stage-edit", stageInputs(8)],
  ["entry", {
    [projectRoot]: edit(
      mainSource,
      "level.start_camera",
      "(if true then level.start_camera else level.start_camera)",
    ),
  }],
];
for (const [label, sources] of cases) {
  const folder = resolve(dest, label);
  let executable = resolve(captureExe);
  if (!verify) {
    try {
      await Deno.stat(resolve(folder, "main.wasm"));
      continue;
    } catch (e) {
      if (!(e instanceof Deno.errors.NotFound)) throw e;
    }
    await Deno.mkdir(folder, { recursive: true });
    const wrapper = resolve(folder, "run");
    await Deno.writeTextFile(
      wrapper,
      "#!/bin/sh\nexport BLOT_PACKET_SAMPLES=" + shellQuote(folder) +
        "\nexec " + shellQuote(executable) + ' "$@"\n',
    );
    await Deno.chmod(wrapper, 0o755);
    executable = wrapper;
  }
  const project = await gdevProject(
    root,
    resolve("std"),
    "src/main.blot",
    executable,
  );
  const compiler = await createZigProjectCompiler(project);
  try {
    const result = await compiler.build({
      sources,
      signal: AbortSignal.timeout(30000),
    });
    assert(
      result.success,
      JSON.stringify(result.success ? undefined : result.diagnostics),
    );
    assert(WebAssembly.validate(result.bytes));
    if (verify) {
      assert.deepEqual(
        result.bytes,
        await Deno.readFile(resolve(folder, "main.wasm")),
      );
    } else await Deno.writeFile(resolve(folder, "main.wasm"), result.bytes);
    assert.equal(result.stats.freshModules, 269);
    assert.equal(result.stats.cachedModules, 0);
    console.log(
      label,
      result.bytes.length,
      result.stats.freshModules,
      result.stats.cachedModules,
    );
  } finally {
    await compiler.dispose();
  }
}
