from pathlib import Path
import json,statistics,re,hashlib
root=Path('/home/mewhhaha/src/blot2');b=root/'build/bench/ct109'
read=lambda p:json.loads(p.read_text())
pairs=read(b/'final-pairs/pair-ranges.json');assert pairs['success']
gate=read(b/'qualification-work/blot2/build/bench/ct109-final-gate-3/timings.json');assert gate['success'] and not gate['active']
native=read(b/'qualification-work/blot2/build/bench/ct109-final-gate-3/native-execution/results.json');assert native['success'] and native['allocation_failures']=='full' and len(native['inventory'])==2573
for name,digest in read(b/'final-pins.json')['qualified_files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
print('GATE',gate['wall_seconds'],[(p['name'],round(p['wall_seconds'],2)) for p in gate['phases']])
print('NATIVE',native['wall_seconds'],len(native['inventory']) if isinstance(native['inventory'],list) else native['inventory'])
print('HOST',pairs['host'])
for row in pairs['rows']:
 if row['phase']=='fresh' or row['phase'].startswith(('edit:','revert:')):
  print(row['workload'],row['phase'],'wall',*[round(row[v]['wall_ms']['median']/1000,3) for v in ['baseline','candidate']],'cpu',*[round(row[v]['cpu_ms']['median']/1000,3) for v in ['baseline','candidate']],'paired',round(100*(row['paired_cpu_ratio']-1),2),'HWM MiB',*[round(row[v]['peak_rss_kib']['median']/1024,2) for v in ['baseline','candidate']])
complete=read(b/'memory-final/complete.json');assert complete['success']
samples=[json.loads(x) for x in (b/'memory-final/samples.jsonl').read_text().splitlines()]
rows=[]
for r in [1,10,40,100,150,200]:
 row=next(s for s in samples if s['kind']=='unseen_literal' and s['revision']==r)
 rows.append({'revision':r,**row['after']})
summary={'complete':complete,'samples':len(samples),'checkpoints':rows,'minimum_post_edit_rss_mib':min(s['after']['rss_kib']/1024 for s in samples if s['kind']=='unseen_literal'),'maximum_post_edit_rss_mib':max(s['after']['rss_kib']/1024 for s in samples if s['kind']=='unseen_literal'),'maximum_hwm_mib':max(s['after']['peak_rss_kib']/1024 for s in samples)}
(b/'memory-final/summary.json').write_text(json.dumps(summary,indent=2)+'\n')
print('MEMORY',json.dumps(summary,indent=2));print('EXECUTION',{k:v for k,v in read(b/'review-execution.json').items() if k!='results'})
for f in (b/'qualification-work/blot2/build/bench/ct109-final-gate-3').glob('run-*/*.stdout.log'):
 hits=re.findall(r'ok \| [0-9]+ passed \| [0-9]+ failed[^\n]*',f.read_text(errors='replace'))
 if hits:print(f.name,hits)
