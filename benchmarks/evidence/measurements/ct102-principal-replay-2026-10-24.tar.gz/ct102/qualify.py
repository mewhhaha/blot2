import pathlib,subprocess,time,json,os,hashlib,statistics
root=pathlib.Path('/home/mewhhaha/src/blot2');out=root/'build/bench/ct102';src=out/'candidate-src';work=root/'build/bench/compile-cost-20261023'
baseline=root/'build/bench/ct97/final-src/zig-native/zig-out/bin/blotc';candidate=src/'zig-native/zig-out/bin/blotc'
assert subprocess.check_output(['zig','version'],text=True).strip()=='0.17.0'
env=dict(os.environ,ZIG_ANALYZER=str(root/'build/tools/zig-analyzer/zig-analyzer-0.17.0-3-x86_64-linux/bin/zig-analyzer'))
files=['zig-native/src/reuse/principal_evidence_reuse.zig','zig-native/src/reuse/principal_input_tests.zig','zig-native/tests/principal_replay_execution.test.ts','scripts/dev_check_areas.ts']
(src/files[2]).write_bytes((root/files[2]).read_bytes())
(src/'zig-native/CONTRACT.md').write_bytes((root/'zig-native/CONTRACT.md').read_bytes())
(out/'final-inputs.json').write_text(json.dumps({'base':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'files':{f:hashlib.sha256((src/f).read_bytes()).hexdigest() for f in files}},indent=2)+'\n')
common=['deno','task','bench:compile','--baseline',str(baseline),'--candidate',str(candidate),'--snapshot',str(work/'snapshot'),'--manifest',str(work/'manifest.json'),'--hashes',str(work/'wasm.json')]
commands=[('release',['deno','task','build:compiler']),('cold',common+['--workload','game,devtools','--runs','7','--no-retained','--guard-cpu','--out',str(out/'cold')]),('retained',common+['--workload','game','--runs','7','--scenarios','trivia,literal_in_body,body_change','--restart-cache','--out',str(out/'retained')]),('phases',common+['--workload','game','--runs','1','--scenarios','literal_in_body,body_change','--profile','--out',str(out/'phases')]),('gate',['deno','task','test:compiler','--native-shards','4','--phase-seconds','900','--budget-seconds','1200','--timings-dir',str(out/'gate')])]
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
status=[]
for name,cmd in commands:
 if name=='gate':
  samples=[json.loads(l) for l in (out/'retained/samples.jsonl').read_text().splitlines()]
  checks={}
  for phase,limit in [('edit:literal_in_body',.90),('edit:body_change',1.05)]:
   d={(s['run'],s['variant']):s['cpu_ms'] for s in samples if s['kind']=='retained' and s['phase']==phase}
   ratios=[d[i,'candidate']/d[i,'baseline'] for i in range(1,8)] if (1,'candidate') in d and (7,'candidate') in d else [d[i,'candidate']/d[i,'baseline'] for i in range(7)]
   checks[phase]={'ratios':ratios,'median':statistics.median(ratios),'limit':limit}
  (out/'acceptance.json').write_text(json.dumps(checks,indent=2)+'\n');print('ACCEPTANCE',json.dumps(checks),flush=True)
  if any(v['median']>v['limit'] for v in checks.values()):raise SystemExit('CPU acceptance missed; review before qualification')
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:p=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start};status.append(row)
 (out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(row),flush=True)
 if p.returncode:raise SystemExit(p.returncode)
 if name=='release':(out/'binaries.json').write_text(json.dumps({k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in [('baseline',baseline),('candidate',candidate)]},indent=2)+'\n')
