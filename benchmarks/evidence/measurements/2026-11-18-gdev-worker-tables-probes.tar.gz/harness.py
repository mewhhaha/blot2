from pathlib import Path
import re,shutil,json,gzip,subprocess,sys,os
d=Path('build/core-packets').resolve();src=Path('compiler-goose/src').resolve();stage=sys.argv[1];at=d/stage;out=at/'src';out.mkdir(parents=True,exist_ok=True)
for p in src.iterdir():
 if p.name not in ['support','main.goose'] and not (out/p.name).exists():(out/p.name).symlink_to(p)
ss=out/'support';ss.mkdir(exist_ok=True)
for p in (src/'support').iterdir():
 if p.name not in ['project_packet.goose','project_packet_codecs.goose'] and not (ss/p.name).exists():(ss/p.name).symlink_to(p)
for n in ('project_packet.goose','project_packet_codecs.goose'):(ss/n).write_bytes((src/'support'/n).read_bytes())
if stage in ('audit-old','arrays','fields'):
 for n in ('project_packet.goose','project_packet_codecs.goose'):
  (ss/n).write_bytes(subprocess.check_output(['git','show','4aa525c1:compiler-goose/src/support/'+n]))
code=ss/'project_packet_codecs.goose';s=code.read_text();labels=[]
if stage=='fields':
 lines=[]
 for line in s.splitlines():
  m=re.match(r'fn (put|get)<[^>]+>\(receiver:[^,]+,value:(blot_check_core::Module|blot_reuse_principal_interface::Interface|blot_check_core::Types|blot_check_frozen_types::Graph|blot_check_core::EffectRows)&?\)',line)
  if m:
   op,typ=m.groups()
   def instrument(hit):
    f=hit[1];i=len(labels);labels.append([op,typ.split('::')[1],f]);offset='receiver.at' if op=='get' else 'receiver.output.len'
    return '{let t=blot_native::clock_ns();let pos='+offset+';'+hit[0]+'traceField('+str(i)+' as u32,'+offset+'-pos,blot_native::clock_ns()-t);}'
   line=re.sub(op+r'\(receiver,value\.(\w+)\);',instrument,line)
  lines.append(line)
 code.write_text('\n'.join(lines)+'\nextern fn traceField(k:u32,size:i64,ns:u64)="cp_hit";\n')
 (at/'labels.json').write_text(json.dumps(labels))
main=(d/'replay.goose').read_text()
if stage.startswith('audit-'):
 main='import reuse.dependency_format;\nextern fn verifyEnabled()->bool="cp_verify";\nextern fn saveImage(unit:u32,kind:u32,b:const u8&,n:i64)="cp_save";\n'+main
 main=main.replace('    inspect(value);','''    if verifyEnabled() {
        let portable,e=blot_reuse_dependency_format::encode(default<blot_reuse_dependency_format::Key>(),value);
        assert(e==blot_error::Error.none && portable.len>0);
        saveImage(unit,kind,portable[0],portable.len);
        blot_reuse_dependency_format::release(portable);
    }''')
if stage not in ('fields','baseline','audit-old','audit-new'):
 exec((d/'variants.py').read_text())
(out/'main.goose').write_text(main)
ref=json.load(gzip.open(os.environ['BLOT_ENGINE_RECEIPT']))['evidence']
with (at/'build.log').open('w') as f:
 for st in ref['stages']:
  if st['stage'] not in ('packet_list emit','packet_list link'):continue
  cmd=[a if a!='-O0' else '-O2' for a in st['command']]
  if st['stage'].endswith('emit'):cmd[cmd.index('-o')+1]=str(at/'program.c');cmd[-1]=str(out/'main.goose')
  else:cmd[cmd.index(next(a for a in cmd if a.endswith('/program.c')))]=str(at/'program.c');cmd[cmd.index('-o')+1]=str(at/'run');cmd.insert(-2,str(d/'io.c'))
  subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT,check=True,timeout=110)
if stage.startswith('audit-'):sys.exit(0)
with (at/'run.log').open('w') as f:subprocess.run([at/'run'],env=dict(os.environ,BLOT_PACKET_SAMPLES=str(d/'input')),stdout=f,stderr=subprocess.STDOUT,timeout=90,check=True)
