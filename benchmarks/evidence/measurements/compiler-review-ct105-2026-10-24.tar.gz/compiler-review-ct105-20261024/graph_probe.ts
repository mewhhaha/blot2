import { createZigProjectCompiler } from '../../../compiler/zig_project_client.ts';
import { gdevWorkloads, sessionOptions, editedSources } from '../../../scripts/bench/gdev.ts';
const root='/home/mewhhaha/src/blot2';
const out=`${root}/build/bench/compiler-review-ct105-20261024`;
const [w]=await gdevWorkloads(root,`${root}/build/bench/compile-cost-20261023/snapshot`);
const compiler=await createZigProjectCompiler({...sessionOptions(`${out}/stacks-fresh/blotc-ptracer`,w),cacheDirectory:false,codegenWorkers:4,profileBackend:true});
let debuggerProcess:Deno.ChildProcess|undefined;
try {
 const population=await compiler.build({sources:{}});
 if(!population.success)throw Error('Population failed');
 debuggerProcess=new Deno.Command('gdb',{args:['-batch','-q','-x',`${out}/graph_probe.py`],env:{PROBE_OUT:out,PROBE_BINARY:'/home/mewhhaha/.local/bin/blotc',PROBE_PID:String(compiler.pid)},stdout:'piped',stderr:'piped'}).spawn();
 const log=debuggerProcess.output().then(async r=>{await Deno.writeFile(`${out}/graph-probe-gdb.log`,new Uint8Array([...r.stdout,...r.stderr]));return r;});
 let attached=false;
 for(let i=0;i<3000;i++) {try {await Deno.stat(`${out}/probe-attached`);attached=true;break;}catch(e){if(!(e instanceof Deno.errors.NotFound))throw e;}await new Promise(r=>setTimeout(r,10));}
 if(!attached)throw Error('Debugger attach timeout');
 const r=await compiler.build({sources:await editedSources(w,w.scenarios.find(s=>s.name==='literal_in_body')!)});
 await Deno.writeTextFile(`${out}/probe-stop`,'1');
 await new Deno.Command('kill',{args:['-USR1',String(compiler.pid)]}).output();
 const status=await log;
 if(!status.success||!r.success)throw Error('Probe failed');
 const sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',r.bytes)),v=>v.toString(16).padStart(2,'0')).join('');
 if(sha!=='fed3453daf266d8f2c489e466f62e7b1c6b0a4767af86227ab9ead045f4da52d')throw Error('Output changed');
 await Deno.writeTextFile(`${out}/graph-probe-result.json`,JSON.stringify({success:true,wasm_sha256:sha,stats:r.stats}));
} finally {try{debuggerProcess?.kill('SIGTERM');}catch{} await compiler.dispose();}
