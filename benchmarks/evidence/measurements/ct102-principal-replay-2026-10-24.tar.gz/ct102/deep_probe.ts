import {createZigProjectCompiler} from './trace-src/compiler/zig_project_client.ts';
const dir=await Deno.makeTempDir({prefix:'blot-principal-depth-'});const entry=dir+'/main.blot';
const source=(value:number)=>`const wrap = fn value => (value, 0)
const ignore = fn value => 1
entry const answer: U32 where { type_rep U32 } = do:
  let seed = ${value}
  let layer_0 = wrap seed
${Array.from({length:130},(_,i)=>`  let layer_${i+1} = wrap layer_${i}`).join('\n')}
  break @u32.div 8 (@u32.mul seed (ignore layer_130))
`;
await Deno.writeTextFile(entry,source(2));
const c=await createZigProjectCompiler({executable:Deno.args[0],entry,prelude:null,cacheDirectory:false});
try {
 for(const value of [2,4,0,2]) {
 const r=await c.build({sources:{[entry]:source(value)}});
 console.log(JSON.stringify({...r,bytes:undefined}));
 if(r.success){const {instance}=await WebAssembly.instantiate(r.bytes);const a=instance.exports.answer;console.log('ANSWER',typeof a==='function'?a():a instanceof WebAssembly.Global?a.value:a);}
 }
}finally{await c.dispose();await Deno.remove(dir,{recursive:true});}
