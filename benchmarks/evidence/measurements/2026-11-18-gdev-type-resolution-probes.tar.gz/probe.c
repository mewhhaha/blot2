#include <stdint.h>
#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>
/* Exact keys within one checked module. A growing flat table retains the
   first visit for each stage, separately with and without depth. */
typedef struct { uint64_t owner,types,effects,physical,limit; uint32_t root,at,clock,depth,stage,generation; } Key;
typedef struct { uint64_t hash; Key key; } Slot;
static Slot *slots;
static size_t cap,used;
static uint64_t counts[3][6][6];
static int active;
static uint64_t mix(uint64_t x) { x ^= x>>30; x *= UINT64_C(0xbf58476d1ce4e5b9); x ^= x>>27; x*=UINT64_C(0x94d049bb133111eb); return x^(x>>31); }
static size_t find(Slot *s,size_t n,uint64_t h,Key *k) {
    size_t i=h&(n-1); while(s[i].hash && (s[i].hash!=h || memcmp(k,&s[i].key,sizeof(*k)))) i=(i+1)&(n-1); return i;
}
static int seen(Key k) {
    if (!cap || used*4>=cap*3) {
        size_t nc=cap ? cap*2 : 1024; Slot *ns=calloc(nc,sizeof(*ns));if (!ns) abort();
        for(size_t i=0;i<cap;i++) if(slots[i].hash) ns[find(ns,nc,slots[i].hash,&slots[i].key)]=slots[i];
        free(slots);slots=ns;cap=nc;
    }
    uint64_t h=mix(k.owner)^mix(k.types+17)^mix(k.effects+23)^mix(k.physical+29)^mix(k.limit+31)^mix(((uint64_t)k.root<<32)|k.at)^mix(((uint64_t)k.clock<<32)|k.depth)^mix(((uint64_t)k.stage<<32)|k.generation);if(!h) h=1;
    size_t i=find(slots,cap,h,&k); if(slots[i].hash)return 1; slots[i]=(Slot){h,k};used++;return 0;
}
void rh_begin(void){active=1;memset(counts,0,sizeof counts);if(slots)memset(slots,0,cap*sizeof(*slots));used=0;}
void rh_visit(uint32_t stage,uint64_t owner,uint32_t root,uint32_t at,int64_t depth,uint64_t types,uint64_t effects,uint32_t clock,uint64_t physical,uint16_t generation,int64_t limit,_Bool is_variable,uint8_t closed,_Bool projections){
    if(!active)return;
    unsigned kind=4;
    if(root<=5)kind=0;else if(closed)kind=1;else if(is_variable)kind=2;else if(projections)kind=3;
    Key k={owner,types,effects,physical,(uint64_t)limit,root,at,clock,(uint32_t)depth,stage+1,generation};
    uint64_t *a=counts[stage][kind];a[0]++;a[1]+=seen(k);k.depth=UINT32_MAX;a[2]+=seen(k);if(depth==0)a[3]++;if(at==0)a[4]++;if(projections)a[5]++;
}
void rh_end(uint32_t unit){active=0;const char *p=getenv("BLOT_RESOLVE_TRACE");if(!p)return;int fd=open(p,O_CREAT|O_APPEND|O_WRONLY|O_CLOEXEC,0600);if(fd<0)abort();char buf[2048];int n=snprintf(buf,sizeof buf,"%u",unit);for(int i=0;i<3;i++)for(int j=0;j<5;j++)for(int k=0;k<6;k++)n+=snprintf(buf+n,sizeof(buf)-n," %llu",(unsigned long long)counts[i][j][k]);buf[n++]='\n';if(write(fd,buf,n)!=n)abort();close(fd);}
