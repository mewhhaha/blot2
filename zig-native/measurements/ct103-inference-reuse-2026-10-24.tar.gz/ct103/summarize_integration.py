from pathlib import Path
import json,hashlib,xml.etree.ElementTree as ET,re
base=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
gate=read(base/'integration-gate/timings.json');native=read(base/'integration-gate/native-execution/results.json')
assert gate['success'] and not gate['active'] and native['success'] and native['allocation_failures']=='full'
pmap={p['name']:p for p in gate['phases']};assert all(p['code']==0 for p in pmap.values())
nrun=Path(next(p for p in native['artifacts'] if p.endswith('inventory.stdout.log'))).parent
laws=[json.loads(l.split('\t',1)[1]) for p in nrun.glob('shard-*.stderr.log') for l in p.read_text().splitlines() if l.startswith('BLOT_NATIVE_TEST\t')]
assert len(laws)==len({r['name'] for r in laws}) and len(laws)==2551
assert all(r['status']=='passed' and r['allocation_failures']=='full' and not r['leaks'] and not r['logged_errors'] for r in laws)
def cases(name):
 rows=list(ET.parse(Path(pmap[name]['stdout']).parent/(name+'.junit.xml')).iter('testcase'));assert rows and all(all(c.find(k) is None for k in ['failure','error','skipped']) for c in rows);return len(rows)
qualification={'native':len(laws),'guests':cases('guests'),'smoke':cases('smoke'),'harness':int(re.findall(r'ok \| (\d+) passed \| 0 failed',Path(pmap['harness']['stdout']).read_text())[-1]),'wall_seconds':gate['wall_seconds'],'phases':{n:p['wall_seconds'] for n,p in pmap.items()},'top_native':sorted(laws,key=lambda r:r['duration_ns'],reverse=True)[:10]}
for name,h in read(base/'integration-inputs.json')['files'].items():assert sha(base/'integration-src'/name)==h,name
release=read(base/'integration-release.json');assert sha(Path(release['path']))==release['sha256']
screen=read(base/'integration-screen/results.json');assert screen['success'] and screen['inputs_unchanged'] and not screen['unexpected_problems']
result={'qualification':qualification,'source_base':read(base/'integration-inputs.json')['base'],'release':release,'screen_success':True,'screen_is_performance_claim':False,'status':read(base/'integration-status.json')}
(base/'integration-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps(result,indent=2))
