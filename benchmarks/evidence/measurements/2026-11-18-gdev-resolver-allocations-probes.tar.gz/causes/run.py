from pathlib import Path
import shutil, subprocess, json
d=Path(__file__).resolve().parent; src=d/'src'
shutil.copytree(d.parent/'probe-src',src,dirs_exist_ok=True)
p=src/'check/types.goose';s=p.read_text()
start=s.index('    let zero:u32=0;');end=s.index('    return id,',start)
s=s[:start]+s[end:]
s=s.replace('return functionWithEffects(self_, parameter, result, effect_row);\n        },\n        product','''let old=self_.effects.node(value.c); let after=self_.effects.node(effect_row);
            let identical=old.cursor==after.cursor && old.tail==after.tail && old.labels.len==0 && after.labels.len==0;
            whyFunction(parameter!=value.a,result!=value.b,effect_row!=value.c,identical,old.tail==after.tail,old.cursor!=after.cursor,old.labels.len==0 && after.labels.len==0);
            return functionWithEffects(self_, parameter, result, effect_row);
        },
        product''')
p.write_text(s+'\nextern fn whyFunction(a:bool,b:bool,c:bool,same:bool,same_tail:bool,diff_time:bool,empty:bool)="ap_why";\n')
get=lambda name:json.load(open('compiler-goose/build/stages/'+name+'.json'))['command']
cmd=get('emit-program');cmd[cmd.index('-o')+1]=str(d/'probe.generated.c');cmd[cmd.index('--header')+1]=str(d/'probe.h');cmd[cmd.index('-O2')]='-O0';cmd[-1]=str(src/'main.goose');subprocess.run(cmd,check=True)
cmd=get('compile-and-link-program');cmd[cmd.index('-O2')]='-O0';cmd[cmd.index(next(a for a in cmd if a.endswith('blot_goose.c')))]=str(d/'probe.generated.c');cmd[-2:-2]=['-fno-omit-frame-pointer','-fno-optimize-sibling-calls','-no-pie',str(d/'why.c')];cmd[-1]=str(d/'probe');subprocess.run(cmd,check=True)
wrapper=d/'traced'
wrapper.write_text('#!/bin/sh\nBLOT_SHAPES_DIR="$(dirname "$0")"\nexport BLOT_SHAPES_DIR\nexec "$BLOT_SHAPES_DIR/probe" "$@"\n')
wrapper.chmod(0o755)
subprocess.run(['deno','run','-A','scripts/integration/build_gdev.ts','--compiler',wrapper,'--timeout-ms','45000',d/'wasm'],check=True)
