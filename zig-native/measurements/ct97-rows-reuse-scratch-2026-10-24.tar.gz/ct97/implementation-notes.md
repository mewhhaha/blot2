# CT97 / CT98 / BT4 implementation evidence

These notes describe unqualified changes pending final full-gate and release
measurements. Base d98e84c; separate dirty text-capability work is excluded.

CT97 largest effect store: 402,273,418 chain hops (longest 5,864); version visits
match hops, so indexing a variable's write history cannot address this cost.
Keep resolved prefixes through append-only writes, recheck their open tails,
and revoke row-ID cache on rollback. Compress only empty-label selected version
paths; later-version target and birth stamp make suffix rollback/recycling
validation O(1) at each link. Epoch saturation disables reuse. New differential
law uses cache-disabled chronology oracle, duplicates, independent roots,
appends, cursor gaps, rollback, recycled destination and saturated epochs,
including all allocation failures. Existing laws cover nonempty intermediates.

CT98: trace showed exactly 4,096 index records, saturation true and incomplete
capture. Completeness is intentionally required by executable admission.
Separate executable default 16K records/8MiB retained capacity from optional
semantic default 4K/2MiB. Keep 16MiB payload, 4K lookup work, exact semantic and
physical replay guards. First combined prefix/cap screen restored 4,535 reused
functions (3,297 named/1,238 closures), but cut literal CPU only 25% and body CPU
31%; do not attribute those combined gains exclusively to capacity or close the
50% target. Profiled retained work still spends most time in inference; replay
and candidate lookup are small. The three largest principal regions still run.

BT4: all fixture boundary checks retained. Count actual successful backend
allocations with a diagnostic allocator that rejects resizing like fault
injection, and native frame pointers enabled only for stack attribution. 128B
scratch first trial saved only ~6%, since initial u32 ArrayList capacity is 132B.
512B temporary conversion/maps and 2KiB scalar-replacement analysis are the
second bounded trial. Owned outputs are copied into the original destination
allocator; overflow delegates and is fully injected. The wide-row law crosses
512B and checks duplicate multiplicity and retained ownership. Deep-path normal
allocations 2,783 -> 2,208 and 3,097 -> 2,268. Three laws: 33 full sweeps, 44,074
-> 37,930 scenario runs, all passing (diagnostic execution times not paired or
comparable because frame pointers differ). Do not claim halved law or gate cost.

Incomplete attempts retained: initial diagnostic did not forward stderr; later
fresh diagnostic did and its following literal edit was deliberately stopped.
Two jump-source dev attempts failed only missing analyzer path; subsequent run
passed. Earlier Safe/noLLVM screens are not release throughput evidence. A
/usr/bin/time launch failed before release build (binary absent); Python resource
accounting launches the actual release. No unqualified candidate installed.
