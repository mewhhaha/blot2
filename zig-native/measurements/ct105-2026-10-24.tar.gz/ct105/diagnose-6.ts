import { createZigProjectCompiler } from '../../../compiler/zig_project_client.ts';
import { verifySnapshotFiles } from '../../../scripts/bench/snapshot.ts';
import { gdevWorkloads, sessionOptions, editedSources } from '../../../scripts/bench/gdev.ts';

const root = '/home/mewhhaha/src/blot2';
const out = `${root}/build/bench/ct105`;
const [w] = await gdevWorkloads(root, `${root}/build/bench/compile-cost-20261023/snapshot`);
const manifest = JSON.parse(await Deno.readTextFile(`${root}/build/bench/compile-cost-20261023/manifest.json`));
await verifySnapshotFiles(w.root, manifest);
const expected = (await Deno.readTextFile(`${root}/build/bench/ct103/warm-series.jsonl`)).trim().split('\n').map(l=>JSON.parse(l)).filter(r => r.variant === 'candidate');
const hz = Number(new TextDecoder().decode((await new Deno.Command('getconf', {args:['CLK_TCK'],stdout:'piped'}).output()).stdout));
const compiler = await createZigProjectCompiler({...sessionOptions(`${root}/zig-native/zig-out-analysis/bin/blotc`,w),codegenWorkers:4,cacheDirectory:false,profileBackend:true});
const digest = async (b:Uint8Array<ArrayBuffer>) => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b)), v=>v.toString(16).padStart(2,'0')).join('');
const original = w.scenarios.find(s=>s.name==='literal_in_body')!;
const body = w.scenarios.find(s=>s.name==='body_change')!;
const bodyEdits = ['const walk_material = fn phase => first_material + from (ceil phase)','const walk_material = fn phase => first_material + from (@f32.floor phase)','const walk_material = fn phase => first_material + from (@f32.abs phase)'];
await Deno.writeTextFile(`${out}/diagnostic-6.jsonl`,'');
try {
  for(let revision=0;revision<=1;revision++) {
    const sources=revision===0||revision===7?{}:revision<=3?await editedSources(w,{...original,replacements:original.replacements.map(r=>({...r,replace:r.replace.replace('0.1876',`0.${1875+revision}`)}))}):await editedSources(w,{...body,replacements:body.replacements.map(r=>({...r,replace:bodyEdits[revision-4]}))});
    const before=await Deno.readTextFile(`/proc/${compiler.pid}/stat`);
    const start=performance.now();
    const r=await compiler.build({sources});
    const wall_ms=performance.now()-start;
    const after=await Deno.readTextFile(`/proc/${compiler.pid}/stat`);
    const ticks=(s:string)=>s.slice(s.lastIndexOf(') ')+2).trim().split(/\s+/).map(Number);
    const bt=ticks(before),at=ticks(after);
    const user_ms=(at[11]-bt[11])*1000/hz,system_ms=(at[12]-bt[12])*1000/hz;
    if(!r.success)throw Error(JSON.stringify(r.diagnostics));
    const wasm_sha256=await digest(r.bytes);
    if(wasm_sha256!==expected.find(e=>e.revision===revision)?.wasm_sha256)throw Error(`Output mismatch revision ${revision}`);
    const record={revision,pid:compiler.pid,wall_ms,user_ms,system_ms,wasm_sha256,stats:r.stats};
    await Deno.writeTextFile(`${out}/diagnostic-6.jsonl`,JSON.stringify(record)+'\n',{append:true});
    console.log(JSON.stringify({revision,wall_ms,user_ms,system_ms}));

  }
  await verifySnapshotFiles(w.root,manifest);
  await Deno.writeTextFile(`${out}/diagnostic-6-success.json`,JSON.stringify({success:true,revisions:2,profile_backend:true,inputs_unchanged:true,all_outputs_match_previous_fresh_controls:true})+'\n');
} finally { await compiler.dispose(); }
