import { memoryProfileReport, stringifyMemoryProfile } from 'file:///home/mewhhaha/src/blot2/compiler/memory_profile.ts';
// Diagnostic copy of scripts/perf/cpu.mjs with measured-window V8 sampling.
// Uses the same restore, validation, input tape, frame hashing, and save hashing.
import inspector from 'node:inspector';
import * as fs from 'node:fs/promises';
import {writeFileSync} from 'node:fs';
globalThis.Deno={args:process.argv.slice(2),version:{node:process.version,v8:process.versions.v8},readFile:async p=>new Uint8Array(await fs.readFile(p)),readTextFile:p=>fs.readFile(p,'utf8'),writeTextFile:(p,s)=>fs.writeFile(p,s),writeTextFileSync:writeFileSync};
const profiler = new inspector.Session();profiler.connect();
profiler.post('Profiler.enable');profiler.post('Profiler.setSamplingInterval',{interval:1000});
let sampled;
// Synchronous V8 guest benchmark. This deliberately excludes browser hosting.
import { createHash } from 'node:crypto';
import { fnv64, replayFrames } from 'file:///home/mewhhaha/src/gdev/scripts/perf/witness.mjs';

const config = JSON.parse(await Deno.readTextFile(Deno.args[0]));
const { wasm, fixture, output, warmup, samples, width, height, step_seconds, trace = false } = config;
const bytes = await Deno.readFile(wasm);
const saved = await Deno.readFile(fixture);
const header = new DataView(saved.buffer, saved.byteOffset, saved.byteLength);
const version = header.getUint32(8, true);
const schema = header.getUint32(12, true);
const offset = version === 1 ? 20 : version === 2 ? 32 + 8 * header.getUint32(28, true) : -1;
if (offset < 0 || offset + header.getUint32(16, true) * 4 !== saved.length) throw Error('Invalid snapshot');
const state = new Float32Array(saved.buffer.slice(offset));
const restore = new Float32Array(state.length + 2);
restore.set([0, 4]); restore.set(state, 2);
const inputs = config.tape ? replayFrames(await Deno.readFile(config.tape), saved.subarray(offset), config.tape_frames ?? warmup + samples, schema).slice(0, warmup + samples)
  : Array.from({length: warmup + samples}, () => new Float32Array([step_seconds, width, height, 0, 0]));
let frame, commit = 1;
const names = ['rc_retains', 'rc_releases', 'rc_destroyed', 'cycle_passes', 'cycle_vertices', 'cycle_edges', 'cycle_bytes'];
let ex, phase = 'hello', done = 0, started = 0, initial = {}, restoreStart = 0, systemMs = 0;
const frames = [], systems = new Map(), spans = [], events = [], counters = {};
const frameHash = createHash('sha256');
const nativeHash = config.host_witnesses ? createHash('sha256') : null;
let inputHash;
const nativePackets = [];
let finalPacketHash;
let finalStateHash, restoreMs;
const startTime = performance.now();
const counts = () => Object.fromEntries(names.filter(n => ex[`blot:${n}`]).map(n => [n, ex[`blot:${n}`].value >>> 0]));
const delta = (a, b) => Object.fromEntries(Object.keys(a).map(n => [n, (b[n] - a[n]) >>> 0]));
const add = (a, b) => { for (const [n, v] of Object.entries(b)) a[n] = (a[n] || 0) + v; };
function write(values) {
  const p = ex['blot:allocate']((values.length + 1) * 4);
  new DataView(ex['blot:memory'].buffer).setUint32(p, values.length, true);
  new Float32Array(ex['blot:memory'].buffer, p + 4, values.length).set(values);
  return p;
}
function sendFrame() {
  if(done===warmup)profiler.post('Profiler.start');
  frame = new Float32Array(inputs[done].length + 2);
  frame.set([commit, 2]); frame.set(inputs[done], 2); commit = 1;
  inputHash = nativeHash ? fnv64(new Uint8Array(frame.buffer, 8)) : null;
  const p = write(frame);
  initial = counts();
  systemMs = 0;
  started = performance.now();
  return p;
}
function exchange(_ref, pointer) {
  const now = performance.now();
  const count = new DataView(ex['blot:memory'].buffer).getUint32(pointer, true);
  const values = new Float32Array(ex['blot:memory'].buffer, pointer + 4, count);
  if (values[0] === -4670544) {
    if (!trace) throw Error('Unexpected system marker in untraced measurement');
    const key = `${values[2]}:${values[3]}`;
    if (values[1] === 1) {
      if (!systems.has(key)) systems.set(key, { key, stage: values[2], id: values[3],
        name: String.fromCodePoint(...values.subarray(4)) || `stage ${values[2]}, system ${values[3]}`,
        calls: [], counters: {}, memoryGrowth: 0 });
      const response = write([]);
      spans.push({ key, counters: counts(), memory: ex['blot:memory'].buffer.byteLength, start: performance.now() });
      return response;
    }
    const span = spans.pop();
    if (!span || span.key !== key) throw Error('Unbalanced system trace');
    if (phase === 'frames' && done >= warmup) {
      const row = systems.get(key), duration = now - span.start;
      if (!spans.length) systemMs += duration;
      row.calls.push(duration);
      add(row.counters, delta(span.counters, counts()));
      row.memoryGrowth += ex['blot:memory'].buffer.byteLength - span.memory;
      events.push({ name: row.name, cat: `stage ${row.stage}`, ph: 'X', pid: 1, tid: 1,
        ts: (span.start - startTime) * 1000, dur: duration * 1000, args: { frame: done } });
    }
    return write([]);
  }
  if (phase === 'hello') {
    if (values[0] !== 4670544 || values[2] !== schema) throw Error('Guest/fixture schema mismatch');
    phase = 'restore'; restoreStart = performance.now(); return write(restore);
  }
  if (phase === 'restore') {
    if (values[0] !== 4 || values[1] === -1) throw Error('Fixture restore failed');
    restoreMs = now - restoreStart;
    if (config.host_validation) {
      phase = 'validate'; return write([1, 2, 0, width, height, 0, 0]);
    }
    phase = 'frames'; return sendFrame();
  }
  if (phase === 'validate') {
    if (values[0] !== 2) throw Error('Host validation frame failed');
    // Replay restore validates speculatively; its next request discards that
    // pending world rather than committing the validation presentation.
    commit = 0;
    phase = 'frames'; return sendFrame();
  }
  if (phase === 'snapshot' || phase === 'checkpoint') {
    if (values[0] !== 3) throw Error('Final snapshot failed');
    if (phase === 'checkpoint') {
      Deno.writeTextFileSync(`${config.checkpoints}/${done}.json`, JSON.stringify([...values.subarray(1)]));
      commit = 0; phase = 'frames'; return sendFrame();
    }
    if (config.saved) Deno.writeTextFileSync(config.saved, JSON.stringify([...values.subarray(1)]));
    finalStateHash = createHash('sha256').update(new Uint8Array(values.buffer, values.byteOffset + 4, values.byteLength - 4)).digest('hex');
    phase = 'stop'; return write([1, 0]);
  }
  if (phase !== 'frames' || values[0] !== 2 || spans.length) throw Error(`Invalid frame response ${phase}`);
  const used = delta(initial, counts());
  if (done >= warmup) {
    frames.push({ index: done, guest_ms: now - started, packet_bytes: values.byteLength,
      memory_bytes: ex['blot:memory'].buffer.byteLength, counters: used,
      ...(trace ? { systems_ms: systemMs, outside_systems_ms: Math.max(0, now - started - systemMs) } : {}) });
    add(counters, used);
    if (trace) {
      events.push({ name: 'guest frame', cat: 'frame', ph: 'X', pid: 1, tid: 1,
        ts: (started - startTime) * 1000, dur: (now - started) * 1000, args: { frame: done } });
      events.push({ name: 'linear memory capacity', ph: 'C', pid: 1, tid: 1,
        ts: (now - startTime) * 1000, args: { bytes: ex['blot:memory'].buffer.byteLength } });
    }
  }
  // Correctness and hashing are outside the timed guest span.
  for (const n of values) if (!Number.isFinite(n)) throw Error(`Nonfinite frame ${done}`);
  frameHash.update(new Uint8Array(values.buffer, values.byteOffset, values.byteLength));
  if (nativeHash) {
    if (done) nativeHash.update('\n');
    // Program.response removes the operation tag before native packet hashing.
    const packetHash = fnv64(new Uint8Array(values.buffer, values.byteOffset + 4, values.byteLength - 4));
    nativePackets.push(packetHash);
    nativeHash.update(inputHash + ' ' + packetHash);
  }
  done++;
  if (done === warmup + samples) finalPacketHash = createHash('sha256').update(new Uint8Array(values.buffer, values.byteOffset, values.byteLength)).digest('hex');
  if (done === warmup + samples) { profiler.post('Profiler.stop', (error,result)=>{if(error)throw error;sampled=result.profile;}); phase = 'snapshot'; return write([1, 3]); }
  if (config.checkpoints && done % (config.checkpoint_frames || 600) === 0) {
    phase = 'checkpoint'; return write([1, 3]);
  }
  return sendFrame();
}
const compiledAt = performance.now();
const instance = await WebAssembly.instantiate(bytes, { 'blot:host/1': { call_array_f32_array_f32: exchange } });
const compileMs = performance.now() - compiledAt;
ex = instance.instance.exports;
const entry = config.entry ?? (trace ? 'main_trace' : 'main');
if (typeof ex[entry] !== 'function') throw Error(`Missing ${entry}`);
ex['blot:ownership_enter']?.(); ex['blot:reset'](0); ex[entry]({});
if (done !== warmup + samples || phase !== 'stop' || spans.length) throw Error('Incomplete run');
// End measurements before snapshot teardown/reset can change counters.
const result = { format: 1, engine: Deno.version, kind: trace ? 'systems' : 'cpu',
  compile_ms: compileMs, restore_ms: restoreMs, frames, counters,
  frame_hash: frameHash.digest('hex'), final_state_hash: finalStateHash,
  ...(nativeHash ? { native_frame_hash: nativeHash.digest('hex'), native_packet_hashes: nativePackets,
    native_input_hash: inputHash, web_frame_hash: finalPacketHash } : {}),
  capabilities: { allocation_bytes: false, system_timings: trace, ownership_counters: Object.keys(counters),
    parallel_systems: false, note: 'Single-threaded synchronous guest; memory_bytes is linear memory capacity, not live heap, resident memory or allocation traffic.' },
  systems: [...systems.values()].map(row => ({ ...row, allocations: null, allocated_bytes: null })) };
if (config.profile_output) await Deno.writeTextFile(config.profile_output, stringifyMemoryProfile(await memoryProfileReport(bytes, ex)));
ex['blot:ownership_leave']?.(0); ex['blot:reset'](0);
await Deno.writeTextFile(output, JSON.stringify(result));
if (trace) await Deno.writeTextFile(output.replace(/\.json$/, '.trace.json'), JSON.stringify({ traceEvents: events }));
console.log(`${entry}: ${done} valid frames; ${result.frame_hash}`);

await new Promise(setImmediate);if(!sampled)throw Error('Missing CPU profile');await fs.writeFile(output.replace('.json','.cpuprofile'),JSON.stringify(sampled));profiler.disconnect();
