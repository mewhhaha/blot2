import json,statistics,sys
from pathlib import Path
for name in sys.argv[1:]:
 p=Path('build/bench/ct109')/name
 r=json.loads((p/'results.json').read_text()); samples=[json.loads(x) for x in (p/'samples.jsonl').read_text().splitlines()]
 result={'name':name,'success':r['success'],'runs':r['runs'],'host':r['host'],'rows':[],'problems':r['problems']}
 for workload,phase in dict.fromkeys((s['workload'],s['phase']) for s in samples):
  both={v:{s['run']:s for s in samples if s['workload']==workload and s['phase']==phase and s['variant']==v} for v in ['baseline','candidate']}
  if not all(both.values()):continue
  row={'workload':workload,'phase':phase}
  for v,rs in both.items():
   row[v]={k:{'median':statistics.median(s[k] for s in rs.values()),'min':min(s[k] for s in rs.values()),'max':max(s[k] for s in rs.values())} for k in ['cpu_ms','wall_ms','peak_rss_kib']}
  ratios=[both['candidate'][i]['cpu_ms']/b['cpu_ms'] for i,b in both['baseline'].items() if i in both['candidate'] and b['cpu_ms']]
  row['paired_cpu_ratio']=statistics.median(ratios) if ratios else None
  result['rows'].append(row)
 (p/'pair-ranges.json').write_text(json.dumps(result,indent=2)+'\n')
 print(name,'success',r['success'])
 for row in result['rows']:
  if row['phase']=='population':continue
  print(row['workload'],row['phase'],'CPU',round(row['baseline']['cpu_ms']['median']),round(row['candidate']['cpu_ms']['median']),'ratio',round(row['paired_cpu_ratio'],4) if row['paired_cpu_ratio'] else None,'wall',round(row['candidate']['wall_ms']['median']))
