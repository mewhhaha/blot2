from pathlib import Path
from collections import Counter
import json, re, subprocess, bisect, sys
d=Path('build/function-pairs/cpu');syms=[]
for line in subprocess.check_output(['nm','-nS','build/resolve-hill/candidate'],text=True).splitlines():
    hit=re.fullmatch(r'([0-9a-f]+) ([0-9a-f]+) [tTwW] (\S+)',line)
    if hit:syms.append((int(hit[1],16),int(hit[2],16),hit[3]))
starts=[r[0] for r in syms];by=Counter()
for run in json.loads((d/'raw.json').read_text()):
    for _,kind,pc,n in run:
        if kind: continue
        i=bisect.bisect_right(starts,pc)-1;start,size,sym=syms[i]
        if pc<start+size and re.fullmatch(r'blot_project_packet_(put|get)_g\d+(_\d+)*',sym):by[sym]+=n
print('samples',sum(by.values()),'specializations',len(by),'top',by.most_common(8))
if not (d/'release.c').is_file():sys.exit(0)
sigs={}
for line in (d/'release.c').open():
    if 'blot_project_packet_' not in line: continue
    m=re.match(r'static void (blot_project_packet_(?:get|put)_g\d+(?:_\d+)*)\(([^;]+)\);',line)
    if m:sigs[m[1]]=m[2].split(', ')[1].split(' ')[0]
    if len(sigs)>0 and line.startswith('    '):break
missing=set(by)-set(sigs);assert not missing,sorted(missing)
top=[dict(symbol=sym,operand=sigs[sym],samples=n) for sym,n in by.most_common()]
print(top[:10]);(d/'packet-types.json').write_text(json.dumps(top,indent=2)+'\n')
