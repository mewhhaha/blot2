from pathlib import Path
import io,subprocess,tarfile
root=Path.cwd();source=root/'build/bench/bt4/profile-src';source.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD']))) as tf:tf.extractall(source,filter='data')
(source/'zig-native/.zig-cache').symlink_to(root/'build/bench/ct96-20261023/blot2/zig-native/.zig-cache',target_is_directory=True)
module=r'''const std = @import("std");
const A = std.mem.Allocator;
pub const Profile = struct {
    const Site = struct { hash: u64 = 0, frames: [8]usize = @splat(0), len: usize = 0, calls: u64 = 0, bytes: u64 = 0 };
    backing: A,
    sites: [8192]Site = @splat(.{}),
    total: usize = 0,
    pub fn allocator(self: *Profile) A { return .{ .ptr = self, .vtable = &.{ .alloc = alloc, .resize = resize, .remap = remap, .free = free } }; }
    fn alloc(ctx: *anyopaque, len: usize, alignment: std.mem.Alignment, ra: usize) ?[*]u8 {
        const self: *Profile = @ptrCast(@alignCast(ctx));
        var frames: [8]usize = @splat(0);
        const trace = std.debug.captureCurrentStackTrace(.{ .first_address = ra }, &frames);
        const hash = std.hash.Wyhash.hash(0, std.mem.sliceAsBytes(trace.return_addresses)) | 1;
        var slot = hash % self.sites.len;
        while (self.sites[slot].hash != 0 and (self.sites[slot].hash != hash or !std.mem.eql(usize, self.sites[slot].frames[0..self.sites[slot].len], trace.return_addresses))) slot = (slot + 1) % self.sites.len;
        const site = &self.sites[slot];
        if (site.hash == 0) { site.hash = hash; site.frames = frames; site.len = trace.return_addresses.len; }
        site.calls += 1; site.bytes += len; self.total += 1;
        return self.backing.rawAlloc(len, alignment, ra);
    }
    fn resize(_: *anyopaque, _: []u8, _: std.mem.Alignment, _: usize, _: usize) bool { return false; }
    fn remap(_: *anyopaque, _: []u8, _: std.mem.Alignment, _: usize, _: usize) ?[*]u8 { return null; }
    fn free(ctx: *anyopaque, bytes: []u8, alignment: std.mem.Alignment, ra: usize) void {
        const self: *Profile = @ptrCast(@alignCast(ctx)); self.backing.rawFree(bytes, alignment, ra);
    }
    pub fn report(self: *Profile, label: []const u8) !void {
        var arena = std.heap.ArenaAllocator.init(std.heap.page_allocator); defer arena.deinit();
        const a = arena.allocator();
        const info = try std.debug.getSelfDebugInfo();
        std.mem.sortUnstable(Site, &self.sites, {}, struct { fn less(_: void, left: Site, right: Site) bool { return left.calls > right.calls; } }.less);
        std.debug.print("ALLOC_TOTAL {s} {d}\n", .{label, self.total});
        for (self.sites[0..@min(60, self.sites.len)]) |site| {
            if (site.calls == 0) break;
            var frames: std.ArrayList(std.debug.Symbol) = .empty;
            for (site.frames[0..site.len]) |address| try info.getSymbols(std.testing.io, a, a, address -| 1, true, &frames);
            const record = try std.json.Stringify.valueAlloc(a, .{ .label = label, .calls = site.calls, .bytes = site.bytes, .frames = frames.items }, .{});
            std.debug.print("ALLOC_SITE\t{s}\n", .{record});
        }
    }
};
'''
(source/'zig-native/src/allocation_site_profile.zig').write_text(module)
p=source/'zig-native/src/backend/structural_record_tests.zig';s=p.read_text();s+=r'''
test "diagnostic deep path allocation sites" {
    const a = std.testing.allocator;
    const library = try std.Io.Dir.cwd().readFileAlloc(std.testing.io, "std/path.blot", a, .limited(65536));
    defer a.free(library);
    for ([_][]const u8{ deep_path_fault_source, deep_effect_path_fault_source }, [_][]const u8{ "deep", "deep_effect" }) |fixture, label| {
        const input = try a.print("{s}\n{s}", .{library, fixture}); defer a.free(input);
        var module = try lowerInput(a, input); defer module.deinit(a);
        var profile: @import("../allocation_site_profile.zig").Profile = .{ .backing = a };
        try emit(profile.allocator(), &module);
        try profile.report(label);
    }
}
''';p.write_text(s)
