import json,re
selection={'core':['merge_ranges','field_names','obligations','nominals','constructors','associated','projections','types.effects.rows'],'interface':['bindings','constructors','nominals','obligations','associated']}
types=['blot_check_core::List','blot_check_core::FieldName','blot_check_core::Obligation','blot_check_core::Nominal','blot_check_core::Constructor','blot_check_core::Associated','blot_check_core::Projection','blot_check_effects::Row','blot_reuse_principal_interface::Binding','blot_reuse_principal_interface::Constructor','blot_reuse_principal_interface::Nominal','blot_check_types::Obligation','blot_reuse_principal_interface::Associated']
(d/'fields.json').write_text(json.dumps({'selection':selection,'types':types},indent=2))
if stage=='arrays':
 i=main.index('fn inspect(');j=main.index('fn main()',i)
 measure='''
fn measure<T>(key:u32,values:const T[:]) {
    if values.len==0 {return;}
    var owner,error=blot_project_packet::initOwner();assert(error==blot_error::Error.none);
    for mode in 0..2 {
        var out:u8[>..<]=[];var writer=blot_project_packet::Writer{out};
        let w=blot_native::clock_ns();
        if mode==0 {blot_project_packet::put(writer,values);} else {blot_project_packet::putFlat(writer,values);}
        let elapsed=blot_native::clock_ns()-w;
        assert(writer.failure==blot_error::Error.none);
        note(1000+4*key+mode as u32,out.len,elapsed);
        let data=inputs.alloc_slice(out.len);for byte,i in out {data[i]=byte;}
        var reader=blot_project_packet::Reader{data,owner};var decoded:T[:]=default<T[:]>();
        let r=blot_native::clock_ns();
        if mode==0 {blot_project_packet::get(reader,decoded);} else {blot_project_packet::getFlat(reader,decoded);}
        note(1002+4*key+mode as u32,values.len,blot_native::clock_ns()-r);
        assert(reader.failure==blot_error::Error.none && reader.at==out.len && decoded==values);
        inputs.free_slice(data);
    }
    owner.deinit();
}
'''
 k=0
 for group,t in [('core','blot_check_core::Module'),('interface','blot_reuse_principal_interface::Interface')]:
  measure+='fn inspect(v:const '+t+'&) {\n'
  for path in selection[group]:
   measure+='    measure('+str(k)+' as u32,v.'+path+');\n';k+=1
  measure+='}\n'
 main=main[:i]+measure+main[j:]
