import subprocess,json,sys
worker=subprocess.Popen([sys.executable,'-u','-c','''import sys,threading,queue
print("ready",flush=True)
queues=[];done=queue.Queue();threads=[]
def work(q):
 while True:
  item=q.get()
  if item is None:return
  x=0
  for i in range(3000000):x+=i
  done.put(x)
for line in sys.stdin:
 if line.strip()=="create":
  for i in range(2):
   q=queue.Queue();queues.append(q);t=threading.Thread(target=work,args=(q,));threads.append(t);t.start()
 else:
  n=int(line)
  for q in queues[:n]:q.put(1)
  for i in range(n):done.get()
 print("done",flush=True)
for q in queues:q.put(None)
for t in threads:t.join()
'''],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
monitor=None
try:
 assert worker.stdout.readline().strip()=='ready'
 monitor=subprocess.Popen([sys.executable,'scripts/bench/process_pmu.py',str(worker.pid)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
 ready=json.loads(monitor.stdout.readline());assert ready['ready']
 rows=[]
 for command in ['create','1','2','1']:
  monitor.stdin.write('start\n');monitor.stdin.flush();assert json.loads(monitor.stdout.readline())['started']
  worker.stdin.write(command+'\n');worker.stdin.flush();assert worker.stdout.readline().strip()=='done'
  monitor.stdin.write('stop\n');monitor.stdin.flush();result=json.loads(monitor.stdout.readline());result['command']=command;rows.append(result)
 instructions=[sum(r['raw'] for r in row['counters'] if r['event']=='instructions') for row in rows[1:]]
 assert instructions[0]>1000000 and 1.7<instructions[1]/instructions[0]<2.3 and .9<instructions[2]/instructions[0]<1.1,instructions
 result={'success':True,'ready':ready,'samples':rows,'instruction_counts':instructions,'two_worker_ratio':instructions[1]/instructions[0],'repeat_ratio':instructions[2]/instructions[0]}
 open('build/bench/ct106/process-pmu-retained-verification.json','w').write(json.dumps(result,indent=2)+'\n')
 print('Retained inherited-thread coverage passed',instructions)
finally:
 if monitor:
  monitor.stdin.write('quit\n');monitor.stdin.flush();assert monitor.wait(timeout=5)==0
 worker.stdin.close();assert worker.wait(timeout=5)==0
