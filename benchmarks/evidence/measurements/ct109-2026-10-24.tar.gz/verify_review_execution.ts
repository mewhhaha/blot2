import { createZigProjectCompiler } from '../../../compiler/zig_project_client.ts';
import { reviewPrograms, reviewProjects } from '../../../scripts/bench/review_corpus.ts';
const root=Deno.cwd();
const dir=root+'/build/bench/ct109/review-pairs-final';
const pairs=JSON.parse(await Deno.readTextFile(dir+'/results.json'));
if(!pairs.success)throw Error('Held-out pair controls did not pass');
const digest=async(b:Uint8Array)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b)),x=>x.toString(16).padStart(2,'0')).join('');
const cases=reviewPrograms.map(program=>({name:`${program.name}_${program.size}`,entry:'main.blot',edit:{'main.blot':program.source.replace(program.edit.search,program.edit.replace)},expected:program.name==='review_record'?[15+program.size,16+program.size]:program.name==='review_closures'?[15,16]:program.name==='review_shared_dag'?[1031,2055]:program.name==='review_quantified'?[21,22]:[8,9]}));
for(const project of reviewProjects){const edit:Record<string,string>={};for(const replacement of project.scenarios[0].replacements){edit[replacement.file]=project.files[replacement.file].replace(replacement.search,replacement.replace)}cases.push({name:project.name,entry:project.entry,edit,expected:[39,40]});}
const results=[];
for(const variant of pairs.variants){
 if(await digest(await Deno.readFile(variant.executable))!==variant.sha256)throw Error('Binary changed');
 for(const scenario of cases){
  const cwd=dir+'/synthetic/'+scenario.name;
  const compiler=await createZigProjectCompiler({executable:variant.executable,entry:cwd+'/'+scenario.entry,prelude:root+'/std/prelude.blot',stdRoot:scenario.name.startsWith('review_modules_')?root+'/std':null,codegenWorkers:4,cacheDirectory:false});
  try{for(const [revision,sources] of [{},Object.fromEntries(Object.entries(scenario.edit).map(([name,text])=>[cwd+'/'+name,text]))].entries()){
   const built=await compiler.build({sources});if(!built.success)throw Error(JSON.stringify(built));
   const hash=await digest(built.bytes);const phase=revision===0?'fresh':scenario.name.startsWith('review_modules_')?'edit:producer_body':'edit:edit';if(hash!==pairs.wasm[scenario.name][phase+'/'+variant.name])throw Error('Output differs from measured artifact');
   const module=new WebAssembly.Module(built.bytes);if(WebAssembly.Module.imports(module).length)throw Error('Unexpected imports');
   const instance=new WebAssembly.Instance(module);const main=instance.exports.main;if(typeof main!=='function')throw Error('Missing main');
   const value=main(7);if(value!==scenario.expected[revision])throw Error(`${scenario.name}/${revision}: ${value}`);
   results.push({variant:variant.name,case:scenario.name,revision,argument:7,value,wasm_sha256:await digest(built.bytes)});
  }}finally{await compiler.dispose()}
 }
}
await Deno.writeTextFile(root+'/build/bench/ct109/review-execution.json',JSON.stringify({success:true,cases:cases.length,executions:results.length,results},null,2)+'\n');
console.log(JSON.stringify({success:true,cases:cases.length,executions:results.length}));
