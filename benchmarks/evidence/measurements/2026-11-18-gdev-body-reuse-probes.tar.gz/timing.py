from pathlib import Path
import json,os,subprocess,time,statistics
d=Path(__file__).resolve().parent
base=d/'base'
cases=json.loads((d/'matrix.json').read_text())
pick=['boolean','staged-provider','reachable-integer-width','shape']
records=[]
for round in range(12):
    for index,name in enumerate(pick):
        case=next(x for x in cases if x['name']==name)
        root=base if case['base']=='base' else d/case['base']
        env=dict(os.environ,BLOT_BASE=str(root),BLOT_EDIT=str(d/case['edit']))
        if round%2:env['BLOT_REFERENCE_FIRST']='1'
        modes=['probe','control']
        if (round+index)%2:modes.reverse()
        for mode in modes:
            r=subprocess.run([d/mode],env=env,capture_output=True,text=True,check=True,timeout=12)
            counts={}
            for l in r.stdout.splitlines():
                k,v=map(int,l.split());counts.setdefault(k,[]).append(v)
            if mode=='probe':assert counts[10]==[1] and counts[14]==case['counts']['14']
            records.append(dict(round=round,case=name,mode=mode,counts=counts))
    (d/'trials.json').write_text(json.dumps(records,separators=(',',':')))
