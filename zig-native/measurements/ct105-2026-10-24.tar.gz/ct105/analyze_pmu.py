from pathlib import Path
import json,hashlib
p=Path(__file__).parent;read=lambda f:[json.loads(l) for l in (p/f).read_text().splitlines()]
b,c=read('pmu-baseline.jsonl'),read('pmu-candidate.jsonl');rows=[]
for x,y in zip(b,c):
 assert x['revision']==y['revision'] and x['wasm_sha256']==y['wasm_sha256']
 if x['revision']==0:continue
 full=all(e['time_enabled_ns']==e['time_running_ns'] and e['time_running_ns']>0 for r in [x,y] for e in r['counters'].values())
 row={'revision':x['revision'],'all_events_fully_scheduled':full,'events':{name:{'baseline':x['counters'][name]['raw'],'candidate':y['counters'][name]['raw'],'ratio':y['counters'][name]['raw']/x['counters'][name]['raw']} for name in x['counters']},'baseline_wall_ms':x['wall_ms'],'candidate_wall_ms':y['wall_ms']}
 rows.append(row)
print(json.dumps({'all_events_fully_scheduled':all(r['all_events_fully_scheduled'] for r in rows),'samples':[{k:v for k,v in r.items() if k!='events'}|{'instructions':r['events']['instructions'],'cycles':r['events']['cycles']} for r in rows]},indent=2))
pins=json.loads((p/'final-pins.json').read_text())
root=p.resolve().parents[2]
for name,digest in pins['source'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for variant in ['baseline','candidate']:assert hashlib.sha256(Path(pins[variant]['path']).read_bytes()).hexdigest()==pins[variant]['sha256']
(p/'pmu-summary.json').write_text(json.dumps({'scope':'one dominant compiler thread, user space only, no inheritance; generic hardware events; one sequence per variant, not seven paired samples','all_events_fully_scheduled':all(r['all_events_fully_scheduled'] for r in rows),'source_binary_pins_unchanged':True,'samples':rows},indent=2)+'\n')
