const source = 'build/bench/ct106/release-compact-timing-final';
const files = [...Deno.readDirSync(source)].filter(e => e.name.endsWith('.bin')).map(e => e.name).sort();
const server = Deno.serve({hostname:'127.0.0.1',port:0,onListen(){}}, request => {
 const {socket,response} = Deno.upgradeWebSocket(request);
 socket.onopen = () => { for(const name of files) socket.send(Deno.readFileSync(source+'/'+name)); };
 return response;
});
const result = await new Deno.Command(Deno.execPath(),{args:['run','-A','scripts/bench/zig_time_report.ts',`ws://127.0.0.1:${server.addr.port}/`,'build/bench/ct106/timing-replay'],stdout:'piped',stderr:'piped'}).output();
console.log(new TextDecoder().decode(result.stdout));
console.error(new TextDecoder().decode(result.stderr));
await server.shutdown();
if(!result.success) throw Error('collector failed');
const old = JSON.parse(Deno.readTextFileSync(source+'/report.json'));
const now = JSON.parse(Deno.readTextFileSync('build/bench/ct106/timing-replay/report.json'));
if(JSON.stringify(old.reports)!==JSON.stringify(now.reports)) throw Error('changed decoded reports');
console.log('Raw timing replay matches all reports');
