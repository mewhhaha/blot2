import pathlib,subprocess,time,json,os
root=pathlib.Path('/home/mewhhaha/src/blot2'); out=root/'build/bench/ct97'; src=out/'final-src'
report=out/'final-release.json'; deadline=time.monotonic()+600
while not report.exists():
 if time.monotonic()>deadline: raise SystemExit('Release build did not complete')
 time.sleep(1)
assert json.loads(report.read_text())['exit_code']==0
assert subprocess.check_output(['zig','version'],text=True).strip()=='0.17.0'
cmd=['deno','task','test:compiler','--native-shards','4','--phase-seconds','900','--budget-seconds','1200','--timings-dir',str(out/'final-gate')]
(out/'final-gate-command.json').write_text(json.dumps(cmd,indent=2)+'\n')
env=dict(os.environ,ZIG_ANALYZER=str(root/'build/tools/zig-analyzer/zig-analyzer-0.17.0-3-x86_64-linux/bin/zig-analyzer'))
print('START final full compiler gate',flush=True)
with (out/'final-gate.log').open('w') as f: p=subprocess.run(cmd,cwd=src,env=env,stdout=f,stderr=subprocess.STDOUT)
print('Full gate exit',p.returncode,flush=True)
if p.returncode: raise SystemExit(p.returncode)
raise SystemExit(subprocess.run(['python3',str(out/'run_final.py')],cwd=src).returncode)
