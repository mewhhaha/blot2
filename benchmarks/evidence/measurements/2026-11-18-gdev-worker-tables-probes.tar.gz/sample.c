#define _GNU_SOURCE
#include <fcntl.h>
#include <errno.h>
#include <link.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <ucontext.h>
#include <unistd.h>

struct image { uintptr_t first, end, base; uint32_t kind; };
static struct image images[128];
static unsigned image_count;
static int output;

static int image_ranges(struct dl_phdr_info *info, size_t size, void *arg) {
    uint32_t kind = 2;
    if (!info->dlpi_name[0]) kind = 0;
    else if (strstr(info->dlpi_name, "/libc.so")) kind = 1;
    for (unsigned i = 0; i < info->dlpi_phnum; ++i) {
        const ElfW(Phdr) *p = &info->dlpi_phdr[i];
        if (p->p_type != PT_LOAD || !(p->p_flags & PF_X)) continue;
        if (image_count == 128) abort();
        uintptr_t base = info->dlpi_addr;
        images[image_count++] = (struct image){base + p->p_vaddr,
            base + p->p_vaddr + p->p_memsz, base, kind};
    }
    return 0;
}
static void sample(int signal_number, siginfo_t *info, void *context) {
    int saved_errno = errno;
    uintptr_t pc = ((ucontext_t *)context)->uc_mcontext.gregs[REG_RIP];
    uint32_t record[3] = {(uint32_t)getpid(), 2, 0};
    for (unsigned i = 0; i < image_count; ++i) {
        struct image range = images[i];
        if (pc < range.first || pc >= range.end) continue;
        record[1] = range.kind;
        if (range.kind != 2) record[2] = (uint32_t)(pc - range.base);
        break;
    }
    if (write(output, record, sizeof record) != sizeof record) _exit(81);
    errno = saved_errno;
}
static void start_timer(void) {
    const struct itimerval timer = {{0, 1000}, {0, 1000}};
    if (setitimer(ITIMER_PROF, &timer, NULL) != 0) _exit(82);
}
__attribute__((constructor)) static void start_profiler(void) {
    const char *path = getenv("BLOT_PAIR_SAMPLES");
    if (!path) return;
    output = open(path, O_WRONLY | O_APPEND | O_CLOEXEC | O_CREAT, 0600);
    if (output < 0) _exit(83);
    dl_iterate_phdr(image_ranges, NULL);
    struct sigaction action = {0};
    action.sa_sigaction = sample;
    action.sa_flags = SA_SIGINFO | SA_RESTART;
    sigemptyset(&action.sa_mask);
    if (sigaction(SIGPROF, &action, NULL) || pthread_atfork(NULL, NULL, start_timer)) _exit(84);
    start_timer();
}
