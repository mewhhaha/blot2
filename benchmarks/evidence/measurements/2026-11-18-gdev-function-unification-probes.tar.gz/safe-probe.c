#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
static _Thread_local uint32_t n[4];void fp_begin(void){memset(n,0,sizeof n);} void fp_hit(uint32_t k){n[k]++;}
void fp_end(uint32_t mod){char b[256];int k=snprintf(b,sizeof b,"%u %u %u %u %u\n",mod,n[0],n[1],n[2],n[3]);int fd=open(getenv("BLOT_CURSOR_LOG"),O_APPEND|O_CREAT|O_WRONLY,0600);if(fd<0||write(fd,b,k)!=k)abort();close(fd);}
