from pathlib import Path
import hashlib,io,json,subprocess,tarfile
root=Path.cwd();out=root/'build/bench/ct97';source=out/'blot2';source.mkdir(exist_ok=True)
with tarfile.open(fileobj=io.BytesIO(subprocess.check_output(['git','archive','HEAD']))) as tf:tf.extractall(source,filter='data')
(out/'base-commit.txt').write_text(subprocess.check_output(['git','rev-parse','HEAD'],text=True))
p=source/'zig-native/src/check/effects.zig';s=p.read_text();(out/'effects-original.zig').write_text(s)
s=s.replace('pub const Store = struct {','''const Trace = struct {
    queries: u64 = 0, cache_hits: u64 = 0, cache_misses: u64 = 0, bypass_cursor: u64 = 0,
    invalidations: u64 = 0, replacement_queries: u64 = 0, version_visits: u64 = 0,
    last_rejects: u64 = 0, chain_hops: u64 = 0, max_hops: usize = 0,
    hop_histogram: [32]u64 = @splat(0),
};
pub const Store = struct {
    trace: Trace = .{},''')
s=s.replace('    pub fn deinit(self: *Store) void {','''    pub fn deinit(self: *Store) void {
        if (self.trace.queries > 100000) {
            if (std.json.Stringify.valueAlloc(std.heap.page_allocator, .{ .rows = self.rows.items.len, .versions = self.versions.items.len, .trace = self.trace }, .{})) |record| {
                defer std.heap.page_allocator.free(record);
                std.debug.print("ROW_TRACE\\t{s}\\n", .{record});
            } else |_| {}
        }''')
s=s.replace('        var index = self.variables.items[variable].first;','''        @constCast(self).trace.replacement_queries += 1;
        const last = self.variables.items[variable].last;
        if (last != none and self.versions.items[last].position < at) @constCast(self).trace.last_rejects += 1;
        var index = self.variables.items[variable].first;''',1)
s=s.replace('            const write = self.versions.items[index];','            @constCast(self).trace.version_visits += 1;\n            const write = self.versions.items[index];',1)
s=s.replace('    pub fn resolve(self: *Store, root: Id, at: Cursor) Error!Id {','''    pub fn resolve(self: *Store, root: Id, at: Cursor) Error!Id {
        self.trace.queries += 1;
        if (at != 0) self.trace.bypass_cursor += 1;''')
s=s.replace('        if (!self.resolved.activate(mutation, 0))','        if (self.resolved.mutation != mutation) self.trace.invalidations += 1;\n        if (!self.resolved.activate(mutation, 0))')
s=s.replace('        if (self.resolved.get(root)) |result| return result;','        if (self.resolved.get(root)) |result| { self.trace.cache_hits += 1; return result; }\n        self.trace.cache_misses += 1;')
s=s.replace('    fn resolveUncached(self: *Store, root: Id, at: Cursor) Error!Id {','''    fn resolveUncached(self: *Store, root: Id, at: Cursor) Error!Id {
        var hops: usize = 0;
        defer {
            self.trace.chain_hops += hops;
            self.trace.max_hops = @max(self.trace.max_hops, hops);
            self.trace.hop_histogram[if (hops == 0) 0 else @min(31, 1 + std.math.log2_int(usize, hops))] += 1;
        }''')
s=s.replace('            current = self.node(write.replacement);','            hops += 1;\n            current = self.node(write.replacement);')
p.write_text(s)
(out/'diagnostic-source.sha256').write_text(hashlib.sha256(p.read_bytes()).hexdigest()+'\n')
