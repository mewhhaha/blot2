from pathlib import Path
p=Path('build/bench/ct97/blot2/zig-native/src/reuse/artifact_fragment.zig');s=p.read_text()
s=s.replace('pub const State = struct {','''pub const State = struct {
    diagnostic: struct { calls: u64 = 0, disabled: u64 = 0, incomplete: u64 = 0, buckets: u64 = 0, origin: u64 = 0, blocked: u64 = 0, arguments: u64 = 0, bodies: u64 = 0, statics: u64 = 0 } = .{},''')
s=s.replace('    pub fn deinit(self: *State) void {','''    pub fn deinit(self: *State) void {
        if (std.json.Stringify.valueAlloc(std.heap.page_allocator, .{ .counts = self.diagnostic, .records = self.old.executable_queries.records.items.len, .saturated = self.old.executable_queries.saturated, .complete = self.old.executable_queries_complete, .enabled = self.enabled }, .{})) |record| {
            defer std.heap.page_allocator.free(record);
            std.debug.print("REUSE_TRACE\\t{s}\\n", .{record});
        } else |_| {}''')
s=s.replace('        if (!self.enabled or !self.old.executable_queries_complete) return null;','''        self.diagnostic.calls += 1;
        if (!self.enabled) { self.diagnostic.disabled += 1; return null; }
        if (!self.old.executable_queries_complete) { self.diagnostic.incomplete += 1; return null; }''')
s=s.replace('        while (candidates.next()) |position| {','        while (candidates.next()) |position| {\n            self.diagnostic.buckets += 1;')
s=s.replace('            if (!same_origin) continue;','            if (!same_origin) { self.diagnostic.origin += 1; continue; }')
s=s.replace('            if (job == 0 or self.blocked[job - 1]) continue;','            if (job == 0 or self.blocked[job - 1]) { self.diagnostic.blocked += 1; continue; }')
s=s.replace('            if (!try self.importer.matches(g, record.key.request, request)) continue;','            if (!try self.importer.matches(g, record.key.request, request)) { self.diagnostic.arguments += 1; continue; }')
s=s.replace('            if (!dependencies_match) continue;','            if (!dependencies_match) { self.diagnostic.bodies += 1; continue; }',1)
pos=s.index('            for (record.dependencies.static_reads)');s=s[:pos]+s[pos:].replace('            if (!dependencies_match) continue;','            if (!dependencies_match) { self.diagnostic.statics += 1; continue; }',1)
p.write_text(s)
p=Path('build/bench/ct97/blot2/zig-native/src/reuse/artifact_capture.zig');s=p.read_text();s=s.replace('    pub fn sealExecutableQueries(self: *Capture) std.mem.Allocator.Error!void {','''    pub fn sealExecutableQueries(self: *Capture) std.mem.Allocator.Error!void {
        defer std.debug.print("SEAL_TRACE records={d} saturated={d} complete={} capacity={d} payload={d}\\n", .{ self.executable_queries.records.items.len, self.executable_queries.saturated, self.executable_queries_complete, self.executable_queries.capacity_bytes, self.executable_queries.owned_bytes });''');p.write_text(s)
