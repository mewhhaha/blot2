import { createZigProjectCompiler } from './blot2/compiler/zig_project_client.ts';
import { gdevWorkloads, sessionOptions, editedSources } from './blot2/scripts/bench/gdev.ts';
const repo = Deno.cwd();
const [game] = await gdevWorkloads(repo, `${repo}/build/bench/compile-cost-20261023/snapshot`);
const compiler = await createZigProjectCompiler({...sessionOptions(`${repo}/build/bench/ct97/blot2/zig-native/zig-out-diagnostic/bin/blotc`, game), cacheDirectory:false, profileBackend: true, codegenWorkers:4});
try {
 for (const phase of ['fresh','literal_in_body']) {
  const scenario = game.scenarios.find(s=>s.name===phase);
  const sources = scenario ? await editedSources(game, scenario) : {};
  const start = performance.now();
  const result = await compiler.build({sources});
  if (!result.success) throw new Error(JSON.stringify(result));
  const hash = [...new Uint8Array(await crypto.subtle.digest('SHA-256',result.bytes))].map(n=>n.toString(16).padStart(2,'0')).join('');
  if (phase==='fresh' && hash!=='7cdefcb761628a6043e04d3a515e85e77074914d3ba67d275ec1672e2a09d071') throw new Error('Fresh output changed');
  await Deno.writeTextFile(`${repo}/build/bench/ct97/diagnostic-${phase}.json`,JSON.stringify({phase,wall_ms:performance.now()-start,hash,stats:result.stats},null,2)+'\n');
  console.log('COMPLETED',phase,hash);
 }
} finally { await compiler.close(); }
