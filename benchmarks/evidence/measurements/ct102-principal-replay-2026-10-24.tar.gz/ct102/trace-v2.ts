import {createZigProjectCompiler} from './trace-src/compiler/zig_project_client.ts';
import {gdevWorkloads,sessionOptions,editedSources} from './trace-src/scripts/bench/gdev.ts';
const root='/home/mewhhaha/src/blot2';
const [w]=await gdevWorkloads(root+'/build/bench/ct102/trace-src',root+'/build/bench/compile-cost-20261023/snapshot');
const c=await createZigProjectCompiler({...sessionOptions(Deno.args[0],w),cacheDirectory:false,profileBackend:true,codegenWorkers:4});
try {
 for(const name of ['population','literal_in_body']) {
  console.error('CT102 PHASE',name);
  const sources=['population','revert'].includes(name)?{}:await editedSources(w,w.scenarios.find(s=>s.name===name)!);
  const t=performance.now();const r=await c.build({sources});
  const row={name,ms:performance.now()-t,...r,bytes:undefined};
  await Deno.writeTextFile(Deno.args[1],JSON.stringify(row)+'\n',{append:true});
  console.error('CT102 COMPLETE',name,row.ms,r.success);
  if(!r.success) throw Error(JSON.stringify(r.diagnostics));
 }
} finally {await c.dispose();}
