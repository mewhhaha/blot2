import { strict as assert } from "node:assert";
import { instantiateGuest } from "../../compiler/guest.ts";
const executable = Deno.args[0];
const directory = await Deno.makeTempDir({prefix: "blot-install-check-"});
async function run(args: string[]) {
  const result = await new Deno.Command(executable, {args, cwd: directory, env: {BLOT_CACHE_DIR: ""}, stdout: "piped", stderr: "piped"}).output();
  assert.equal(result.code, 0, new TextDecoder().decode(result.stderr));
  return new TextDecoder().decode(result.stdout);
}
try {
  const guide = await run(["guide"]);
  assert(guide.includes("An explicit spawn helper"));
  const readme = await Deno.readTextFile(new URL("../../README.md", import.meta.url));
  const source = [...readme.matchAll(/```blot\n([\s\S]*?)```/g)].find((match) => match[1].includes("const scope = "))![1];
  await Deno.writeTextFile(`${directory}/tasks.blot`, source);
  await run(["build", `${directory}/tasks.blot`, `${directory}/tasks.wasm`, "--prelude", "none"]);
  for (const asynchronous of [false, true]) {
    const guest = await instantiateGuest(await Deno.readFile(`${directory}/tasks.wasm`), {asynchronous});
    try { assert.equal(asynchronous ? await guest.callAsync("answer", null) : guest.call("answer", null), 42); }
    finally { guest.dispose(); }
  }
  await Deno.writeTextFile(`${directory}/standard.blot`, "entry const answer=fn () => 40+2\n");
  await run(["fmt", `${directory}/standard.blot`]);
  await run(["fmt", `${directory}/standard.blot`, "--check"]);
  await run(["build", `${directory}/standard.blot`, `${directory}/standard.wasm`]);
  const guest = await instantiateGuest(await Deno.readFile(`${directory}/standard.wasm`));
  try { assert.equal(guest.call("answer", null), 42); } finally { guest.dispose(); }
  console.log(JSON.stringify({executable, checked: ["embedded guide", "formatter", "embedded standard library", "README tasks sync", "README tasks JSPI"], result: 42}));
} finally { await Deno.remove(directory, {recursive: true}); }
