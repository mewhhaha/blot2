Blot CPU, memory and algorithm audit, 24 October 2026

Compiler and manifest identities: pins.json. Host: host.json.
This is one unchanged qualified compiler, not an optimization comparison.
commands.json and measure.py record the three profiling modes and the
three-pair phase/instrumentation-overhead benchmark. All outputs must match
the frozen CT103 Wasm pins. Profiles run at random 5-15 ms GDB intervals.

Reproduction from the original workspace, with the exact frozen workload:
  python3 build/bench/performance-audit-20261024/measure.py
  deno run --allow-all build/bench/performance-audit-20261024/memory_series.ts
  deno run --allow-all build/bench/performance-audit-20261024/pmu_series.ts
  python3 build/bench/performance-audit-20261024/analyze.py
Run the measurement commands sequentially. They require local compiler children,
/proc visibility, ptrace for the GDB profiles, and perf_event_open for PMU events.
Do not rebuild or replace the installed compiler between measurements.

The memory and PMU scripts use archived CT103 fresh-controlled output hashes;
restore that prior evidence and the separately held frozen workload to repeat.
No workload source, compiler executable or Wasm output is included here.

analysis.json includes split edit/revert CPU attribution and memory summaries.
Self CPU rows are exclusive; inclusive rows overlap. Phase allocation traffic is
cumulative requests, not live bytes. RSS samples can miss peaks; VmHWM is lifetime.
Thread accounting has 100 ms sampling and process-tick boundary precision.

pmu.py uses generic Linux PERF_TYPE_HARDWARE events on only the dominant native
thread. No kernel/other-thread/Deno attribution, raw AMD events or DRAM bandwidth.
PERF_EVENT_IOC_RESET resets event counts, not enabled/running times; analyze.py
takes interval time deltas before calculating scaling. Raw enabled/running fields
in pmu-series.jsonl are cumulative. All observed per-interval running ratios are 1.

No compiler code changed and no semantic qualification gate was rerun.
