import { strict as assert } from "node:assert";
import { resolve } from "node:path";
import { createZigProjectCompiler } from "../../compiler/zig_project_client.ts";
const sides = {
 baseline: {executable:resolve("build/issue-fixes/candidate-blotc"), std:resolve("build/remaining-runtime/baseline-std")},
 candidate: {executable:resolve("build/remaining-runtime/candidate-blotc"), std:resolve("std")},
 ablation: {executable:resolve("build/remaining-runtime/cycle-ablation/zig-native/zig-out/bin/blotc"), std:resolve("std")},
};
const sha = async (bytes:Uint8Array<ArrayBuffer>) => [...new Uint8Array(await crypto.subtle.digest("SHA-256",bytes))].map(x=>x.toString(16).padStart(2,"0")).join("");
const names=["rc_retains","rc_releases","rc_destroyed","cycle_passes","cycle_vertices","cycle_edges","cycle_bytes","rc_roots","rc_leases"];
const exports:Record<string,WebAssembly.Exports>={};
const results:Record<string,any>={};
const count=4096; const lanes=Array.from({length:256},(_,i)=>i); let expected=0;
for(let i=0;i<count;i++){expected+=lanes[i%256]+i;lanes[i%256]=i;}
const invoke=(side:string)=>{const e=exports[side];(e["blot:ownership_enter"] as CallableFunction)();let outcome=1;try{assert.equal((e.update_snapshots as CallableFunction)(count),expected);outcome=0;}finally{(e["blot:ownership_leave"] as CallableFunction)(outcome);}for(const n of ["rc_roots","rc_leases"])assert.equal((e[`blot:${n}`] as WebAssembly.Global).value,0);};
const read=(side:string)=>Object.fromEntries(names.map(n=>[n,Number((exports[side][`blot:${n}`] as WebAssembly.Global).value)>>>0]));
for(const [side,opt] of Object.entries(sides)){
 const start=performance.now();const c=await createZigProjectCompiler({executable:opt.executable,entry:resolve("benchmarks/runtime-boundaries/acyclic-updates.blot"),prelude:`${opt.std}/prelude.blot`,stdRoot:opt.std,cacheDirectory:false});
 try{const b=await c.build();assert(b.success,JSON.stringify(b));const compile_ms=performance.now()-start;exports[side]=new WebAssembly.Instance(new WebAssembly.Module(b.bytes)).exports;for(let i=0;i<5;i++)invoke(side);const before=read(side);invoke(side);const after=read(side);results[side]={compiler_sha256:await sha(await Deno.readFile(opt.executable)),wasm_sha256:await sha(b.bytes),wasm_bytes:b.bytes.length,compile_ms,counts:Object.fromEntries(names.map(n=>[n,(after[n]-before[n])>>>0])),samples_ms:[],memory_bytes:(exports[side]["blot:memory"] as WebAssembly.Memory).buffer.byteLength};await Deno.writeFile(`build/remaining-runtime/acyclic-${side}.wasm`,b.bytes);}finally{await c.dispose();}
}
for(let round=0;round<31;round++)for(const side of round%2?["ablation","candidate","baseline"]:["baseline","candidate","ablation"]){const start=performance.now();for(let i=0;i<5;i++)invoke(side);results[side].samples_ms.push((performance.now()-start)/5);assert.equal((exports[side]["blot:memory"] as WebAssembly.Memory).buffer.byteLength,results[side].memory_bytes);}
assert.equal(results.candidate.counts.cycle_passes,0);assert(results.baseline.counts.cycle_vertices>0);assert(results.ablation.counts.cycle_vertices>0);
for(const r of Object.values(results))r.median_ms=[...r.samples_ms].sort((a,b)=>a-b)[15];
await Deno.writeTextFile("build/remaining-runtime/acyclic-results.json",JSON.stringify({complete:true,engine:Deno.version,count,expected,samples:31,batch:5,scope:"LLVM release compilers, optimized uninstrumented Wasm; alternating cases with exact witnesses, roots/leases and stable memory. Compile cost is one unsampled screen.",results},null,2));
console.log(JSON.stringify(results));
