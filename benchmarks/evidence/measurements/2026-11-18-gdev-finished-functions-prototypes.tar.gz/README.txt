Both patches apply independently to Blot 52798173.
signature-sharing.patch restricts reuse to the final normalization pass. The
focused resolution_views engine law covers different row cursors and tail
identities. To rebuild, regenerate the adapters listed in compiler-goose/README.md
and run deno task build:compiler. The 190 fixture records change solely in two
allocation counters. Use the normal test_fixtures.py --record interface to
refresh them when verifying this experimental compiler against the recorded gate.

skip-final-loops.patch is a separate experiment. On Gdev the emitted Wasm
matches, and all recorded fixture fields except type_nodes and effect_rows
match. cursor.goose is an executed store-level counterexample for a reader
using head(root, 0) independently on each child. The parent was bound between
two writes to its child's variable. Preserving the parent's substitution
position selects bool. Restarting the child's lookup from zero selects u32.

The time_gdev_parse.ts runner in scripts/integration produced the fresh, edit
and profiled measurements. The confirmation reverses which compiler starts each
round. The serial control sets frontendWorkers to one.
