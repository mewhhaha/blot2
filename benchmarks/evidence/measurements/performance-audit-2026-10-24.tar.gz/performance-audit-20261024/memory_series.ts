import { createZigProjectCompiler } from '../../../compiler/zig_project_client.ts';
import { verifySnapshotFiles } from '../../../scripts/bench/snapshot.ts';
import { gdevWorkloads, sessionOptions, editedSources } from '../../../scripts/bench/gdev.ts';

const root = '/home/mewhhaha/src/blot2';
const out = `${root}/build/bench/performance-audit-20261024`;
const [w] = await gdevWorkloads(root, `${root}/build/bench/compile-cost-20261023/snapshot`);
const manifest = JSON.parse(await Deno.readTextFile(`${root}/build/bench/compile-cost-20261023/manifest.json`));
await verifySnapshotFiles(w.root, manifest);
const expected = (await Deno.readTextFile(`${root}/build/bench/ct103/warm-series.jsonl`)).trim().split('\n').map(l=>JSON.parse(l)).filter(r => r.variant === 'candidate');
const hz = Number(new TextDecoder().decode((await new Deno.Command('getconf', {args:['CLK_TCK'],stdout:'piped'}).output()).stdout));
const compiler = await createZigProjectCompiler({...sessionOptions('/home/mewhhaha/.local/bin/blotc',w),codegenWorkers:4,cacheDirectory:false,profileBackend:false});
const digest = async (b:Uint8Array<ArrayBuffer>) => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b)), v=>v.toString(16).padStart(2,'0')).join('');
const original = w.scenarios.find(s=>s.name==='literal_in_body')!;
const body = w.scenarios.find(s=>s.name==='body_change')!;
const bodyEdits = ['const walk_material = fn phase => first_material + from (ceil phase)','const walk_material = fn phase => first_material + from (@f32.floor phase)','const walk_material = fn phase => first_material + from (@f32.abs phase)'];
function fields(s:string) { return Object.fromEntries(s.trim().split('\n').filter(l=>l.includes(':')).map(l=>{const [k,v]=l.split(':');return [k,v.trim()]})); }
async function sample(revision:number, rollup=false) {
  const p=`/proc/${compiler.pid}`;
  const [stat,status] = await Promise.all([Deno.readTextFile(`${p}/stat`),Deno.readTextFile(`${p}/status`)]);
  const s=stat.slice(stat.lastIndexOf(') ')+2).trim().split(/\s+/);
  const threads:Record<string,number[]>={};
  for await(const entry of Deno.readDir(`${p}/task`)) {
    try {threads[entry.name]=(await Deno.readTextFile(`${p}/task/${entry.name}/schedstat`)).trim().split(/\s+/).map(Number);} catch(e) {if(!(e instanceof Deno.errors.NotFound))throw e;}
  }
  return {revision,time_ms:performance.now(),cpu_ms:(Number(s[11])+Number(s[12]))*1000/hz,minor_faults:Number(s[7]),major_faults:Number(s[9]),status:fields(status),threads,smaps:rollup?fields(await Deno.readTextFile(`${p}/smaps_rollup`)):undefined};
}
await Deno.writeTextFile(`${out}/memory-series.jsonl`,'');
try {
  for(let revision=0;revision<=7;revision++) {
    const sources=revision===0||revision===7?{}:revision<=3?await editedSources(w,{...original,replacements:original.replacements.map(r=>({...r,replace:r.replace.replace('0.1876',`0.${1875+revision}`)}))}):await editedSources(w,{...body,replacements:body.replacements.map(r=>({...r,replace:bodyEdits[revision-4]}))});
    const samples:Awaited<ReturnType<typeof sample>>[]=[];
    const before=await sample(revision,true);samples.push(before);
    let running=true;
    const polling=(async()=>{while(running){await new Promise(r=>setTimeout(r,100));if(running)samples.push(await sample(revision));}})();
    const start=performance.now();
    const r=await compiler.build({sources});
    const wall_ms=performance.now()-start;
    const after=await sample(revision,true);running=false;await polling;samples.push(after);
    if(!r.success)throw Error(JSON.stringify(r.diagnostics));
    const wasm_sha256=await digest(r.bytes);
    if(wasm_sha256!==expected.find(e=>e.revision===revision)?.wasm_sha256)throw Error(`Output mismatch revision ${revision}`);
    const record={revision,pid:compiler.pid,wall_ms,cpu_ms:after.cpu_ms-before.cpu_ms,wasm_sha256,verified_against:'CT103 fresh-controlled warm series',stats:r.stats,samples};
    await Deno.writeTextFile(`${out}/memory-series.jsonl`,JSON.stringify(record)+'\n',{append:true});
    console.log(JSON.stringify({revision,wall_ms,cpu_ms:record.cpu_ms,rss:after.status.VmRSS,hwm:after.status.VmHWM,samples:samples.length}));
  }
  await verifySnapshotFiles(w.root,manifest);
  await Deno.writeTextFile(`${out}/memory-series-success.json`,JSON.stringify({success:true,revisions:8,profile_backend:false,inputs_unchanged:true,all_outputs_match_previous_fresh_controls:true})+'\n');
} finally { await compiler.dispose(); }
