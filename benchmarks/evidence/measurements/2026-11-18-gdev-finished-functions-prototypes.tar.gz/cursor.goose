// Final type projection must carry the substitution position into children.
import check.types;
import support.error;
fn main() {
    let ok=blot_error::Error.none;
    var store,e=blot_check_types::initWithOptions(blot_check_types::Options{closed_graphs:true,..});assert(e==ok);
    let child,ce=store.fresh();assert(ce==ok);
    let parent,pe=store.fresh();assert(pe==ok);
    let function,fe=store.function(blot_check_types::unit,child);assert(fe==ok);
    assert(store.appendVersion(child,blot_check_types::u32_type)==ok);
    assert(store.appendVersion(parent,function)==ok);
    assert(store.appendVersion(child,blot_check_types::boolean)==ok);
    let normalized,ne=store.resolve(parent,0);assert(ne==ok);
    assert(store.node(normalized).b==blot_check_types::boolean);
    let outer=store.head(parent,0);
    assert(store.head(store.node(outer).b,0)==blot_check_types::u32_type);
    store.deinit();
}
