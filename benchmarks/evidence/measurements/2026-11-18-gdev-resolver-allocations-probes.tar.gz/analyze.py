from pathlib import Path
import struct, bisect, subprocess, collections, json, re
d=Path(__file__).resolve().parent
nm=subprocess.check_output(['nm','-n',d/'probe'],text=True)
syms=[(int(a,16),n) for a,t,n in (x.split() for x in nm.splitlines() if len(x.split())==3) if t.lower()=='t']
off=[a for a,_ in syms]
def sym(a):
 if not a:return ''
 return re.sub(r'_g[0-9]+.*','',syms[bisect.bisect_right(off,a-1)-1][1])
tags='absent unit boolean unsigned32 floating32 never variable function product record nominal array list cursor type_constructor resolver provider state_provider projection scoped instance_selection erased_proof forall existential bound rigid usage instance_version'.split()
agg=collections.defaultdict(collections.Counter)
nested=total=0
for f in d.glob('trace-*'):
 data=f.read_bytes();p=0;states={}
 while p<len(data):
  owner,hi,gen,id,t,a,b,c,closed,caller,parent,n,depth=struct.unpack_from('<13I',data,p);p+=52
  w=struct.unpack_from('<%dI'%n,data,p);p+=n*4
  total+=1
  ow=(hi,owner)
  if ow not in states or states[ow][0]!=gen or states[ow][1]>=id:states[ow]=[gen,0,set(),{},{}]
  st=states[ow];st[1]=id;seen,structs,ids=st[2:];ch=lambda i:ids.get(i,(-1,i))
  key=(t,a,b,c)
  if t in (8,9):key=(t,w)
  elif t in (10,18,20):key=(t,a,b,w)
  sk=None
  if t==7:sk=(t,ch(a),ch(b),c)
  elif t==8:sk=(t,tuple(map(ch,w)))
  elif t==9:sk=(t,tuple(zip(w[::2],map(ch,w[1::2]))))
  elif t in (10,20):sk=(t,a,b,tuple(map(ch,w)))
  elif t in (11,12,13,15):sk=(t,ch(a))
  elif t==26:sk=(t,ch(a),b,ch(c))
  elif t==6:sk=(t,a,b);key=sk
  dup=key in seen and sk!=None;seen.add(key)
  sd=(sk in structs) if sk!=None else False
  if sk!=None:ids[id]=structs.setdefault(sk,(1,id))
  if depth:
   nested+=depth>1
   k=(tags[t],sym(caller),sym(parent))
   x=agg[k];x['count']+=1;x['sameDirect']+=dup;x['sameShape']+=sd;x['closed']+=bool(closed)
out=[dict(tag=t,caller=c,parent=par,**counts) for (t,c,par),counts in sorted(agg.items(),key=lambda kv:-kv[1]['count'])]
(d/'attribution.json').write_text(json.dumps(dict(allAdded=total,resolveAdded=sum(x['count'] for x in out),nested=nested,modules=len(list(d.glob('trace-*'))),rows=out),indent=2)+'\n')
for group in ['tag','caller','parent']:
 sums=collections.defaultdict(collections.Counter)
 for r in out:sums[r[group]].update({k:r[k] for k in ['count','sameDirect','sameShape','closed']})
 print(group,sorted(sums.items(),key=lambda kv:-kv[1]['count'])[:15])
print(out[:12])
