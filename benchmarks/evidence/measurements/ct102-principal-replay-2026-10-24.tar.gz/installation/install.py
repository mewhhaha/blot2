"""Install the qualified isolated CT102 package, preserving the prior binaries."""
from pathlib import Path
import datetime, gzip, hashlib, json, os, shutil, subprocess, tempfile

root = Path('/home/mewhhaha/src/blot2')
stage = root / 'build/install/ct102'
bench = root / 'build/bench/ct102'
src = bench / 'candidate-src'
target = Path('/home/mewhhaha/.local/bin')
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
summary = read(bench / 'summary.json')
assert summary['qualification']['native'] == 2541
assert all(summary['targets'][k] for k in ['literal_gain', 'unaffected_game', 'unaffected_devtools', 'unaffected_body'])
gate = read(bench / 'gate/timings.json')
assert gate['success'] and not gate['active']
pins = read(bench / 'final-inputs.json')
for name, digest in pins['files'].items():
    assert sha(src / name) == digest, name
staged = read(stage / 'staged-smoke.json')
expected = read(root / 'build/install/ct97-1aa132e/installed.json')['installed_sha256']
for name in ['blot', 'blotc']:
    assert sha(stage / name) == staged['staged_sha256'][name]
    assert sha(target / name) == expected[name], 'Installed binary changed: ' + name
assert sha(stage / 'blotc') == summary['pins']['candidate']['sha256']
assert hashlib.sha256(gzip.decompress((src / 'generated/compiler/blotc.gz').read_bytes())).hexdigest() == sha(stage / 'blotc')

backup = Path(tempfile.mkdtemp(prefix='previous-', dir=stage))
for name in ['blot', 'blotc']:
    shutil.copy2(target / name, backup / name)

def atomic_copy(source, destination):
    fd, path = tempfile.mkstemp(prefix='.' + destination.name + '-ct102-', dir=destination.parent)
    try:
        with os.fdopen(fd, 'wb') as out, source.open('rb') as inp:
            shutil.copyfileobj(inp, out)
            out.flush()
            os.fchmod(out.fileno(), 0o755)
            os.fsync(out.fileno())
        os.replace(path, destination)
        directory = os.open(destination.parent, os.O_RDONLY | os.O_DIRECTORY)
        try:
            os.fsync(directory)
        finally:
            os.close(directory)
    finally:
        if os.path.exists(path):
            os.unlink(path)

try:
    for name in ['blot', 'blotc']:
        atomic_copy(stage / name, target / name)
    cwd = Path(tempfile.mkdtemp(prefix='blot-installed-ct102-'))
    shutil.copy2(src / 'examples/lists.blot', cwd / 'smoke.blot')
    for name in ['blot', 'blotc']:
        assert Path(shutil.which(name)).resolve() == (target / name).resolve()
    commands = [
        ['blot', 'fmt', 'smoke.blot'],
        ['blot', 'fmt', 'smoke.blot', '--check'],
        ['blot', 'check', 'smoke.blot'],
        ['blot', 'build', 'smoke.blot', 'installed-cli.wasm'],
        ['blotc', 'build', 'smoke.blot', 'installed-native.wasm', '--prelude', str(src / 'std/prelude.blot'), '--std-root', str(src / 'std')],
    ]
    results = []
    for i, cmd in enumerate(commands):
        with (stage / f'installed-smoke-{i}.stdout.log').open('w') as out, (stage / f'installed-smoke-{i}.stderr.log').open('w') as err:
            run = subprocess.run(cmd, cwd=cwd, stdout=out, stderr=err)
        results.append({'command': cmd, 'exit_code': run.returncode})
        assert run.returncode == 0, cmd
    assert (cwd / 'installed-cli.wasm').read_bytes() == (cwd / 'installed-native.wasm').read_bytes()
    assert sha(cwd / 'installed-cli.wasm') == staged['wasm_sha256']
    run = subprocess.run(['deno', 'run', '--allow-read', str(stage / 'verify_wasm.ts'), str(cwd / 'installed-cli.wasm')], cwd=cwd, capture_output=True, text=True)
    assert run.returncode == 0, run.stderr
    execution = json.loads(run.stdout)
    guide = subprocess.check_output(['blot', 'guide'], cwd=cwd)
    assert guide.rstrip() == (src / 'compiler/guide.md').read_bytes().rstrip()
    installed = {name: sha(target / name) for name in ['blot', 'blotc']}
    assert installed == staged['staged_sha256']
    record = {
        'source_base': pins['base'], 'qualified_source_files': pins['files'],
        'installed_at_utc': datetime.datetime.now(datetime.timezone.utc).isoformat(),
        'directory': str(target), 'backup': str(backup), 'previous_sha256': expected,
        'installed_sha256': installed, 'native_matches_qualified_release': True,
        'verification': {'path_resolves_to_installed_files': True, 'formatter_check_build': True,
                         'installed_cli_and_native_wasm_match_staged': True, 'bundled_guide_matches': True,
                         'wasm_sha256': staged['wasm_sha256'], 'execution': execution,
                         'cwd': str(cwd), 'commands': results},
    }
    (stage / 'installed.json').write_text(json.dumps(record, indent=2) + '\n')
    print(json.dumps({'installed': installed, 'execution': execution, 'backup': str(backup)}, indent=2))
except BaseException:
    for name in ['blot', 'blotc']:
        atomic_copy(backup / name, target / name)
    raise
