Base checkout: e2fe7ac3e6ffb956e90f52419c0c9723149101a3. All patches
apply with git apply from that repository. broad.patch and guarded.patch
are independent candidates against the same base. Build either with
deno task build:compiler. Use the source and compiler fingerprints in the
adjacent measurement JSON and the ordinary time_gdev_parse.ts runner.

The optional oracle.patch applies on top of broad.patch. It restores eager
normalization and compares each admitted signature recursively in its own
store. Link oracle.c with the native compiler and supply BLOT_CURSOR_LOG
to the compiler process. The sixteen integer columns are module, usage,
scoped, editor, cases, selected uses, reflection, holes, then total,
eligible, mismatch and allocated node counts for expressions and dispatch.
The ordinary released build has no instrumented calls.

core-witness.patch applies to the guarded source and selects the direct
Core collision test as its Goose entry. Compile this entry using the
patched Goose compiler with -O0, its stdlib and a standalone native link
as in compiler-goose/tools/test_engines.py. Two lookups reach the same
function through different cursor positions. The test exercises both orders
of type/row writes and compares actual Core output to eager resolution.
late-row-witness.patch is an alternative witness on the guarded source. It
publishes a type with an open row, writes the row, and compares both Core
readers. Its assertion requires the divergence to be present. It models a
store operation and is not evidence of a triggering source program.
settled.patch and stable-tails.patch apply independently to the base. Both use
the release Core reader. The former requires ground leaves and physical closed
rows outside a certified closed type. The latter also admits principal variables
with no prior writes and empty rows with no applicable write.
resolution_views.goose also runs the store-level historical cursor, depth
and proof-budget checks via the normal engine-law runner.

Run unification.py from the release source root after building the compiler. It creates build/cursor-core/unify and a module table whose columns are described in the measurement JSON.
