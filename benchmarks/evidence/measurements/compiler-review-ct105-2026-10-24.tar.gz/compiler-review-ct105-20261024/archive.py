from pathlib import Path
import hashlib
import io
import json
import tarfile

root=Path('/home/mewhhaha/src/blot2')
out=root/'build/bench/compiler-review-ct105-20261024'
destination=root/'zig-native/measurements/compiler-review-ct105-2026-10-24.tar.gz'
files=[]
for p in sorted(out.rglob('*')):
    if not p.is_file() or 'control-0' in p.parts or p.name.startswith('probe-') or p.name=='blotc-ptracer': continue
    if p.suffix not in ('.py','.ts','.json','.jsonl','.log','.txt'): continue
    files.append(p)
prefix='compiler-review-ct105-20261024'
manifest=''.join(hashlib.sha256(p.read_bytes()).hexdigest()+'  '+str(p.relative_to(out))+'\n' for p in files).encode()
with tarfile.open(destination,'w:gz') as archive:
    for p in files: archive.add(p,arcname=prefix+'/'+str(p.relative_to(out)),recursive=False)
    info=tarfile.TarInfo(prefix+'/SHA256SUMS');info.size=len(manifest);info.mode=0o644
    archive.addfile(info,io.BytesIO(manifest))
sha=hashlib.sha256(destination.read_bytes()).hexdigest()
destination.with_suffix('.gz.sha256').write_text(sha+'  '+destination.name+'\n')
with tarfile.open(destination,'r:gz') as archive:
    for line in archive.extractfile(prefix+'/SHA256SUMS').read().decode().splitlines():
        digest,name=line.split('  ',1)
        assert hashlib.sha256(archive.extractfile(prefix+'/'+name).read()).hexdigest()==digest,name
print(json.dumps({'path':str(destination.relative_to(root)),'files':len(files),'bytes':destination.stat().st_size,'sha256':sha,'internal_hashes_verified':True},indent=2))
