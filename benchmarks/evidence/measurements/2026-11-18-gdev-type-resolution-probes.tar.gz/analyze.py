from statistics import median
from pathlib import Path
import json
d=Path('build/resolve-hill')
def trace(folder):
 rows=[list(map(int,l.split())) for l in (folder/'keys.log').read_text().splitlines()]
 assert len(rows)==len(set(r[0] for r in rows))==269
 result={}
 for i,stage in enumerate(['root','depth','node']):
  types={}
  for j,name in enumerate(['primitive','closed','variable','projectedComposite','openComposite']):
   types[name]=dict(zip(['visits','repeatedExact','repeatedIgnoringDepth','atDepthZero','atCursorZero','usesProjections'],(sum(r[1+(i*5+j)*6+k] for r in rows) for k in range(6))))
  result[stage]={**types,'all':{k:sum(t[k] for t in types.values()) for k in types['closed']}}
 return result
def read(name):return [json.loads(line) for line in (d/(name+'.jsonl')).read_text().splitlines()]
def summarize(rows,key,step='fresh'):
 r=[x for x in rows if x['step']==step];by={m:{x['round']:key(x) for x in r if x['mode']==m} for m in ('before','after','memo')}
 rounds=sorted(set.intersection(*[set(x) for x in by.values()]));assert rounds
 values={m:[v[i] for i in rounds] for m,v in by.items()}
 def cmp(a,b):
  saved=[x-y for x,y in zip(values[a],values[b])];return {'medianWithinPairSaved':round(median(saved),3),'wins':sum(n>0 for n in saved)}
 return {'rounds':len(rounds),'medians':{m:round(median(v),3) for m,v in values.items()},'shippingVsPrevious':cmp('before','after'),'memoVsShipping':cmp('after','memo'),'memoVsPrevious':cmp('before','memo')}
if __name__=='__main__':
 for d0 in (d,d/'after-trace'):
  if (d0/'keys.log').exists():
   try:t=trace(d0);print(d0,[(s,t[s]['all']['visits'],t[s]['all']['repeatedExact']) for s in t])
   except AssertionError:pass
 for n in ['cold','edits','profile']:
  if not (d/(n+'.jsonl')).exists():continue
  rows=read(n)
  for step in dict.fromkeys(x['step'] for x in rows):
   try:print(n,step,summarize(rows,lambda x:x['ms'],step))
   except AssertionError:pass
  if n=='profile' and len(rows)>=3:
   for label,f in [('check',lambda x:x['profile']['phases']['check']['us']/1000),('workerCPU',lambda x:x['profile']['checking']['parallel_worker_cpu_us']/1000),('resolveVisits',lambda x:x['profile']['checking']['normalization']['resolve_depth_entries'])]:print(label,summarize(rows,f))

def direct(rows,step):
 records={m:{r['round']:r['ms'] for r in rows if r['mode']==m and r['step']==step} for m in ['before','after']}
 assert set(records['before'])==set(records['after']) and records['before']
 deltas=[records['before'][k]-records['after'][k] for k in records['before']]
 return {'pairs':len(deltas),'medians':{m:round(median(v.values()),3) for m,v in records.items()},'pairedMedianSavedMs':round(median(deltas),3),'wins':sum(x>0 for x in deltas)}
