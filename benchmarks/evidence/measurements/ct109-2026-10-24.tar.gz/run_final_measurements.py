from pathlib import Path
import hashlib,json,os,subprocess,time
root=Path('/home/mewhhaha/src/blot2'); bench=root/'build/bench/ct109'
read=lambda p:json.loads(p.read_text())
assert read(bench/'qualification-work/blot2/build/bench/ct109-final-gate-3/timings.json')['success']
for name,digest in read(bench/'candidate-10-inputs.json').items():
 assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
common=['--baseline','build/bench/ct109/baseline-blotc','--candidate','build/bench/ct109/candidate-10-blotc','--snapshot','build/bench/compile-cost-20261023/snapshot','--manifest','build/bench/compile-cost-20261023/manifest.json']
commands=[
 ('final-pairs',['deno','task','bench:compile',*common,'--runs','7','--workload','game,devtools','--scenarios','literal_in_body,body_change','--hashes','build/bench/ct103/wasm.json','--guard-cpu','--out','build/bench/ct109/final-pairs']),
 ('review-pairs-final',['deno','task','bench:compile',*common,'--runs','3','--workload','review','--hashes','build/bench/ct103/wasm.json','--out','build/bench/ct109/review-pairs-final']),
 ('review-execution',['deno','run','-A','build/bench/ct109/verify_review_execution.ts']),
 ('memory-final',['deno','run','-A','scripts/bench/session_memory.ts',*common,'--edits','200','--control-every','20','--out','build/bench/ct109/memory-final']),
 ('pair-ranges',['python3','build/bench/ct109/summarize_pairs.py','final-pairs','review-pairs-final'])
]
env=dict(os.environ,TMPDIR=str(bench/'tmp')); records=[]
for name,command in commands:
 start=time.monotonic();print('Starting '+name,flush=True)
 with (bench/(name+'.log')).open('x') as log:
  result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 records.append({'name':name,'command':command,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start})
 (bench/'final-measurement-runs.json').write_text(json.dumps(records,indent=2)+'\n')
 print(f'{name}: exit {result.returncode}',flush=True)
 if result.returncode:raise SystemExit(result.returncode)
print('All final measurements completed',flush=True)
