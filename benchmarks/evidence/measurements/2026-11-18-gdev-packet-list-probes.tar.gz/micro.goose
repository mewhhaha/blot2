import support.project_packet;
import support.error;
import support.native;
import check.types;

fn checksum(bytes:const u8[:],count:i64)->u64 {
    var reader = blot_project_packet::Reader {bytes, default<blot_project_packet::Owner>()};
    var sum:u64 = 0;
    for i in count {
        var value = blot_check_types::List {..};
        blot_project_packet::get(reader, value);
        sum += value.start as u64 + value.len as u64;
    }
    assert(reader.failure == blot_error::Error.none && reader.at == bytes.len);
    return sum;
}
reusable[] var inputs:u8[>..];
fn main() {
    let count:i64 = 262144;
    var packet:u8[>..<] = [];
    var writer = blot_project_packet::Writer {packet};
    let start = blot_native::clock_ns();
    for i in count {
        let bits = (i as u64 * 2654435761) as! u32;
        blot_project_packet::put(writer, blot_check_types::List {bits, bits ^ 0xa55a3cc3});
    }
    let encoded = blot_native::clock_ns();
    assert(writer.failure == blot_error::Error.none && packet.len == 8 * count);
    let input = inputs.alloc_slice(packet.len);
    for byte,i in packet {input[i]=byte;}
    let readStarted = blot_native::clock_ns();
    let sum = checksum(input,count);
    let decoded = blot_native::clock_ns();
    print(encoded - start); print(decoded - readStarted); print(sum);
}
