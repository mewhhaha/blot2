from pathlib import Path
import json
root=Path('/home/mewhhaha/src/blot2');out=root/'build/bench/ct102'
s=json.loads((out/'summary.json').read_text());q=s['qualification'];assert all(s['targets'][k] for k in ['literal_gain','unaffected_game','unaffected_devtools','unaffected_body'])
native=q['phases']['native-run'];total=q['wall_seconds'];guests=q['guests'];laws=q['native']
def insert(path,block):
 p=root/path;t=p.read_text();head,rest=t.split('\n',1);p.write_text(head+'\n\n'+block.strip()+'\n'+rest)
checkpoint=f'''CT102 checkpoint, 24 October 2026: [qualified partial call-memo replay](zig-native/CT102_QUALIFICATION.md)
reduces retained literal-edit CPU by **25.1%** in seven alternating pairs against
CT97. Literal-edit wall medians are 8.63 → 5.93 s; body edits remain about 6.83 s
in the candidate. Shared-host load causes wide ranges; use the paired CPU
comparison rather than interpreting independent wall medians as speedups.
Fresh game/devtools and body-edit CPU guards pass, and every fresh/edit/revert/
restart Wasm comparison is exact. The full gate passes {laws:,} exhaustive native
laws, {guests:,} guest checks, 48 smoke checks and 57 tooling checks with zero Zig
lint findings. Native execution takes {native:.2f} s and the full gate {total:.2f} s
in this interval. The expanded development cycle takes 35.36 s.

The change keeps a source/input-proven empty principal result while omitting
optional call memo outputs that cannot pass the unchanged importer. Ordinary
checking handles those calls. The largest literal-edit region is now reused;
two large regions remain. A separate profile measures literal inference at
5.22 → 3.20 s and body inference at about 5.13 s. First-edit checking takes
0.92 s, later revisions about 0.07 s. Sub-second editing remains open; follow
CT103 and CT104 in [the current queue](COMPILE_HILLS.md). Concurrent text and
guest-runtime changes remain preserved outside this isolated candidate.
'''
insert('CONTINUE.md',checkpoint)
insert('zig-native/STATUS.md','## Principal call-memo replay, 24 October 2026\n\n'+checkpoint.replace('(zig-native/CT102_QUALIFICATION.md)','(CT102_QUALIFICATION.md)').replace('(COMPILE_HILLS.md)','(../COMPILE_HILLS.md)'))
insert('COMPILE_MEASUREMENTS.md',f'''Latest qualification: [CT102 principal replay](zig-native/CT102_QUALIFICATION.md).
Seven alternating pairs show **25.1% less retained literal-edit CPU** against
CT97, with exact outputs and unchanged fresh/body CPU within the 5% guard.
Candidate literal/body wall medians are 5.93 / 6.83 s; the shared-host ranges are
wide and sub-second editing remains open. The full gate passes {laws:,} exhaustive
native laws and {guests:,} guest checks. First-edit checking and steady revisions
are reported separately. The earlier measurements below remain historical.
''')
p=root/'FINISH_PLAN.md';t=p.read_text();needle='## Execution checkpoint, 24 October 2026\n';assert needle in t;t=t.replace(needle,needle+'\n'+checkpoint+'\n',1);p.write_text(t)
p=root/'README.md';t=p.read_text();start=t.index('The [compile measurements]');end=t.index('For a smaller development check',start);t=t[:start]+f'''The [compile measurements](COMPILE_MEASUREMENTS.md) separate application compile
cost from building and checking the compiler. The
[latest optimization](zig-native/CT102_QUALIFICATION.md) reduces retained gdev
literal-edit CPU by **25.1%** against CT97 in seven alternating pairs, with
identical Wasm. Candidate literal/body wall medians are 5.93 / 6.83 s in this
shared-host run; sub-second editing remains open. Fresh-build and body-edit CPU
stay within the 5% regression guard. The full gate passes {laws:,} exhaustive
native laws and {guests:,} guest checks. The expanded development cycle takes
35.36 s, including a 2.57 s compiler build; native qualification takes
{native:.2f} s. These are individual cycle observations, not p95 estimates.
Keep stable writable Zig caches; the measured incremental mode did not improve
real edits. Use `deno task bench:compiler-build --out build/bench/build-next`
for isolated build/edit/revert measurements. See the
[compile hills](COMPILE_HILLS.md), [build hills](BUILD_HILLS.md) and
[performance review](PERFORMANCE_REVIEW.md) for remaining costs and targets.

'''+t[end:];p.write_text(t)
p=root/'zig-native/README.md';t=p.read_text();start=t.index('[CT97 and the reuse/scratch follow-up]');end=t.index('`blotc build ENTRY',start);t=t[:start]+f'''[CT102 principal replay](CT102_QUALIFICATION.md) reduces retained literal-edit
CPU by 25.1% against CT97 in seven alternating release pairs, with identical
Wasm. Candidate literal/body wall medians are 5.93 / 6.83 s on the shared host;
sub-second editing remains open. The full gate passes {laws:,} exhaustive native
laws and {guests:,} guest checks. The expanded development cycle takes 35.36 s;
full native execution takes {native:.2f} s. These are individual observations.
The [review](../PERFORMANCE_REVIEW.md) separates first-edit frontend work from
steady inference and records the next exact reuse boundaries to investigate.

'''+t[end:];p.write_text(t)
p=root/'BUILD_HILLS.md';t=p.read_text();start=t.index('Current status:');end=t.index('| Hill ',start);t=t[:start]+f'''Current follow-up: [CT102](zig-native/CT102_QUALIFICATION.md) keeps ordinary
Safe/noLLVM development builds. Its expanded static-sharing cycle passes in
35.36 s: compiler build 2.57 s, complete native compilation 15.50 s, sampled
native execution 0.91 s, with the additional retained-proof and executed-Wasm
laws. Actual LLVM release construction takes 254.61 s. Full native execution
takes {native:.2f} s and the complete gate {total:.2f} s. These individual intervals
are not paired compiler-build or whole-gate improvements; no build hill closes
from this batch. BT2 remains negative and BT4's previous scratch-size trials
remain complete. The historical CT97 scratch reduction (44,074 → 37,930 exhaustive
scenario runs) and its unresolved halving/whole-gate targets remain unchanged.

'''+t[end:];t=t.replace('Final LLVM release takes 196.47 s;', 'Latest actual LLVM release takes 254.61 s (CT97 observed 196.47 s in a different interval);');p.write_text(t)
p=root/'COMPILE_HILLS.md';t=p.read_text();historical=t[t.index('## Historical program: CT1–CT94'):];p.write_text('''# Compile-time hills

## Current queue: ordinary edits toward one second (24 October 2026)

[CT102 is qualified](zig-native/CT102_QUALIFICATION.md): seven alternating pairs
show **25.1% less literal-edit CPU** against CT97, with exact Wasm and full
qualification. Candidate literal/body wall medians are 5.93 / 6.83 s, with wide
shared-host ranges. Fresh game/devtools and body-edit CPU pass the 5% regression
guard. The largest literal-edit principal region is reused, with 12,134 call
proofs translated and 253 omitted for ordinary checking. No validation limit or
source/input gate is weakened. Sub-second ordinary edits remain open.

The user prioritizes ordinary edits and rebuilds. Separate the first edit after
population from later previously unseen edits and from reverts. A single matched
profile measures first-edit checking at 0.92 s / 6.55 million allocations, later
checking at about 0.07 s, and remaining inference at 3.20 s for a literal edit /
5.13 s for a body edit. Existing code replay alone does not remove that inference.

| Hill | Current evidence and next action | Acceptance target |
| --- | --- | --- |
| CT95–CT97: measurement, spawn preparation and effect rows | Complete; preserve the frozen workload/settings and the dated qualification records. | Do not rerun the historical program or weaken output/fault checks. |
| CT98: ordinary edit reuse | Executable capacity is fixed; CT102 removes another literal-region rebuild. Body changes still rebuild the three large regions. | Original combined literal/body targets remain open: at least 50% cheaper than CT96, then under 4 s wall. Do not multiply ratios from different intervals into a new measured claim. |
| CT99: constants | The matched literal profile spends 0.217 s in constant preparation. | Deferred until eligible cost exceeds 10% of whole-build CPU. |
| CT100: first-edit and fresh frontend allocation | First literal edit still makes 6,553,820 checking allocations; later revisions check in about 70 ms. Attribute allocation callers and cutoff/replay work before changing ownership. | At least 25% fewer check allocations and 20% less check time, without whole-build CPU regression. Preserve current interface and invalidation checks. |
| CT101: combined qualification | Fresh CPU is unchanged by CT102 within the guard. Previous 12 s milestone is met; the 8 s milestone remains open. | Seven paired comparisons, <=5% unaffected CPU regression, exact fresh/edit/revert/restart outputs, full exhaustive gate and zero lint. |
| CT102: keep admitted results when optional memo outputs decline | Complete: the 128-level importer limit rejected one output and previously discarded the whole empty result. Omit only untranslatable memo outputs; keep their calls fresh. | Met: >=10% less literal CPU, <=5% unaffected regression, ownership/failure/execution laws and full gate. The disproved work-budget/height-cache prototype was removed. |
| CT103: reuse the remaining principal regions | Literal region 20 returns nonempty row facts; region 24 lacks a complete input key. Body edits also fail the complete source image. Trace actual consumed call proofs and result ownership before extending either boundary. | At least 20% less retained edit CPU; progress toward both edit classes below 4 s. Require exact changed-type/effect/catalog rejection, errors/recovery, fresh parity and full OOM. |
| CT104: attribute residual inference and reach the iteration budget | Profile the actual candidate after CT102. Measure a sequence of unseen literal/body edits separately from first edits and cached reverts; identify repeated selected-body work before altering cache/index/inline policy. | First get both ordinary edit classes below 2 s, then below 1 s on a documented quiet host. Report CPU and wall distributions and preserve complete outputs and qualification. |

For each experiment, record the hypothesis and acceptance threshold first. If
two bounded experiments miss the target, stop that approach and retain the
negative evidence. Measure before widening semantic admission or adding
parallelism. The [performance review](PERFORMANCE_REVIEW.md) explains the
current boundaries. CT1–CT94 below are historical, not a queue to rerun.

'''+historical)
p=root/'PERFORMANCE_REVIEW.md';t=p.read_text();_,rest=t.split('\n',1);p.write_text('''# Performance hills toward sub-second edits

[CT102 is qualified](zig-native/CT102_QUALIFICATION.md). Seven alternating pairs
show **25.1% less retained literal-edit CPU** against CT97. The first saved call
proof rejection was a depth bound (128), with 999,809 work units still available;
the proposed shared-graph work-budget fix was therefore removed. Keeping the
independently admitted empty result while omitting unsupported optional memo
outputs removes the largest rebuilt literal-inference region. The original
source, input, type/depth and executable checks stay in force.

The single matched phase comparison measures literal inference at 5.22 → 3.20 s
and backend time at 6.77 → 4.76 s. Two large principal regions remain (0.955 and
0.493 s), and other inference work remains too. The body edit still runs the
three large regions and takes about 5.13 s in inference. Its image has changed;
CT102 provides no new body-source admission. The six projected decline counters
now distinguish unsupported results, missing recordings, changed inputs/images,
wrong owners and failed import preparation.

Prioritize CT103's remaining principal result/input boundary and CT104's residual
inference profile for ordinary iteration. A nonempty result needs owned type/row
translation; a region that consumes earlier call proofs needs an exact recorded
input key. Neither can be inferred safe merely from unchanged surface types.
Keep changed-type/effect/catalog failures and ordinary fresh checking as oracles.

Frontend checking needs a separate first-edit investigation: the first literal
edit takes 0.918 s and 6,553,820 allocations, while subsequent revert/body checks
take about 0.07 s. A sequence of previously unseen edits must establish whether
that fast frontend path holds during ordinary work. Constants (0.217 s), lookup
(0.420 s) and replay (0.068 s) are smaller measured costs; these scoped clocks
must not be added to overlapping inference/region clocks.

Sub-second ordinary edits are not achieved. Candidate literal/body wall medians
are 5.93 / 6.83 s in the seven-pair run, with broad shared-host ranges. The
completed full gate and raw measurements are linked above. The dated reviews
below explain earlier decisions and are historical evidence.
'''+rest)
print('Updated current documentation; historical sections preserved.')
