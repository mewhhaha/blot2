from pathlib import Path
import subprocess,time,json,hashlib
root=Path('/home/mewhhaha/src/blot2');base=root/'build/bench/ct103';src=base/'integration-src'
assert subprocess.check_output(['zig','version'],text=True).strip()=='0.17.0'
start=time.monotonic()
with (base/'integration-release.log').open('w') as log:r=subprocess.run(['deno','task','build:compiler'],cwd=src,stdout=log,stderr=subprocess.STDOUT)
record={'exit_code':r.returncode,'seconds':time.monotonic()-start}
if r.returncode==0:
 p=src/'zig-native/zig-out/bin/blotc';record.update(path=str(p),sha256=hashlib.sha256(p.read_bytes()).hexdigest())
(base/'integration-release.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record),flush=True)
if r.returncode:raise SystemExit(r.returncode)
with (base/'integration-driver.log').open('w') as log:r=subprocess.run(['python3',str(base/'integrate.py')],cwd=root,stdout=log,stderr=subprocess.STDOUT)
print('Final integration exit',r.returncode,flush=True)
raise SystemExit(r.returncode)
