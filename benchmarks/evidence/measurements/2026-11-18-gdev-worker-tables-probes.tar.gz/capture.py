from pathlib import Path
import json,os,sys,subprocess
d=Path('build/core-packets').resolve()
dest=d/sys.argv[1];dest.mkdir(exist_ok=True)
if dest.name not in ('input','new-input'):raise ValueError(dest)
cmd=json.loads(Path('compiler-goose/build/stages/compile-and-link-program.json').read_text())['command']
cmd[cmd.index('-O2')]='-O0'
cmd[-1]=str(d/'capture')
cmd.insert(-2,str(d/'capture.c'))
cmd.insert(-2,'-Wl,--wrap=blot_persist_publish')
subprocess.run(cmd,check=True)
w=d/'capture-run'
w.write_text('#!/bin/sh\nexport BLOT_PACKET_SAMPLES="'+str(dest)+'"\nexec "'+str(d/'capture')+'" "$@"\n');w.chmod(0o755)
subprocess.run(['deno','run','-A','scripts/integration/build_gdev.ts','--compiler',w,'--timeout-ms','45000',d/(dest.name+'-wasm')],check=True)
