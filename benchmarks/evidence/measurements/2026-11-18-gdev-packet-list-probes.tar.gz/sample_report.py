"""Match sampled release and candidate instruction addresses to emitted packet codecs."""
from collections import Counter
from pathlib import Path
import bisect,json,re,struct,subprocess
d=Path('build/packet-list');rows=lambda p:[json.loads(line) for line in p.read_text().splitlines()]
cases={'release':(Path('build/resolve-hill/candidate'),Path('build/function-pairs/cpu/release.c')),'candidate':(d/'compiler',Path('compiler-goose/build/blot_goose.c'))}
result={};raw={}
for name,(exe,source) in cases.items():
 table={}
 for line in subprocess.check_output(['nm','-nS',str(exe)],text=True).splitlines():
  m=re.fullmatch(r'([0-9a-f]+) ([0-9a-f]+) [tTwW] (\S+)',line)
  if m:table[int(m[1],16)]=(int(m[2],16),m[3])
 starts=sorted(table);sig={}
 for line in source.open():
  hit=re.match(r'static void (blot_project_packet_(?:get|put)_g\d+(?:_\d+)*)\(([^;]+)\);',line)
  if hit:sig[hit[1]]=hit[2].split(', ')[1].split(' ')[0].removeprefix('r_')
  if sig and line.startswith('    '):break
 data=[];raws=[];symbols=Counter()
 for p in sorted((d/'samples'/name).glob('pc.*'),key=lambda p:p.stat().st_mtime_ns):
  counts=Counter(struct.iter_unpack('<III',p.read_bytes()));list_samples=0;codec_samples=0
  for (pid,kind,addr),amount in counts.items():
   if kind!=0:continue
   i=bisect.bisect_right(starts,addr)-1
   if i<0:continue
   size,sym=table[starts[i]]
   if addr>=starts[i]+size or not re.fullmatch(r'blot_project_packet_(get|put)_g\d+(_\d+)*',sym):continue
   assert sym in sig,sym
   symbols[(sym,sig[sym])]+=amount;codec_samples+=amount
   if re.fullmatch(r'blot_check_types_List_g\d+',sig[sym]):list_samples+=amount
  data.append(dict(all=counts.total(),processes=len({i[0] for i in counts}),typeList=list_samples,packet=codec_samples))
  raws.append([list(k)+[v] for k,v in sorted(counts.items())])
 assert len(data)==8 and min(r['processes'] for r in data)>=8
 raw[name]=raws
 result[name]=dict(totals={k:sum(r[k] for r in data) for k in ['all','typeList','packet']},runs=data,packetSymbols=[[sym,typ,n] for (sym,typ),n in symbols.most_common()])
 print(name,result[name]['totals'])
(d/'sampled.json').write_text(json.dumps(result,indent=2)+'\n')
(d/'sample-pc.json').write_text(json.dumps(raw,separators=(',',':')))
