from pathlib import Path
import json, statistics as st, hashlib, re, xml.etree.ElementTree as ET
base=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={}
for group in ['final-cold','final-retained','final-phases']:
 report=read(base/group/'results.json')
 assert report['success'] and report['inputs_unchanged'] and not report['unexpected_problems'],group
 rows=[json.loads(s) for s in (base/group/'samples.jsonl').read_text().splitlines()]
 summary={}
 for workload,phase in sorted({(s['workload'],s['phase']) for s in rows}):
  selected=[s for s in rows if s['workload']==workload and s['phase']==phase]
  pairs=[{s['variant']:s for s in selected if s['run']==i} for i in sorted({s['run'] for s in selected})]
  assert all(set(p)=={'baseline','candidate'} for p in pairs)
  entry={'pairs':len(pairs),'paired_cpu_ratios':[p['candidate']['cpu_ms']/p['baseline']['cpu_ms'] for p in pairs if p['baseline']['cpu_ms']>0]}
  entry['paired_cpu_ratio_median']=st.median(entry['paired_cpu_ratios']) if entry['paired_cpu_ratios'] else None
  for variant in ['baseline','candidate']:
   s=[p[variant] for p in pairs]
   entry[variant]={k:{'median':st.median([r[k] for r in s]),'min':min(r[k] for r in s),'max':max(r[k] for r in s)} for k in ['cpu_ms','wall_ms','peak_rss_kib']}
   entry[variant]['backend']=s[-1]['stats']['backend']
   if group=='final-phases':
    entry[variant]['work_median_us']={k:st.median([r['stats']['backendTiming']['work'][k] for r in s]) for k,v in s[-1]['stats']['backendTiming']['work'].items() if isinstance(v,(int,float))}
    entry[variant]['phase_medians']={name:{k:st.median([r['stats']['phaseProfile']['phases'][name][k] for r in s]) for k in values} for name,values in s[-1]['stats']['phaseProfile']['phases'].items()}
  summary[workload+'/'+phase]=entry
 result[group]=summary
cold=result['final-cold']; phases=result['final-phases']; retained=result['final-retained']
inference_ratio=phases['game/fresh']['candidate']['work_median_us']['inference_us']/phases['game/fresh']['baseline']['work_median_us']['inference_us']
result['targets']={'CT97_inference_ratio':inference_ratio,'CT97_met':cold['game/fresh']['paired_cpu_ratio_median']<=.9 and inference_ratio<=.75,'unaffected_devtools':cold['devtools/fresh']['paired_cpu_ratio_median']<=1.05,'CT98_half_cpu':all(retained['game/edit:'+s]['paired_cpu_ratio_median']<=.5 for s in ['literal_in_body','body_change']),'CT98_under_four_seconds':all(retained['game/edit:'+s]['candidate']['wall_ms']['median']<4000 for s in ['literal_in_body','body_change'])}
gate=read(base/'final-gate/timings.json'); native=read(base/'final-gate/native-execution/results.json')
assert gate['success'] and not gate['active'] and native['success'] and native['allocation_failures']=='full'
pmap={p['name']:p for p in gate['phases']}; assert all(p['code']==0 for p in pmap.values())
nrun=Path(next(p for p in native['artifacts'] if p.endswith('inventory.stdout.log'))).parent
laws=[json.loads(l.split('\t',1)[1]) for p in nrun.glob('shard-*.stderr.log') for l in p.read_text().splitlines() if l.startswith('BLOT_NATIVE_TEST\t')]
assert len(laws)==len({r['name'] for r in laws})==2540
assert all(r['status']=='passed' and r['allocation_failures']=='full' and not r['leaks'] and not r['logged_errors'] for r in laws)
def cases(name):
 rows=list(ET.parse(Path(pmap[name]['stdout']).parent/(name+'.junit.xml')).iter('testcase'))
 assert rows and all(all(c.find(k) is None for k in ['failure','error','skipped']) for c in rows)
 return len(rows)
result['qualification']={'native':len(laws),'guests':cases('guests'),'smoke':cases('smoke'),'harness':int(re.findall(r'ok \| (\d+) passed \| 0 failed',Path(pmap['harness']['stdout']).read_text())[-1]),'wall_seconds':gate['wall_seconds'],'phases':{n:p['wall_seconds'] for n,p in pmap.items()},'top_native':sorted(laws,key=lambda r:r['duration_ns'],reverse=True)[:10]}
for name,h in read(base/'final-inputs.json')['files'].items():assert sha(base/'final-src'/name)==h,name
result['pins']=read(base/'final-binaries.json');result['release_build']=read(base/'final-release.json')
screen=read(base/'native-screen/results.json')
assert len(screen['variants'])==2
screen_sums={v['variant']:{'cpu_seconds':sum(t['cpu_seconds'] for t in v['tests']),'wall_seconds_sum':sum(t['wall_seconds'] for t in v['tests'])} for v in screen['variants']}
result['native_screen']={'sums':screen_sums,'cpu_ratio':screen_sums['candidate']['cpu_seconds']/screen_sums['baseline']['cpu_seconds'],'wall_ratio':screen_sums['candidate']['wall_seconds_sum']/screen_sums['baseline']['wall_seconds_sum'],'qualification':'single same-session screen; not whole-gate acceptance'}
result['targets']['BT4_half_three_laws_screen']=result['native_screen']['wall_ratio']<=.5
(base/'final-summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'targets':result['targets'],'qualification':result['qualification']},indent=2))
