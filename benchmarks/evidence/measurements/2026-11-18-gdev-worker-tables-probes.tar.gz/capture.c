#include <stdbool.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
extern bool __real_blot_persist_publish(uint64_t, uint32_t, uint32_t, const uint8_t *, uint64_t);
bool __wrap_blot_persist_publish(uint64_t h, uint32_t id, uint32_t kind, const uint8_t *bytes, uint64_t len) {
    bool published=__real_blot_persist_publish(h,id,kind,bytes,len);
    if (published) {
        const char *dir=getenv("BLOT_PACKET_SAMPLES");
        char path[4096];
        if (!dir || snprintf(path,sizeof path,"%s/%u-%u.bin",dir,id,kind)>=(int)sizeof path) abort();
        FILE *out=fopen(path,"wb");
        if (!out || fwrite(bytes,1,len,out)!=len || fclose(out)) abort();
    }
    return published;
}
