from pathlib import Path
import subprocess,shutil,json,hashlib
root=Path('/home/mewhhaha/src/blot2');src=root/'build/bench/ct103/integration-src';stage=root/'build/install/ct103'
pin=json.loads((root/'build/bench/ct103/integration-release.json').read_text());assert pin['exit_code']==0
assert hashlib.sha256((src/'zig-native/zig-out/bin/blotc').read_bytes()).hexdigest()==pin['sha256']
if (stage/'staged-smoke.json').exists():
 old=stage/'obsolete-before-restart-fix';old.mkdir(exist_ok=True)
 for p in stage.iterdir():
  if p.is_file() and p.suffix in ['.json','.log'] and p.name!='previous-pins.json':shutil.copy2(p,old/p.name)
shutil.copy2(src/'zig-native/zig-out/bin/blotc',stage/'blotc')
commands=[['deno','task','package:pack'],['deno','compile','--allow-read','--allow-write','--allow-run','--allow-env=HOME,XDG_CACHE_HOME,BPM_CACHE_DIR','--include','generated/wasm','--include','generated/compiler','--include','std','--include','compiler/guide.md','--output',str(stage/'blot'),'compiler/installed_cli.ts']]
for i,cmd in enumerate(commands):
 with (stage/f'package-{i}.log').open('w') as log:r=subprocess.run(cmd,cwd=src,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(cmd,r.returncode)
r=subprocess.run(['python3',str(stage/'smoke.py')],cwd=root)
raise SystemExit(r.returncode)
