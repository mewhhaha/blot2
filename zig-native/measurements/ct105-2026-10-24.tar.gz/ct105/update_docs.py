from pathlib import Path
import json
root=Path(__file__).resolve().parents[3];out=root/'build/bench/ct105'
gate=json.loads((out/'gate/timings.json').read_text())
assert gate['success'] and not gate['active']
assert json.loads((out/'release-checks-success.json').read_text())['success']
assert json.loads((root/'build/install/ct105/installed.json').read_text())['native_matches_qualified_release']
wall=gate['wall_seconds'];native=next(x['wall_seconds'] for x in gate['phases'] if x['name']=='native-run')
p=root/'README.md';s=p.read_text();a=s.index('The [compile measurements]');b=s.index('For a smaller development check',a)
s=s[:a]+'''The [latest performance changes](zig-native/CT105_QUALIFICATION.md) reduce
frozen gdev fresh-build CPU by **13.3%**, body-edit CPU by **12.9%** and
literal-edit CPU by **3.3%** against `5cfb411` in seven alternating release
pairs, with identical Wasm. Shared-host wall medians are 8.33 s fresh, 4.16 s
first literal, 3.10 s literal revert and 5.42 s body edit. The 10% literal-CPU
and sub-second editing targets remain open. Scope indexing, row certificates,
worklist masks, exact frontend indexes and cache fixes remove repeated work;
four body regions and first-edit graph correspondence still need attention.
The report records memory costs, unseen/fresh controls, exhaustive qualification
and the disposition of all 50 observations in the preceding
[CPU/memory audit](PERFORMANCE_REVIEW.md#current-cpu-memory-and-algorithm-audit--24-october-2026).

The matching release CLI and native compiler are installed locally. The
expanded Safe/noLLVM development cycle takes 21.28 s, including a 3.31 s
compiler build and 5.91 s complete native compilation. These are individual
observations, not p95 estimates or paired compiler-build gains. Keep stable
writable Zig caches; the measured incremental mode did not improve real edits.
Use `deno task bench:compiler-build --out build/bench/build-next` for isolated
build/edit/revert measurements. The [compile measurements](COMPILE_MEASUREMENTS.md),
[compile hills](COMPILE_HILLS.md), [build hills](BUILD_HILLS.md) and
[performance review](PERFORMANCE_REVIEW.md) separate completed work from the
remaining targets.

'''+s[b:];p.write_text(s)
p=root/'CONTINUE.md';s=p.read_text();s=s.replace('CT103/CT104 checkpoint, 24 October 2026:','Historical CT103/CT104 checkpoint, 24 October 2026:',1)
intro=f'''CT105 checkpoint, 24 October 2026:
[solver scans, row certificates and exact catalog indexes are qualified](zig-native/CT105_QUALIFICATION.md).
Seven alternating release pairs against `5cfb411` reduce fresh-game CPU by
**13.3%**, body-edit CPU by **12.9%** and first-literal CPU by **3.3%**. Devtools
stays within the 5% guard. All strict fresh/edit/revert/restart Wasm pins and
unseen-edit fresh controls pass. Shared-host wall medians are 8.33 / 4.16 /
3.10 / 5.42 s for fresh / first literal / literal revert / body. The 10%
literal target, two-second edits and sub-second editing remain open.

Per-scope links remove region-wide type-variable scans; dense four-byte row
certificates cut fresh argument visits by 62%. Sorted evidence hits, pending
worklist masks, cache update/failed-plan fixes and removal of a redundant
allocator mutex are implemented. Principal keys own anonymous/module source
observations (archive v7). Frontend identity indexes reach graph correspondence
with budget remaining; the first edit still checks 22 modules. Three body
principals reject module 42's changed input image; one rejects source 42:35's
identity. Keep these exact checks. Residual query work, lookup/encoding and
allocation/working-set attribution remain in [the queue](COMPILE_HILLS.md).

The final gate passes 2,555 exhaustive native laws, the complete guest/tooling
suite and zero Zig lint findings in {wall:.2f} s ({native:.2f} s native execution).
The expanded sampled development cycle passes in 21.28 s (3.31 s compiler,
5.91 s native compilation); it does not replace the exhaustive gate and is not
a paired build-speed claim. The qualified CLI and native compiler are installed
at `~/.local/bin/blot` and `blotc`; external format/check/build, exact Wasm,
answer 29 and bundled guide pass. Native SHA-256:
`0eadf4bb1a0cc7448f59156091a7287e2456aedfd4b31452197a0a3437a1da78`.
Installation/rollback records are in `build/install/ct105/installed.json`.
Raw evidence and the audit disposition table are linked from the qualification
record. Preserve unrelated untracked `zig-native/build/` and `zig-out-modern/`.
The checkpoints below retain their original baselines and installation history.

'''
s=s.replace('# Continue here\n\n','# Continue here\n\n'+intro,1);p.write_text(s)
p=root/'COMPILE_MEASUREMENTS.md';s=p.read_text();s=s.replace('Current diagnostic refresh, 24 October 2026:','Pre-CT105 diagnostic refresh, 24 October 2026:',1).replace('The unchanged installed release measures','The then-installed unchanged release measures',1).replace('Latest qualification:\n','Historical qualification:\n',1)
intro=f'''Latest qualification, 24 October 2026:
[CT105 solver scans, normalization and catalog costs](zig-native/CT105_QUALIFICATION.md).
Seven alternating pairs against `5cfb411` show **13.3% less fresh-game CPU**,
**12.9% less body-edit CPU** and **3.3% less first-literal CPU**, with exact Wasm
and unaffected devtools. The 10% literal target misses; sub-second edits remain
open. Shared-host wall medians are 8.33 s fresh, 4.16 s first literal, 3.10 s
literal revert and 5.42 s body edit. The report includes distributions, source
and binary pins, phase/work counters, memory costs, unseen/fresh/restart controls
and the full gate ({wall:.2f} s). Final native/CLI installation is verified.

The matching profiled pair reduces fresh inference from 5.760 to 4.648 s and
body inference from 4.051 to 3.356 s; literal-revert inference remains 1.259 s.
Dense row certificates remove repeated arguments while adding solver-local
memory: largest region live bytes rise 185.37 → 195.25 MB. Current RSS,
lifetime peaks and logical allocation requests are reported separately. The
21.28 s Safe/noLLVM development cycle includes 3.31 s compiler and 5.91 s full
native compilation. These are observations, not paired build gains or p95.
Historical numbers below preserve their original scope.

'''
s=s.replace('# Compile and compiler-build measurements\n\n','# Compile and compiler-build measurements\n\n'+intro,1);p.write_text(s)
p=root/'BUILD_HILLS.md';s=p.read_text();s=s.replace('Current follow-up: [CT103/CT104]','Historical follow-up: [CT103/CT104]',1)
intro=f'''Current follow-up: [CT105](zig-native/CT105_QUALIFICATION.md) preserves
Safe/noLLVM and runtime native selection. Its affected development cycle passes
in 21.28 s: compiler build 3.31 s, full 2,555-test inventory compilation 5.91 s,
sampled execution 0.77 s. The exhaustive final gate takes {wall:.2f} s, including
{native:.2f} s native execution across four isolated shards. The actual LLVM
release is built separately; the later gate reuses that artifact. These are
individual observations, not paired compiler-build improvements. No BT hill
closes; stable caches, 20-cycle latency measurement, exhaustive-test cost and
LLVM construction remain separate work.

'''
s=s.replace('Historical follow-up: [CT103/CT104]',intro+'Historical follow-up: [CT103/CT104]',1);p.write_text(s)
p=root/'PERFORMANCE_REVIEW.md';s=p.read_text();intro='''## CT105 implementation and qualification — 24 October 2026

[CT105](zig-native/CT105_QUALIFICATION.md) implements the supported scope-scan,
row-certificate, interner fast-path, evidence-sort, worklist, cache and allocator
fixes. Exact frontend indexes replace quadratic correspondence searches;
principal observations now own anonymous/module dependencies. Seven alternating
release pairs against `5cfb411` show 13.3% less fresh-game CPU, 12.9% less body-edit
CPU and 3.3% less first-literal CPU, with unchanged Wasm and full qualification.
The literal 10% target misses. Fresh/body solver live peaks grow about 9.88 MB;
the report includes complete allocation and RSS evidence.

The first-edit comparison now reaches a real graph mismatch with budget
remaining. Four body regions still rebuild on exact source-image/identity
differences. Literal-revert inference is 1.259 s and the non-inference floor is
still about 1.34 s in the matched profile. Sub-second edits require further
work. All 50 audit observations have an explicit disposition in the qualification
record; hardware/retention/parallelism hypotheses are not reported as fixed
bugs. The audit below describes the preceding installed binary and remains the
historical diagnostic baseline.

'''
s=s.replace('# Performance hills toward sub-second edits\n\n','# Performance hills toward sub-second edits\n\n'+intro,1);p.write_text(s)
p=root/'COMPILE_HILLS.md';s=p.read_text();a=s.index('The\n[current CPU/memory audit]');b=s.index('[The four CT103/CT104',a)
s=s[:a]+'''[CT105 is qualified](zig-native/CT105_QUALIFICATION.md): scope scans, row
certificates, worklist wakeups, evidence sorting, cache updates, failed recipe
plans and exact frontend indexes are implemented. Seven alternating pairs
against `5cfb411` show 13.3% less fresh-game CPU, 12.9% less body-edit CPU and
3.3% less first-literal CPU. Devtools stays within the guard, strict outputs and
unseen fresh controls pass, and the exhaustive gate passes. The 10% literal
CPU target misses; two-second and sub-second ordinary edits remain open.

Prioritize (1) exact module-image/source-identity dependencies blocking four body
principals and residual queries after all 20 literal hits, (2) unit 42's first
frontend graph mismatch after indexed catalogs succeed, (3) remaining 9.81
million literal-revert interner candidates and 35.99 million row arguments,
then (4) lookup/encoding and allocation capacity. Preserve the negative results:
faster catalog lookup still checks 22 modules first, and more complete source
observations alone do not grant body reuse. The
[50-observation audit](PERFORMANCE_REVIEW.md#current-cpu-memory-and-algorithm-audit--24-october-2026)
and its CT105 disposition distinguish demonstrated costs from hypotheses.

The comparison and diagnostic sequence below are historical CT103/CT104 evidence.

'''+s[b:]
needle='\nRecord each experiment\'s hypothesis'
idx=s.index(needle)
s=s[:idx]+'''
| New hill | Evidence and next action | Acceptance target |
| --- | --- | --- |
| CT105: repeated solver scans and normalization | Qualified fresh/body CPU reductions; dense certificates lower argument work with about 9.88 MB additional peak region storage. Literal gain is 3.3%. | Fresh/body benefit retained; combined >=10% literal/body target remains open. |
| CT106: residual queries and exact source observations | Four body regions still fail source module/identity checks; literal revert still creates 2,422 regions. Trace equivalent query inputs and the specific changed source subgraphs. | >=20% body CPU and >=10% later-literal CPU reduction, exact fresh/error/restart parity, bounded retention, full OOM. |
| CT107: frontend graph correspondence | Exact producer/catalog indexes leave 60,950 comparisons, then unit 42 declines in graph checking. Record the first graph pair and ownership reason. | First-edit check allocations -25% and checking time -20%; no weakening of graph/contract admission. |
| CT108: remaining non-inference floor | Literal revert retains about 363 ms lookup and 1.34 s outside inference. Attribute candidate/anchor repeats, optimized-body clones, encoding and transport. | Both ordinary edit classes below 2 s, then 1 s, in seven quiet-host pairs with instructions/CPU/wall/current RSS controls. |
'''+s[idx:];p.write_text(s)
print('Updated README, continuation, measurements, review and both hill plans')
p=root/'FINISH_PLAN.md';s=p.read_text();s=s.replace('CT103/CT104 checkpoint, 24 October 2026:','Historical CT103/CT104 checkpoint, 24 October 2026:',1)
checkpoint='''[CT105 is qualified and installed](zig-native/CT105_QUALIFICATION.md).
The audit follow-up removes repeated solver/scoping/cache work and indexes exact
frontend identities. Seven pairs against `5cfb411` reduce fresh-game CPU 13.3%,
body-edit CPU 12.9% and first-literal CPU 3.3%; outputs and the full 2,555-law
exhaustive native/guest gate pass with zero lint. The 10% literal target misses.
Four body regions, first-edit graph correspondence, two-second/sub-second edits
and the broader completion requirements below remain open. Continue from
[CT106–CT108](COMPILE_HILLS.md), preserving exact dependency checks. The
[continuation record](CONTINUE.md) pins the installed binaries and evidence.

'''
s=s.replace('## Execution checkpoint, 24 October 2026\n\n','## Execution checkpoint, 24 October 2026\n\n'+checkpoint,1);p.write_text(s)
p=root/'zig-native/STATUS.md';s=p.read_text();s=s.replace('CT103/CT104 checkpoint, 24 October 2026:','Historical CT103/CT104 checkpoint, 24 October 2026:',1)
idx=s.index('Historical CT103/CT104');s=s[:idx]+checkpoint.replace('(zig-native/CT105_QUALIFICATION.md)','(CT105_QUALIFICATION.md)').replace('(COMPILE_HILLS.md)','(../COMPILE_HILLS.md)').replace('(CONTINUE.md)','(../CONTINUE.md)')+s[idx:];p.write_text(s)
p=root/'zig-native/README.md';s=p.read_text();a=s.index('[Principal dependency reuse and row normalization]');b=s.index('`blotc build ENTRY',a)
s=s[:a]+'''[CT105 solver scans, row certificates and exact frontend indexes](CT105_QUALIFICATION.md)
reduce fresh-game CPU by 13.3%, body-edit CPU by 12.9% and first-literal CPU by
3.3% against `5cfb411` in seven alternating pairs, with identical Wasm. Shared-host
wall medians are 8.33 s fresh, 4.16 s first literal, 3.10 s literal revert and
5.42 s body edit. The 10% literal target and sub-second editing remain open.
The final release passes 2,555 exhaustive native laws, the full guest/tooling
suite and zero Zig lint findings, and both local tools are installed. The
sampled development cycle takes 21.28 s, including 3.31 s compiler construction
and 5.91 s complete native compilation; these are individual observations.
The [review](../PERFORMANCE_REVIEW.md) records the memory tradeoff and remaining
four body rebuilds, first-edit graph mismatch and non-inference costs.

'''+s[b:];p.write_text(s)
print('Updated compiler README/status and completion checkpoint')
p=root/'zig-native/STATUS.md';s=p.read_text();s=s.replace('## Principal dependency reuse and row normalization, 24 October 2026','## Solver scans, row certificates and frontend indexes, 24 October 2026',1);p.write_text(s)
p=root/'DEVELOPMENT_TURNAROUND.md';s=p.read_text();intro=f'''The latest [CT105 static-sharing cycle](zig-native/CT105_QUALIFICATION.md)
passes in 21.28 s: 3.31 s development compiler construction, 5.91 s complete
2,555-law native compilation and 0.77 s sampled native execution, followed by
selected guests and local analysis. The separately qualified exhaustive gate
takes {wall:.2f} s ({native:.2f} s native execution). These are individual host
observations, not paired build gains or p95. The older timings below retain
their original regression families and conditions.

''';s=s.replace('# Five-minute development feedback\n\n','# Five-minute development feedback\n\n'+intro,1)
a=s.index('- The published static-sharing family runs');b=s.index('- Run ',a)
s=s[:a]+'''- The current static-sharing family selects 52 native laws, covering aggregate
  parity and rejection, persistent roots, principal observations, portable archives,
  closure replay, effect-row normalization and fault-policy
  behavior. `--list-areas` and the run's exact selection are authoritative.
'''+s[b:]
s=s.replace('- Run 45 protocol, budget-recovery and selected client edit/error/recovery\n  tests.', '- Run the selected protocol, budget-recovery and client edit/error/recovery\n  guest tests.')
p.write_text(s)
print('Updated development-cycle documentation')
