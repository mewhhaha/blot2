from pathlib import Path
import json
root=Path('/home/mewhhaha/src/blot2');base=root/'build/bench/ct97'
s=json.loads((base/'final-summary.json').read_text());g=s['final-cold']['game/fresh'];d=s['final-cold']['devtools/fresh'];r=s['final-retained'];q=s['qualification'];targets=s['targets'];p=s['final-phases']['game/fresh']
assert targets['CT97_met'] and targets['unaffected_devtools']
pct=lambda ratio:f'{100*(1-ratio):.1f}%'
sec=lambda ms:f'{ms/1000:.2f}'
gain=pct(g['paired_cpu_ratio_median']); wall0=sec(g['baseline']['wall_ms']['median']);wall1=sec(g['candidate']['wall_ms']['median']);cpu0=sec(g['baseline']['cpu_ms']['median']);cpu1=sec(g['candidate']['cpu_ms']['median'])
lit=r['game/edit:literal_in_body'];body=r['game/edit:body_change'];litgain=pct(lit['paired_cpu_ratio_median']);bodygain=pct(body['paired_cpu_ratio_median']);lw=sec(lit['candidate']['wall_ms']['median']);bw=sec(body['candidate']['wall_ms']['median'])
inf0=p['baseline']['work_median_us']['inference_us']/1e6;inf1=p['candidate']['work_median_us']['inference_us']/1e6
native=q['phases']['native-run']; gate=q['wall_seconds']; ref='[qualification record](zig-native/CT97_QUALIFICATION.md)'
core=f'Seven alternating release pairs reduce fresh game CPU by **{gain}** against CT96; median build wall falls from **{wall0} to {wall1} s**, with identical Wasm.'
ret=f'Literal/body edits use {litgain} / {bodygain} less CPU and take {lw} / {bw} s median wall. The 50% edit-CPU and four-second wall targets remain open.'
qualification=f'The isolated full gate passes {q["native"]:,} exhaustive native laws, {q["guests"]:,} guest checks, {q["smoke"]} smoke checks and {q["harness"]} tooling checks, with zero Zig lint findings.'
nextstep='Next, attribute the three large principal-region rebuilds and the remaining frontend allocations. Keep exact source/input/replay checks; executable index capacity is no longer the observed blocker.'
def replace(name,old,new):
 path=root/name;text=path.read_text();assert old in text,(name,old[:60]);path.write_text(text.replace(old,new,1))
def prepend(name,paragraph):
 path=root/name;text=path.read_text();head,body=text.split('\n\n',1);path.write_text(head+'\n\n'+paragraph+'\n\n'+body)
prepend('CONTINUE.md',f'CT97/CT98/BT4 checkpoint, 24 October 2026: {core}\nMatching instrumented inference falls {inf0:.2f} → {inf1:.2f} s, meeting CT97.\nExecutable capture capacity restores thousands of retained function hits. {ret}\nTemporary backend scratch reduces the three slow laws from 44,074 to 37,930\nexhaustive scenario runs; BT4’s halved-law/whole-gate targets remain open.\n{qualification} Native execution takes {native:.2f} s; the complete gate takes\n{gate:.2f} s. These gate intervals are observations, not paired speedup claims.\nThe {ref} pins the source, release, comparisons and raw evidence.\n{nextstep}\nThe separate text-capability changes remain preserved outside this candidate;\nthis work does not replace the locally installed compiler.')
prepend('zig-native/STATUS.md',f'## Row traversal, retained reuse and scratch, 24 October 2026\n\n{core}\nMatching phase measurements reduce inference {inf0:.2f} → {inf1:.2f} s.\n{ret}\nBackend temporary scratch cuts 33 exhaustive sweeps from 44,074 to 37,930 runs.\n{qualification}\nSee [qualification](CT97_QUALIFICATION.md). CT97 is complete; CT98 and BT4\nretain their remaining timing targets. The separate text repair and installed\ntools are outside this candidate.')
replace('FINISH_PLAN.md','## Execution checkpoint, 23 October 2026','## Execution checkpoint, 24 October 2026\n\n'+core+'\n'+ret+'\nThe [new qualification](zig-native/CT97_QUALIFICATION.md) closes CT97 and records\nrestored executable reuse and fewer real backend allocations. CT98, BT4 and the\nbroader completion plan remain open; follow the updated hill tables below.')
oldstart='The [compile measurements](COMPILE_MEASUREMENTS.md) separate application compile'
path=root/'README.md';text=path.read_text();start=text.index(oldstart);end=text.index('\nFor a smaller development check',start)
text=text[:start]+f'''The [compile measurements](COMPILE_MEASUREMENTS.md) separate application compile
cost from building and checking the compiler. The
[latest optimization](zig-native/CT97_QUALIFICATION.md) cuts fresh gdev game CPU
by {gain} against CT96 ({wall0} → {wall1} s median build wall), with identical Wasm.
Literal/body edit wall is {lw} / {bw} s after restoring executable reuse.
The affected development checks take 16.10 s for static sharing and 3.94 s for
types/effects; complete native qualification takes {native:.2f} s. These are
individual check cycles, not p95 estimates. Ordinary compiler edits previously
measured about 3.4 s. Keep stable writable Zig caches; the measured incremental
mode did not improve real edits. Use `deno task bench:compiler-build --out
build/bench/build-next` for isolated build/edit/revert measurements.
See the [compile hills](COMPILE_HILLS.md), [build hills](BUILD_HILLS.md) and
[performance review](PERFORMANCE_REVIEW.md) for remaining targets. The full gate
and seven-pair measurements are recorded in the qualification link above.
'''+text[end:];path.write_text(text)
path=root/'zig-native/README.md';text=path.read_text();start=text.index('[CT96](CT96_QUALIFICATION.md)');end=text.index('\n`blotc build ENTRY',start);text=text[:start]+f'''[CT97 and the reuse/scratch follow-up](CT97_QUALIFICATION.md) reduce fresh game
CPU by {gain} against [CT96](CT96_QUALIFICATION.md), with identical Wasm in seven
alternating release pairs. Game median build wall is {wall1} s; literal/body
edits take {lw} / {bw} s. Complete native qualification takes {native:.2f} s;
affected static-sharing and type-effects checks take 16.10 / 3.94 s.
The [review](../PERFORMANCE_REVIEW.md) retains the remaining principal-inference,
frontend allocation and exhaustive-test targets.
'''+text[end:];path.write_text(text)
prepend('PERFORMANCE_REVIEW.md',f'Follow-up, 24 October 2026: [CT97 and the reuse/scratch changes are qualified](zig-native/CT97_QUALIFICATION.md). {core}\nInference falls {inf0:.2f} → {inf1:.2f} s under matching instrumentation. The executable\nindex saturated at 4,096 records; its separate bounded capacity restores\nthousands of hits. {ret}\nThe three slow laws now execute 37,930 exhaustive scenarios. Their timing target\nremains open. {nextstep}\nThe dated analysis below preserves the evidence that selected these experiments.')
prepend('COMPILE_MEASUREMENTS.md',f'Latest follow-up: [CT97, executable reuse and temporary scratch](zig-native/CT97_QUALIFICATION.md). {core}\nThe original baseline and CT96 measurements below remain historical references;\nuse the latest qualification for current comparisons and remaining targets.')
# Replace the current queue only; preserve the historical CT1–CT94 record.
path=root/'COMPILE_HILLS.md';text=path.read_text();start=text.index('## Current queue:');end=text.index('| Hill ',start)
text=text[:start]+f'''## Current queue: CT95–CT101 (24 October 2026)

CT95, CT96 and **CT97 are complete**. The
[latest qualification](zig-native/CT97_QUALIFICATION.md) records {gain} less
fresh-game CPU against CT96 ({cpu0} → {cpu1} s medians), exact Wasm and the full
compiler gate. Matching instrumented inference falls {inf0:.2f} → {inf1:.2f} s.
The candidate is `build/bench/ct97/final-src/zig-native/zig-out/bin/blotc`.

CT98's complete executable index now has sufficient bounded capacity and reuses
thousands of functions, but {ret}
CT100 and those large retained principal regions are the next measured costs.
CT99 remains deferred. CT101's 12 s CPU milestone is met; its 8 s milestone
{'is met' if g['candidate']['cpu_ms']['median']<8000 else 'remains open'}.
The [review](PERFORMANCE_REVIEW.md) preserves the preceding diagnosis and links
these results. CT1–CT94 below are historical, not a queue to rerun.

'''+text[end:]
rows={
'| CT97:':f'| CT97: bound effect-row resolution in large inference regions | Complete: retained prefixes and birth-checked empty-row shortcuts remove repeated chain walks; largest diagnostic store followed 402 million edges before the change. | {gain} less whole-build CPU and {pct(targets["CT97_inference_ratio"])} less inference wall, exceeding 10% / 25% targets; chronology, rollback, multiplicity and OOM laws pass. |',
'| CT98:':f'| CT98: restore backend reuse for ordinary source edits | The 4,096-record complete-index cap was the blocker; separate 16K-record / 8 MiB capacity restores hits. Literal/body CPU improves {litgain} / {bodygain} in the combined candidate. Three large principal regions still run; trace exact input/image rejection before changing admission. | Still open: at least 50% cheaper literal/body CPU, then under 4 s wall. Current wall {lw} / {bw} s. Keep fresh/edit/revert/restart and rejection/recovery exact. |',
'| CT100:':f'| CT100: reduce frontend allocation and repeated row work | Final matched profile: check takes {p["candidate"]["phase_medians"]["check"]["us"]/1e6:.2f} s and requests {p["candidate"]["phase_medians"]["check"]["allocations"]:,.0f} allocations. Attribute callers and copies against this candidate. | At least 25% fewer checking allocations and 20% less check time, without whole-build CPU regression; distinguish cumulative bytes from peak RSS. |',
'| CT101:':f'| CT101: qualify the combined result and keep the costs visible | Current fresh-game CPU {cpu1} s; 12 s milestone met, 8 s milestone {"met" if g["candidate"]["cpu_ms"]["median"]<8000 else "open"}. | Seven unprofiled pairs, both entries with at most 5% unaffected CPU regression, exact retained/revert/restart outputs, full gate and zero lint. Current candidate passes these checks. |'
}
text='\n'.join(next((replacement for prefix,replacement in rows.items() if line.startswith(prefix)),line) for line in text.split('\n'))
a=text.index("CT96's new profile selects");b=text.index('For each experiment',a);text=text[:a]+'Next, separate retained principal-region work from fresh frontend allocation.\nCapacity is no longer the executable-admission blocker. Constant preparation\nand assembly remain small compared with inference.\n\n'+text[b:];path.write_text(text)
path=root/'BUILD_HILLS.md';text=path.read_text();start=text.index('Current status:');end=text.index('| Hill ',start)
text=text[:start]+f'''Current status: BT1's warm cache-hit target and BT3's observed development-cycle
targets are met; BT2's incremental-mode experiment remains negative. The final
[CT97/reuse/scratch candidate](zig-native/CT97_QUALIFICATION.md) passes affected
static-sharing/type-effects checks in 16.10 / 3.94 s. Those are individual
observations, not p95 claims. BT4's temporary scratch removes real allocations:
33 exhaustive sweeps now require 37,930 scenario runs instead of 44,074.
Its halved-law and paired whole-gate timing targets remain open. Complete native
execution takes {native:.2f} s and the whole gate {gate:.2f} s in this interval;
these are not paired reductions from the previous 665.13 / 761.75 s gate.

'''+text[end:]
lines=[]
for line in text.split('\n'):
 if line.startswith('| BT4:'):line=f'| BT4: reduce exhaustive test cost without reducing coverage | Stack scratch reduces allocation scenarios by 13.9%; all fault positions in the resulting compiler still execute. Current native phase {native:.2f} s. The one-pair top-three screen is in the qualification record. Stop further scratch-size tuning after two bounded trials. | Still open: halve combined top-three cost and show at least 5% paired whole-gate gain; then reprofile toward 480 s native. No sampled substitute for qualification. |'
 if line.startswith('| BT5:'):line=f'| BT5: lower actual release construction cost | Final LLVM release takes {s["release_build"]["wall_seconds"]:.2f} s; the later gate uses that cached release. Release construction remains a separate cost. Collect a detailed Zig time report on the next necessary release. | First milestone below 150 s on this host/configuration, with identical behavior and no application CPU regression. Native unit tests remain Safe/noLLVM. |'
 lines.append(line)
path.write_text('\n'.join(lines))
print('Updated status, README, handoff and hill documents from final measurements.')
