"""Package this measurement campaign's raw evidence, without private source or caches."""
import gzip
import hashlib
import io
import json
from pathlib import Path
import tarfile

repo = Path(__file__).resolve().parents[3]
base = Path(__file__).resolve().parent
def digest(data):
    return hashlib.sha256(data).hexdigest()
def read_json(path):
    return json.loads(path.read_text())
gate_root = repo / 'build/bench/associated-work-fix-20261023'
gate = read_json(gate_root / 'timings.json')
native = read_json(gate_root / 'native-execution/results.json')
laws = []
logs = sorted((gate_root / 'native-execution/run-f199a9f10e1d2c7b').glob('shard-*.stderr.log'))
for path in logs:
    for line in path.read_text().splitlines():
        if line.startswith('BLOT_NATIVE_TEST\t'):
            laws.append(json.loads(line.split('\t', 1)[1]))
assert len(laws) == len({r['name'] for r in laws}) == 2539
assert all(r['status'] == 'passed' and r['allocation_failures'] == 'full' for r in laws)
gate_costs = {
    'source': 'zig-native/measurements/associated-work-2026-10-23.tar.gz',
    'source_archive_sha256': digest((repo / 'zig-native/measurements/associated-work-2026-10-23.tar.gz').read_bytes()),
    'gate_report_sha256': digest((gate_root / 'timings.json').read_bytes()),
    'wall_seconds': gate['wall_seconds'],
    'phases': [{k: r[k] for k in ['name', 'wall_seconds', 'code']} for r in gate['phases']],
    'native_shard_intervals': native['intervals'],
    'slowest_native_laws': sorted(laws, key=lambda r: r['duration_ns'], reverse=True)[:20],
    'note': 'Previously qualified compiler; native and release phases overlap. No qualification key is included.',
}
(base / 'prior-gate-costs.json').write_text(json.dumps(gate_costs, indent=2) + '\n')
print('Slowest native seconds:', [round(r['duration_ns'] / 1e9, 3) for r in gate_costs['slowest_native_laws'][:3]])

iteration = read_json(base / 'iteration-v2/results.json')
samples = iteration['samples']
assert iteration['success'] and len(samples) == 92
assert len({(s['mode'], s['phase'], s['round'], s['target']) for s in samples}) == 92
assert all(s['exit_code'] == 0 for s in samples)
for directory in ['cold', 'retained', 'tool-smoke']:
    result = read_json(base / directory / 'results.json')
    assert result.get('success', True) and result['inputs_unchanged']
    assert not result['unexpected_problems'] and not result['problems']
for directory in ['development-first', 'development-cached']:
    r = read_json(base / directory / 'results.json')
    assert r['success'] and not r['qualifies_release']
    assert r['compiled_native_tests'] == 2539 and len(r['native_tests']) == 12 and len(r['guest_tests']) == 9
assert '57 passed | 0 failed' in (base / 'tool-harness.log').read_text()
identity = read_json(base / 'baseline/identity.json')
assert digest((base / 'baseline/blotc').read_bytes()) == identity['sha256']
assert digest((repo / 'zig-native/zig-out/bin/blotc').read_bytes()) == identity['sha256']
manifest = read_json(base / 'manifest.json')
actual = {str(p.relative_to(base / 'snapshot')): digest(p.read_bytes()) for p in (base / 'snapshot').rglob('*') if p.is_file() and p.name != 'manifest.json'}
assert manifest == actual and len(manifest) == 554

payload = {}
def add(path, name=None):
    assert not path.is_symlink(), path
    payload[name or str(path.relative_to(base))] = path.read_bytes()
for path in base.iterdir():
    if path.is_file() and path.suffix in {'.json', '.jsonl', '.log', '.txt', '.py'}:
        add(path)
add(base / 'baseline/identity.json')
for directory in ['cold', 'retained', 'stacks', 'tool-smoke', 'iteration', 'iteration-v2']:
    for path in (base / directory).iterdir():
        if path.is_file() and path.suffix in {'.json', '.jsonl', '.log', '.txt'}:
            add(path)
for directory in ['development-first', 'development-cached']:
    for path in (base / directory).rglob('*'):
        if path.is_file() and path.suffix in {'.json', '.log', '.xml'}:
            add(path)
tool_files = [
    'deno.json', 'scripts/bench_compile.ts', 'scripts/bench_compile.test.ts',
    'scripts/bench/gdev.ts', 'scripts/bench/costs.ts', 'scripts/bench/snapshot.ts',
    'scripts/bench/profile_compile.ts', 'scripts/bench/gdb_sampler.py',
    'scripts/bench/summarize_stacks.py', 'scripts/bench/compiler_iteration.py',
]
for name in tool_files:
    add(repo / name, 'tools-final/' + name)
metadata = {
    'purpose': 'Compile-cost baseline and compiler-build iteration measurements, 2026-10-23',
    'compiler': identity,
    'snapshot_files': len(manifest),
    'tool_sources': 'tools-final/ contains the final reviewed tooling; raw records preserve run-specific pins where available.',
    'qualification': 'Build/measurement tools only; prior full compiler qualification remains separate.',
    'controls': 'iteration/ is incomplete; iteration-v2/results-before-resume-* preserves the second interrupted control. iteration-v2/results.json is the completed 92-cell run.',
    'paths': 'Raw local paths are retained as provenance; payload names are relative. Private sources, binaries, caches and native qualification keys are excluded.',
    'source_change_after_measurements': 'A separate uncommitted debug-trace edit appeared in reuse/zig_project_server.zig after the completed measurements. It is outside this campaign and not included.',
}
payload['README.json'] = (json.dumps(metadata, indent=2) + '\n').encode()
payload['SHA256SUMS'] = ''.join(f'{digest(data)}  {name}\n' for name, data in sorted(payload.items())).encode()
archive = repo / 'zig-native/measurements/compile-cost-2026-10-23.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as tar:
    for name, data in sorted(payload.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        info.mtime = 0
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive, 'r:gz') as tar:
    names = set(tar.getnames())
    sums = tar.extractfile('SHA256SUMS').read().decode().splitlines()
    assert names == {line.split('  ', 1)[1] for line in sums} | {'SHA256SUMS'}
    for line in sums:
        expected, name = line.split('  ', 1)
        assert digest(tar.extractfile(name).read()) == expected
print(json.dumps({'archive': str(archive.relative_to(repo)), 'files': len(payload), 'bytes': archive.stat().st_size, 'sha256': digest(archive.read_bytes()), 'checks': '92 build cells, 57 harness tests, two 12-native/9-guest development checks, 554 unchanged snapshot files, compiler pin, every archive digest'}))
