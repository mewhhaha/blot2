"""Model module schedules from measured costs; no result is a realized speedup."""
from pathlib import Path
import json, heapq
from statistics import median

work = Path(__file__).resolve().parent
read = lambda p: json.loads(p.read_text())
samples = [read(work / f'profiles/{i}-fresh.json') for i in range(3)]
assert read(work / 'profiles/complete.json')['success']
traces = [s['stats']['phaseProfile']['module_trace'] for s in samples]
assert all(len(t) == 189 and len({r['filename'] for r in t}) == 189 for t in traces)
by_run = [{r['filename']: r for r in t} for t in traces]
assert read(work / 'topology/complete.json')['success']
topology = read(work / 'topology/0-fresh.json')['stats']['phaseProfile']['module_trace']
assert len(topology) == len({r['name_key'] for r in topology}) == len({r['filename'] for r in topology}) == 189
names = {r['name_key']:r['filename'] for r in topology}
nodes = {r['filename']:{**r,'dependencies':[names[dep] for dep in r['dependencies']]} for r in topology}
assert all(set(run)==set(nodes) for run in by_run)
children = {n: [] for n in nodes}
for n,r in nodes.items():
    assert not r['truncated'] and n not in r['dependencies']
    assert all(all(run[n][k] == r[k] for k in ('syntax_nodes','imported_schemes','candidates','type_nodes','free_type_visits','free_row_visits')) for run in by_run), n
    for dep in r['dependencies']:
        assert dep in nodes, (n,dep)
        children[dep].append(n)
order = [r['filename'] for r in traces[0]]
seen=set()
for n in order:
    assert set(nodes[n]['dependencies']) <= seen, (n,nodes[n]['dependencies'])
    seen.add(n)

def model(weights, workers):
    ends, parents, tails = {}, {}, {}
    for n in order:
        deps=nodes[n]['dependencies']
        parent=max(deps,key=lambda x:ends[x]) if deps else None
        parents[n]=parent
        ends[n]=weights[n]+(ends[parent] if parent is not None else 0)
    for n in reversed(order):tails[n]=weights[n]+max((tails[x] for x in children[n]),default=0)
    critical=max(ends,key=ends.get)
    chain=[];n=critical
    while n is not None:chain.append(n);n=parents[n]
    chain.reverse()
    pending={n:len(nodes[n]['dependencies']) for n in nodes}
    ready=[(-tails[n],n) for n in nodes if pending[n]==0];heapq.heapify(ready)
    running=[];completed=0;now=0;peak=0;schedule=[]
    while ready or running:
        while ready and len(running)<workers:
            _,n=heapq.heappop(ready)
            heapq.heappush(running,(now+weights[n],n));schedule.append({'unit':n,'start_ns':now,'end_ns':now+weights[n]})
            peak=max(peak,len(running))
        assert running
        now=running[0][0]
        while running and running[0][0]==now:
            _,n=heapq.heappop(running);completed+=1
            for child in children[n]:
                pending[child]-=1
                if pending[child]==0:heapq.heappush(ready,(-tails[child],child))
    assert completed==len(nodes)
    total=sum(weights.values())
    return {'workers':workers,'makespan_ms':now/1e6,'total_work_ms':total/1e6,'critical_path_ms':ends[critical]/1e6,'lower_bound_ms':max(total/workers,ends[critical])/1e6,'utilization':total/(workers*now),'peak_active':peak,'critical_chain':chain,'schedule':schedule}

costs={n:{key:median([run[n][key] for run in by_run]) for key in ('cpu_ns','wall_ns','headers_cpu_ns','bodies_cpu_ns','allocations','requested_bytes','imported_schemes','candidates','type_nodes','free_type_visits','free_row_visits')} for n in nodes}
models={metric:[model({n:r[metric] for n,r in costs.items()},workers) for workers in (1,2,4,8,16,189)] for metric in ('cpu_ns','wall_ns')}
profile_rows=[s['stats']['phaseProfile']['phases'] for s in samples]
other_frontend=median([sum(r['us'] for name,r in p.items() if name not in ('check','backend'))/1000 for p in profile_rows])
check_phase=median([p['check']['us']/1000 for p in profile_rows])
check_residual=max(0,check_phase-median([sum(r['wall_ns'] for r in trace)/1e6 for trace in traces]))
for metric,rows in models.items():
    for row in rows:row['frontend_estimate_ms']=row['makespan_ms']+other_frontend+check_residual
parts={key:sum(r[key] for r in costs.values())/1e6 for key in ('cpu_ns','wall_ns','headers_cpu_ns','bodies_cpu_ns')}
ranked=sorted(nodes,key=lambda n:costs[n]['cpu_ns'],reverse=True)
top=[{'unit':n,'file':nodes[n]['filename'].split('/snapshot/',1)[-1],'syntax_nodes':nodes[n]['syntax_nodes'],**costs[n]} for n in ranked[:20]]
chain=[{'unit':n,'file':nodes[n]['filename'].split('/snapshot/',1)[-1],'cpu_ms':costs[n]['cpu_ns']/1e6} for n in models['cpu_ns'][0]['critical_chain']]
edit_traces={phase:read(work/f'profiles/0-{phase}.json')['stats']['phaseProfile'] for phase in ('literal_in_body','literal_revert','body_change','body_revert')}
result={'scope':'Diagnostic serial costs fed into a precedence-only scheduling model; excludes scheduler, contention, copying, symbol isolation and deterministic budget/publication costs. Not a measured parallel compiler.', 'modules':len(nodes),'edges':sum(len(r['dependencies']) for r in nodes.values()),'other_frontend_ms':other_frontend,'check_residual_ms':check_residual,'check_phase_ms':check_phase,'parts_ms':parts,'top_modules':top,'critical_chain':chain,'models':models,'per_run_cpu_model':[{'run':i,'models':[{k:v for k,v in model({n:r['cpu_ns'] for n,r in run.items()},workers).items() if k!='schedule'} for workers in (1,2,4,8,189)]} for i,run in enumerate(by_run)],'edits':{phase:{'checked_modules':len(p['module_trace']),'check_ms':p['phases']['check']['us']/1000,'frontend_ms':sum(r['us'] for name,r in p['phases'].items() if name!='backend')/1000,'modules':[r['filename'].split('/snapshot/',1)[-1] for r in p['module_trace']]} for phase,p in edit_traces.items()}}
game=next(n for n in nodes if n.endswith('/snapshot/src/game.blot'))
counterfactuals=[]
for label,body_factor,header_factor in [('halve game body checking',0.5,1.0),('quarter game body checking',0.25,1.0),('halve game body and all headers',0.5,0.5)]:
    weights={n:round(r['cpu_ns']-r['headers_cpu_ns']*(1-header_factor)-(r['bodies_cpu_ns']*(1-body_factor) if n==game else 0)) for n,r in costs.items()}
    scenario=model(weights,4)
    counterfactuals.append({'assumption':label,'checker_ms':scenario['makespan_ms'],'frontend_ms':scenario['makespan_ms']+other_frontend+check_residual})
result['counterfactuals']=counterfactuals
result['counterfactual_note']='Hypothetical reductions to locate useful targets, not forecast gains or implemented optimizations.'
(work/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print('Modules',len(nodes),'edges',result['edges'],'parts ms',parts,'outside checking ms',other_frontend)
for row in models['cpu_ns']:print('Workers',row['workers'],'ideal check ms',round(row['makespan_ms'],1),'frontend estimate ms',round(row['frontend_estimate_ms'],1),'utilization',round(row['utilization'],3))
print('Critical chain',json.dumps(chain,indent=2))
print('Top CPU modules',[(r['file'],round(r['cpu_ns']/1e6,2),round(r['headers_cpu_ns']/1e6,2),round(r['bodies_cpu_ns']/1e6,2)) for r in top[:10]])
print('Edits',result['edits'])
print('Counterfactuals',counterfactuals)
