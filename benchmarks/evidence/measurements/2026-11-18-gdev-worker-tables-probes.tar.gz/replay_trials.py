from pathlib import Path
from hashlib import sha256
import os,time,json,subprocess
d=Path('build/core-packets').resolve()
names=('audit-old','audit-new');records={}
for n in names:
 at=d/n/'canonical';records[n]={p.name:sha256(p.read_bytes()).hexdigest() for p in at.glob('*.bin')}
 assert len(records[n])==538
mismatch=[f for f,v in records[names[0]].items() if records[names[1]].get(f)!=v]
print('mismatching canonical records',len(mismatch),mismatch[:20],flush=True)
(d/'canonical.json').write_text(json.dumps(dict(hashes=records[names[0]],mismatches=mismatch),indent=2))
assert not mismatch
runs=[]
for i in range(12):
 for n in (names if i%2==0 else names[::-1]):
  inputs=d/('input' if n==names[0] else 'new-input');out=subprocess.check_output([d/n/'run'],env=dict(os.environ,BLOT_PACKET_SAMPLES=str(inputs)),timeout=15,text=True)
  row={k:(c,b,t) for k,c,b,t in (map(int,l.split()) for l in out.splitlines())}
  assert set(row)=={1801,1802,1803,1804} and all(c==269 for c,b,t in row.values())
  runs.append(dict(round=i+1,mode=n,fields=row))
(d/'replay-trials.json').write_text(json.dumps(runs,indent=2)+'\n')
