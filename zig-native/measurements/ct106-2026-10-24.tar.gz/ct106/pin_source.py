from pathlib import Path
import hashlib,json,subprocess
root=Path.cwd();copy=root/'build/bench/ct106/qualification-work/blot2'
files=[*sorted((root/'zig-native/src').rglob('*.zig')),*sorted((root/'zig-native').glob('*.zig')),*sorted((root/'zig-native/tests').rglob('*.ts'))]
pins={};mismatch=[]
for p in files:
 name=str(p.relative_to(root)); digest=hashlib.sha256(p.read_bytes()).hexdigest();pins[name]=digest
 if not (copy/name).exists() or hashlib.sha256((copy/name).read_bytes()).hexdigest()!=digest:mismatch.append(name)
assert not mismatch,mismatch
out={'source_head':subprocess.check_output(['git','rev-parse','HEAD'],text=True).strip(),'qualified_files':pins,'qualified_native_sha256':hashlib.sha256((root/'build/bench/ct106/identity-heap-blotc').read_bytes()).hexdigest(),'compiler_identity_file_sha256':hashlib.sha256((copy/'zig-native/zig-out/compiler-identity.bin').read_bytes()).hexdigest(),'frozen_manifest_sha256':hashlib.sha256((root/'build/bench/compile-cost-20261023/manifest.json').read_bytes()).hexdigest(),'source_matches_qualified_checkout':True}
(root/'build/bench/ct106/final-pins.json').write_text(json.dumps(out,indent=2)+'\n')
print('Matched',len(pins),'native/build/guest source files to the qualified checkout')
