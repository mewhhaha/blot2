const out = 'build/bench/ct106/timing-premature-close';
const server = Deno.serve({hostname:'127.0.0.1',port:0,onListen(){}}, request => {
  const {socket,response} = Deno.upgradeWebSocket(request);
  socket.onopen = () => socket.close();
  return response;
});
const result = await new Deno.Command(Deno.execPath(),{args:['run','-A','scripts/bench/zig_time_report.ts',`ws://127.0.0.1:${server.addr.port}/`,out],stdout:'piped',stderr:'piped'}).output();
await server.shutdown();
console.log(JSON.stringify({success:result.success,code:result.code,stderr:new TextDecoder().decode(result.stderr)}));
if(result.success || !new TextDecoder().decode(result.stderr).includes('closed before')) throw Error('premature close was not rejected');
try {await Deno.stat(out+'/report.json'); throw Error('incomplete collector published success');} catch(error) {if(!(error instanceof Deno.errors.NotFound)) throw error;}
