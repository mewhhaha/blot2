from pathlib import Path
import json
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter, MaxNLocator
mpl.rcParams['svg.fonttype']='none';mpl.rcParams['svg.hashsalt']='gdev-finished-signatures'
out=Path('benchmarks/evidence/measurements/2026-11-18-gdev-finished-functions')
doc=json.loads(out.with_suffix('.json').read_text());a,b=[doc['work'][k]['resolve_nodes_added'] for k in ['before','after']]
fig,(left,right)=plt.subplots(1,2,figsize=(9,3.4),gridspec_kw={'width_ratios':[1,1.3]});colors=['#56819b','#177451'];fig.subplots_adjust(left=.11,right=.93,top=.68,bottom=.17,wspace=.46)
fig.text(.022,.9,'Gdev Main compilation',fontsize=18,weight='bold',color='#183143');fig.text(.022,.795,'46,109 lines  ·  269 modules  ·  eight workers  ·  identical Wasm',fontsize=10,color='#475569')
for ax in [left,right]:
 ax.spines[:].set_visible(False);ax.set_axisbelow(True);ax.grid(axis='x',color='#e1e6e9');ax.tick_params(length=0,pad=5,labelsize=9)
left.set_title('Type nodes allocated in resolution',loc='left',fontsize=10,weight='bold');left.barh([1,0],[a,b],color=colors,height=.47)
left.set_yticks([1,0],['Baseline','Candidate']);left.set_xlim(0,440000);left.set_xticks([0,100000,200000,300000,400000]);left.xaxis.set_major_formatter(FuncFormatter(lambda x,p:f'{x/1000:.0f}k' if x else '0'))
for y,n in zip([1,0],[a,b]):left.text(n-9500,y,f'{n:,}',ha='right',va='center',color='white',size=10,weight='bold')
right.set_title('Fresh compile, median milliseconds',loc='left',fontsize=10,weight='bold')
for y,k in [(1,'fresh'),(0,'confirmation')]:
 for dy,field,c in zip([.18,-.18],['previousMs','candidateMs'],colors):
  n=doc[k][field];right.barh(y+dy,n,height=.31,color=c);right.text(n-20,y+dy,f'{n:.0f}',va='center',ha='right',color='white',size=9,weight='bold')
right.set_xlim(0,max(1050,max(doc[k][v] for k in ['fresh','confirmation'] for v in ['previousMs','candidateMs'])*1.03));right.set_xticks([0,1000,2000,3000]);right.set_yticks([1,0],['First 24 pairs','Busy host, 24 pairs'])
fig.savefig(out.with_suffix('.png'),dpi=150);fig.savefig(out.with_suffix('.svg'),metadata={'Date':None})
svg=out.with_suffix('.svg');svg.write_text('\n'.join(line.rstrip() for line in svg.read_text().splitlines())+'\n')
