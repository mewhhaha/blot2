import { strict as assert } from "node:assert";
const sha = async (bytes:Uint8Array<ArrayBuffer>) => [...new Uint8Array(await crypto.subtle.digest("SHA-256",bytes))].map(x=>x.toString(16).padStart(2,"0")).join("");
const modules:Record<string,WebAssembly.Module>={}; const pins:Record<string,unknown>={};
for(const [side,path] of Object.entries({plain:"build/remaining-runtime/kernels/candidate.wasm",profile:"build/remaining-runtime/public-profile.wasm"})) {const bytes=await Deno.readFile(path);modules[side]=new WebAssembly.Module(bytes);pins[side]={path,sha256:await sha(bytes),bytes:bytes.length};}
const names=["rc_retains","rc_releases","rc_destroyed","cycle_passes","cycle_vertices","cycle_edges","cycle_bytes"];
const cases:[string,number,number][]=[["selected",100,200100000],["reference_scratch",2000,2498864],["optional_generate",2000,2001000],["pipeline",2000,1151976000]];
const rows=[];
for(const [name,argument,expected] of cases){
 const raw=Object.fromEntries(Object.entries(modules).map(([side,module])=>[side,new WebAssembly.Instance(module).exports]));
 const invoke=(side:string)=>{const e=raw[side];(e["blot:ownership_enter"] as CallableFunction)();let outcome=1;try{assert.equal((e[name] as CallableFunction)(argument)>>>0,expected>>>0);outcome=0;}finally{(e["blot:ownership_leave"] as CallableFunction)(outcome);}for(const n of ["rc_roots","rc_leases"])assert.equal((e[`blot:${n}`] as WebAssembly.Global).value,0);};
 const counts=(side:string)=>Object.fromEntries(names.map(n=>[n,Number((raw[side][`blot:${n}`] as WebAssembly.Global).value)>>>0]));
 const results:Record<string,any>={};
 for(const side of ["plain","profile"]){for(let i=0;i<10;i++)invoke(side);const before=counts(side);invoke(side);const after=counts(side);results[side]={counts:Object.fromEntries(names.map(n=>[n,(after[n]-before[n])>>>0])),samples_ms:[],memory_bytes:(raw[side]["blot:memory"] as WebAssembly.Memory)?.buffer.byteLength??0};}
 assert.deepEqual(results.plain.counts,results.profile.counts);
 for(let round=0;round<31;round++)for(const side of round%2?["profile","plain"]:["plain","profile"]){const t=performance.now();for(let i=0;i<5;i++)invoke(side);results[side].samples_ms.push((performance.now()-t)/5);}
 for(const r of Object.values(results))r.median_ms=[...r.samples_ms].sort((a,b)=>a-b)[15];
 rows.push({name,argument,expected,...results});
}
await Deno.writeTextFile("build/remaining-runtime/profile-overhead.json",JSON.stringify({complete:true,engine:Deno.version,samples:31,batch:5,pins,scope:"Diagnostic overhead only; same optimized source, alternating raw and --profile-memory Wasm. Exact checksums, matching production counters, ownership enter/leave.",rows},null,2));
console.log(JSON.stringify(rows));
