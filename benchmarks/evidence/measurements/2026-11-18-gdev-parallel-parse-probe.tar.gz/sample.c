// Linux/x86-64 sampling probe for the separately fingerprinted metered binary.
#define _GNU_SOURCE
#include <fcntl.h>
#include <link.h>
#include <pthread.h>
#include <signal.h>
#include <stdint.h>
#include <stdlib.h>
#include <string.h>
#include <sys/time.h>
#include <ucontext.h>
#include <unistd.h>
static uintptr_t base, limit;
static int out = -1;
static const volatile struct { int fd, depth, stages[12]; } *meter;
static int executable(struct dl_phdr_info *p, size_t size, void *user) {
    (void)size; (void)user;
    if (*p->dlpi_name) return 0;
    base = p->dlpi_addr;
    for (int i = 0; i < p->dlpi_phnum; ++i) {
        if (p->dlpi_phdr[i].p_flags & PF_X)
            limit = base + p->dlpi_phdr[i].p_vaddr + p->dlpi_phdr[i].p_memsz;
    }
    return 1;
}
static void sample(int sig, siginfo_t *info, void *u) {
    (void)sig; (void)info;
    int depth=meter->depth;
    if (meter->fd < 0 || depth <= 0 || depth > 11 || meter->stages[depth] != 1) return;
    uintptr_t pc = ((ucontext_t *)u)->uc_mcontext.gregs[REG_RIP];
    uint64_t offset = 0;
    if (pc >= base && pc < limit) offset = pc - base;
    (void)write(out, &offset, sizeof offset);
}
static void arm(void) {
    struct itimerval t = {.it_value={0,1000},.it_interval={0,1000}};
    (void)setitimer(ITIMER_PROF,&t,0);
}
__attribute__((constructor)) static void init(void) {
    const char *target=getenv("BLOT_SAMPLE_EXE"), *offset=getenv("BLOT_SAMPLE_OFFSET"), *path=getenv("BLOT_SAMPLE_OUT");
    char name[4096];
    if (!target || !offset || !path) return;
    ssize_t n=readlink("/proc/self/exe",name,sizeof name-1);
    if (n<=0) return;
    name[n]=0;
    if (strcmp(name,target)) return;
    dl_iterate_phdr(executable,NULL);
    meter=(const void *)(base+strtoull(offset,NULL,16));
    out=open(path,O_WRONLY|O_CREAT|O_APPEND|O_CLOEXEC,0600);
    if (out<0) return;
    struct sigaction sa={.sa_sigaction=sample,.sa_flags=SA_SIGINFO|SA_RESTART};
    sigemptyset(&sa.sa_mask);
    if (sigaction(SIGPROF,&sa,NULL)) return;
    pthread_atfork(NULL,NULL,arm);
    arm();
}
