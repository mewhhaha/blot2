import pathlib,subprocess,json,hashlib,tempfile,shutil
root=pathlib.Path('/home/mewhhaha/src/blot2');stage=root/'build/install/ct109';src=root
dir=pathlib.Path(tempfile.mkdtemp(prefix='blot-install-ct109-', dir=str(root / 'build/bench/ct109/tmp')));shutil.copy2(src/'examples/lists.blot',dir/'smoke.blot')
commands=[[str(stage/'blot'),'fmt','smoke.blot'],[str(stage/'blot'),'fmt','smoke.blot','--check'],[str(stage/'blot'),'check','smoke.blot'],[str(stage/'blot'),'build','smoke.blot','staged-cli.wasm'],[str(stage/'blotc'),'build','smoke.blot','staged-native.wasm','--prelude',str(src/'std/prelude.blot'),'--std-root',str(src/'std')]]
results=[]
for i,cmd in enumerate(commands):
 with (stage/f'smoke-{i}.stdout.log').open('w') as out,(stage/f'smoke-{i}.stderr.log').open('w') as err:r=subprocess.run(cmd,cwd=dir,stdout=out,stderr=err)
 results.append({'command':cmd,'exit_code':r.returncode});assert r.returncode==0,cmd
cli=(dir/'staged-cli.wasm').read_bytes();assert cli==(dir/'staged-native.wasm').read_bytes()
verify=stage/'verify_wasm.ts';verify.write_text('const b=await Deno.readFile(Deno.args[0]);const m=new WebAssembly.Module(b);if(WebAssembly.Module.imports(m).length)throw Error("Unexpected imports");const i=new WebAssembly.Instance(m);const a=i.exports.answer;const value=typeof a==="function"?a():a instanceof WebAssembly.Global?a.value:null;if(value!==29)throw Error(String(value));console.log(JSON.stringify({valid:WebAssembly.validate(b),answer:value,imports:WebAssembly.Module.imports(m)}));\n')
r=subprocess.run(['deno','run','--allow-read',str(verify),str(dir/'staged-cli.wasm')],cwd=dir,capture_output=True,text=True);assert r.returncode==0,r.stderr
record={'cwd':str(dir),'commands':results,'wasm_sha256':hashlib.sha256(cli).hexdigest(),'wasm_bytes':len(cli),'execution':json.loads(r.stdout),'staged_sha256':{name:hashlib.sha256((stage/name).read_bytes()).hexdigest() for name in ['blot','blotc']}}
(stage/'staged-smoke.json').write_text(json.dumps(record,indent=2)+'\n');print(json.dumps(record['execution']))
