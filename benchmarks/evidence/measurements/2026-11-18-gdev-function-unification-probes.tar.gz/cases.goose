import check.types;
import check.effects;
import support.error;
extern fn word(value:u32)="pair_test_word";
extern fn endCase()="pair_test_end";
fn errorCode(e:blot_error::Error)->u32 {
 match e {none=>{return 0;},type_mismatch=>{return 1;},effect_mismatch=>{return 2;},infinite_type=>{return 3;},type_limit=>{return 4;},infinite_effect=>{return 5;},_=>{assert(false);return 6;},}
}
fn choose(seed:u32&,n:u32)->u32 {seed=seed*1664525+1013904223;return (seed>>8)%n;}
fn arrow(s:blot_check_types::Store&,a:u32,b:u32,r:u32)->u32 {let f,e=s.functionWithEffects(a,b,r);assert(e==blot_error::Error.none);return f;}
recursive fn shape(s:const blot_check_types::Store&,id:u32,depth:i64) {
    assert(depth<32);let node=s.node(id);word(blot_check_types::tagCode(node.tag));
    if node.tag==blot_check_types::Tag.variable {word(node.a);word(node.b);}
    if node.tag==blot_check_types::Tag.function {shape(s,node.a,depth+1);shape(s,node.b,depth+1);row(s,node.c);}
}
fn row(s:const blot_check_types::Store&,id:u32) {
    let v=s.effects.node(id);word(v.labels.len);for label in s.effects.list(v.labels) {word(label);}
    match v.tail {closed=>{word(0);},variable n=>{word(1);word(n.value);},_=>{assert(false);},}
    word(v.cursor);
}
fn main() {
    let u=blot_check_types::u32_type;let b=blot_check_types::boolean;let unit=blot_check_types::unit;let ok=blot_error::Error.none;
    var seed:u32=2399;
    for round in 0..4096 {
        var s,e=blot_check_types::initWithOptions(blot_check_types::Options{closed_graphs:(round%8)!=0,..});assert(e==ok);
        let x,xe=s.fresh();let y,ye=s.fresh();let alias,ae=s.fresh();assert(xe==ok && ye==ok && ae==ok);
        let r,re=s.freshEffects();let v,ve=s.freshEffects();assert(re==ok && ve==ok);
        let foreign,fe=s.effects.row([blot_check_types::foreign_operation],blot_check_effects::Tail.closed);assert(fe==ok);
        let inner=arrow(s,x,y,r);
        if round%4==0 {assert(s.appendVersion(y,u)==ok);}
        assert(s.appendVersion(alias,inner)==ok);
        if round%4==0 {assert(s.appendVersion(y,b)==ok);}
        if round%7==0 {match s.effects.node(r).tail {variable n=>{assert(s.effects.appendVersion(n.value,v)==ok);},_=>{assert(false);},}}
        let leaves=[u,b,unit,x,y,alias,inner];let rows=[0 as u32,r,v,foreign];
        let a=leaves[choose(seed,7)];let c=leaves[choose(seed,7)];let t=rows[choose(seed,4)];
        let p=arrow(s,a,c,t);
        var a2=a;var c2=c;var t2=t;
        if round%3!=0 {a2=leaves[choose(seed,7)];c2=leaves[choose(seed,7)];t2=rows[choose(seed,4)];}
        let q=arrow(s,a2,c2,t2);
        var tail=leaves[choose(seed,7)];var tail2=tail;
        if round%2==0 {tail2=leaves[choose(seed,7)];}
        if round%4==1 {tail=p;tail2=q;}
        let left=arrow(s,p,tail,r);let right=arrow(s,q,tail2,v);
        if round%16==0 {s.resolution_depth_limit=2;}
        let err=s.unify(left,right);word(errorCode(err));word(s.cursor());word(s.versions.len as u32);word(s.effects.versions.len as u32);
        s.resolution_depth_limit=1024;
        for id in [x,y,alias,left,right] {
            let resolved,xe=s.resolve(id,0);word(errorCode(xe));if xe==ok {shape(s,resolved,0);}
        }
        for id in [r,v] {let resolved,re=s.resolveEffects(id,0);word(errorCode(re));if re==ok {row(s,resolved);}}
        endCase();s.deinit();
    }
}
