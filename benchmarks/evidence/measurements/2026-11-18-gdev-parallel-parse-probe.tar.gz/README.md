These sources reproduce the profiling experiment on Linux x86-64.
The patch applies to Blot 9409487492fb517e8180a261e546fbbdd3b7e834.
The standalone parser test is tree_oracle.goose. Its four input roots are
Gdev, Ink, std, and compiler-goose. The generated-code fixtures use .blot.

Use a scratch copy of that revision. Keep the pinned Gdev and Ink next to it.
Build its shipping compiler with deno task build:compiler and save a copy at
build/parse-pilot/control. Apply pilot.patch, rebuild and copy the resulting
binary to build/parse-pilot/candidate. Put the .ts, .py and .c files from
this archive under build/parse-pilot. Run these commands at the repo root.

    python3 build/parse-pilot/wrappers.py
    deno run -A build/parse-pilot/measure.ts cold 12
    deno run -A build/parse-pilot/measure.ts edits 5
    deno run -A build/parse-pilot/measure.ts worker 4

The 1 and 8 modes change only the parser width. The checker uses eight
workers in both cases. The native process meter tags exclusive intervals.
Each fresh worker run emits eight worker rows and a coordinator row. Each
row is a pid followed by wall and thread CPU microseconds per stage. Stage
order is other, check, Core lowering, interface freeze/encode, Core encode,
imported interface decode, queue claim, publish, read, coordinator gather.
The last two copy intervals include record validation and queue locking.

For the CPU samples, use the archived time_gdev_parse.ts in scripts/integration.
Only the sampling wrapper installs the timer in the matching executable.
The sampler derives the meter offset from that build's ELF symbols.

    clang -O2 -fPIC -shared -o build/parse-pilot/sample.so build/parse-pilot/sample.c -ldl -pthread
    python3 build/parse-pilot/sample.py run ordinary

Ordinary sampling uses six fresh Gdev builds with phase profiling disabled.
It counts exclusive program-counter samples during type checking while the
worker is outside imported-interface decoding and transport. Samples mapped
outside the executable are retained in the denominator. The transport meter
itself is active. Timed shipping comparisons use neither sampler nor meter.
