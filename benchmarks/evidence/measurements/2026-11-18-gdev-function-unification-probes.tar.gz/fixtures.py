from pathlib import Path
import json,sys,tempfile
sys.path.insert(0,'compiler-goose/tools');import test_fixtures as f
from collections import Counter
wanted=json.loads(Path('compiler-goose/tests/fixtures/expected.json').read_text())['programs'];diff=Counter();bad=[]
with tempfile.TemporaryDirectory() as tmp:
 for name,old in wanted.items():
  got=f.build(Path(sys.argv[1]).resolve(),name,tmp)
  for a,b in zip(got['records'],old['records']):
   for key in ['type_nodes','effect_rows']:
    if k:=a.get(key):diff[key]+=int(k!=b.get(key));a.pop(key);b.pop(key,None)
  if old!=got:bad.append(name)
print(len(wanted),'programs; counter differences',diff,'semantic differences',bad);assert not bad
