"""Link the observable capture compiler from a completed release build."""
from pathlib import Path
import json
import subprocess

here = Path(__file__).resolve().parent
build = Path("compiler-goose/build").resolve()
command = json.loads((build / "stages/compile-and-link-program.json").read_text())["command"]
command[command.index("-O2")] = "-O0"
command[command.index("-o") + 1] = str(here / "capture")
command[command.index("-o"):command.index("-o")] = [
    str(here / "capture.c"), "-Wl,--wrap=blot_persist_publish",
]
subprocess.run(command, check=True)
