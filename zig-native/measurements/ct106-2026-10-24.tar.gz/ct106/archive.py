from pathlib import Path
import hashlib,io,json,subprocess,tarfile
root=Path.cwd();bench=root/'build/bench/ct106';files={}
def add(path,name):
 data=path.read_bytes();files[name]=data
suffixes={'.json','.jsonl','.log','.xml','.txt','.csv','.patch','.zig','.ts','.py','.asm'}
exclude={'qualification-work','tmp','timing-replay','timing-replay-final','timing-replay-verified','timing-replay-missing'}
for path in bench.rglob('*'):
 rel=path.relative_to(bench)
 if not path.is_file() or path.name=='archive-result.json' or any(part in exclude or part in ['workspace','.zig-cache','__pycache__'] for part in rel.parts):continue
 if path.suffix in suffixes or path.suffix=='.bin' and rel.parts[0]=='release-compact-timing-final' or path.suffix=='.blot' and rel.parts[0] in ['review-pairs','review-pairs-final','synthetic-pairs'] and 'synthetic' in rel.parts:add(path,'ct106/'+str(rel))
for path in (root/'build/install/ct106').iterdir():
 if path.is_file() and path.suffix in suffixes:add(path,'installation/'+path.name)
files['source/changes.patch']=subprocess.check_output(['git','diff','--binary','HEAD','--','.',':(exclude)zig-native/measurements'])
for path in [root/'zig-native/src/eval/source_owners.zig',*[root/'scripts/bench'/n for n in ['README.md','review_corpus.ts','development_cycles.py','process_pmu.py','process_pmu.ts','session_memory.ts','zig_time_report.ts']]]:add(path,'source/'+str(path.relative_to(root)))
for path in [root/'zig-native/CT106_QUALIFICATION.md',root/'COMPILER_CT106_WORK.md']:add(path,'documentation/'+path.name)
files['README.txt']=b'''CT106 evidence: final release 7d7ea08313e865a633ec9be2acc0347bc1560490ce8caca82e96df1c5b2dba69.
The historical file final-blotc (de3bf00...) predates the build-identity and heap-profile additions; only its same-source CPU-target screen uses it.
Complete qualification is qualification-final-disk/timings.json; its native evidence resumes run-ab5742e3da0626f5. Failed, invalidated and interrupted attempts are retained and are not passes.
Source changes are relative to 342a6f9, plus the explicitly included new source/tool files. final-pins.json records native/build/guest file identities. The later Git commit is authoritative for final documentation.
Public generated synthetic fixtures are included. Source snapshots from the private workload, binaries, generated Wasm and caches are excluded. Reproduction requires the frozen manifest's matching source tree.
Hardware events cover userspace whole requests, all existing and inherited future threads. Generic cache counts do not identify a cache level. Affinity trials constrain CPU sets rather than pinning each worker individually.
All 86 suggestions have dispositions; partial, conditional and unfinished items are not claimed as implementations.
'''
sums=''.join(hashlib.sha256(data).hexdigest()+'  '+name+'\n' for name,data in sorted(files.items()))
files['SHA256SUMS']=sums.encode()
destination=root/'zig-native/measurements/ct106-2026-10-24.tar.gz'
with tarfile.open(destination,'w:gz',compresslevel=6) as archive:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
# Verify the payload independently after compression.
with tarfile.open(destination,'r:gz') as archive:
 for line in archive.extractfile('SHA256SUMS').read().decode().splitlines():
  digest,name=line.split('  ',1);assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest,name
sha=hashlib.sha256(destination.read_bytes()).hexdigest()
destination.with_name(destination.name+'.sha256').write_text(sha+'  '+destination.name+'\n')
print(json.dumps({'file':str(destination),'sha256':sha,'bytes':destination.stat().st_size,'members':len(files),'verified':True}))
