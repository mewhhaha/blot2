# CT102: retained principal proof import

Baseline b346008 / qualified CT97 release. Focus ordinary edits; sub-second is an aspirational latency target, not measured.

Trace v1: first large projected query has matching complete image and dynamic inputs but importing saved call publications declines. The two later regions remain nonempty/unrecorded respectively.
Trace v2: import stops at publication 8627/12387, target 6:2, evidence 3275, at the principal type depth/work/bounds guard. Determine which bound before changing it.

Candidate acceptance: at least 10% less paired literal-edit CPU, no more than 5% unaffected fresh/body CPU regression, exact fresh/edit/revert/restart Wasm and full gate. Do not raise work/depth budgets or weaken image/admission checks. If work-limit rejection is duplicate DAG traversal, validate each distinct graph node with bounded scratch, retaining path-depth and cycle rejection. Preserve exhaustive OOM ownership laws.

Trace timings use Safe/noLLVM and are diagnostic only. Current frozen workload/output pins remain unchanged.

Trace v3 disproves the shared-graph work-limit hypothesis: depth 128, remaining work 999,809, node 3146 / 24,185. The height-cache prototype was removed; its new regression passed the sampled native family but lint reported two ownership-shape findings. It cannot overcome the actual unchanged depth boundary and is not a candidate.

Next bounded experiment: a source/image/input-proven empty result does not depend on successfully transporting all of its optional validated-call memo outputs. Translate each publication independently; omit any declined publication and let a later use perform ordinary fresh checking. Publish only accepted owner-translated proofs atomically. Keep the original depth/work/source/value checks unchanged. Require an executed-Wasm retained/deep-proof regression, errors/recovery, full OOM, and the same >=10% literal CPU / <=5% unaffected gates above.
