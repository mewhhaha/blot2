from pathlib import Path
import shlex
d=Path('build/parse-pilot').resolve()
for width in [1,8]:
 for profile in [False,True]:
    name='p'+str(width)+('trace' if profile else '')
    marks=''
    if profile: marks=f'export BLOT_LANE_TIMING={shlex.quote(str(d/(name+".lanes")))}\nexport BLOT_PARSE_TIMING={shlex.quote(str(d/(name+".parses")))}\n'
    p=d/name;p.write_text('#!/bin/sh\nexport BLOT_PARSE_WIDTH='+str(width)+'\n'+marks+'exec '+shlex.quote(str(d/'candidate'))+' "$@"\n');p.chmod(0o755)
