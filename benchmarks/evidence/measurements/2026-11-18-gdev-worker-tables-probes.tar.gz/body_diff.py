import hashlib
import json
from pathlib import Path
import sys

sys.path.insert(0, str(Path("benchmarks/tools").resolve()))
from wasm_size import Reader


def section_bodies(path):
    module = path.read_bytes()
    assert module[:8] == b"\0asm\x01\0\0\0"
    reader = Reader(module, 8)
    sections = []
    bodies = []
    while reader.pos < reader.end:
        section = reader.byte()
        length = reader.leb()
        start = reader.pos
        reader.skip(length)
        parts = Reader(module, start, reader.pos)
        contents = module[start:reader.pos]
        sections.append((section, hashlib.sha256(contents).hexdigest()))
        if section == 10:
            for _ in range(parts.leb()):
                size = parts.leb()
                body = parts.pos
                parts.skip(size)
                bodies.append(module[body:parts.pos])
            assert parts.pos == parts.end
    return hashlib.sha256(module).hexdigest(), sections, bodies


a, b = (section_bodies(Path(p)) for p in sys.argv[1:])
assert [s for s, _ in a[1]] == [s for s, _ in b[1]]
assert len(a[2]) == len(b[2]) and a[2]
changed = [i for i, (x, y) in enumerate(zip(a[2], b[2])) if x != y]
print(json.dumps(dict(freshSha256=a[0], editSha256=b[0], definedFunctions=len(a[2]),
    changedBodyOrdinals=changed, changedSections=[x[0] for x,y in zip(a[1],b[1]) if x!=y],
    freshBodyBytes=sum(map(len, a[2])), editBodyBytes=sum(map(len, b[2])),
    identicalBodyBytes=sum(len(x) for x, y in zip(a[2], b[2]) if x == y)), indent=2))
