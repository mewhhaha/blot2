from pathlib import Path
import json
root=Path(__file__).resolve().parents[3];base=root/'build/bench/ct103'
read=lambda p:json.loads(p.read_text())
summary=read(base/'summary.json');q=summary['qualification'];integration=read(base/'integration-summary.json');iq=integration['qualification'];installed=read(root/'build/install/ct103/installed.json')
assert all(summary['targets'][k] for k in ['literal_gain','unaffected_game','unaffected_devtools','unaffected_body'])
assert not summary['targets']['body_gain'] and not summary['targets']['under_one_second']
release=integration['release'];native_sha=installed['installed_sha256']['blotc'];assert native_sha==release['sha256']
checkpoint=f'''CT103/CT104 checkpoint, 24 October 2026:
[the four inference changes are qualified](zig-native/CT103_QUALIFICATION.md).
Nonempty principal results, exact call/recursive-summary observations, consumed
source declarations and bounded operation-row normalization are implemented.
Seven alternating pairs against `5412320` show **24.8% less literal-edit CPU**,
**4.2% less body-edit CPU** and **6.1% less fresh-game CPU**, with byte-identical
fresh/edit/revert/restart outputs. Devtools stays effectively unchanged.
Literal/body wall medians are 7.60 / 12.46 s on the loaded shared host; the body
wall median does not improve. These CPU gains are medians of within-pair ratios.

Literal edits reuse all 20 principal results; body edits reuse 16, leaving four
fresh regions. Three unseen literal edits and three unseen body edits match
fresh controls. Later literal edits take 2.96–3.18 s in that single diagnostic
sequence, including about 1.5 s inference. The 20% body-CPU target, both edit
classes below four/two seconds, and sub-second editing remain open. Continue
with the remaining body-region dependencies and residual inference in
[the current queue](COMPILE_HILLS.md); keep first-edit frontend work separate.

The measured candidate passes {q['native']:,} exhaustive native laws; its guest
suite catches a lost restart-reuse optimization, fixed by omitting unsupported
optional summary outputs while keeping all required-input checks. Main also
advanced to `faf3f78` during measurement;
the final combined release separately passes {iq['native']:,} exhaustive native
laws, {iq['guests']:,} guest checks, {iq['smoke']} smoke checks and {iq['harness']} tooling checks,
with zero Zig lint findings and exact frozen-workload output parity against the
measured candidate. Its full gate takes {iq['wall_seconds']:.2f} s. Performance percentages belong to the pinned comparison; they do not attribute
gains to the later callback/diagnostic changes or portable-output fix. The measured expanded
development cycle takes 26.05 s with a 3.59 s compiler build and 6.90 s complete
native compilation; these are individual observations, not p95 estimates.

The combined CLI and compiler are installed at `~/.local/bin/blot` and `blotc`.
Both resolve through PATH; outside-repository format/check/build, matched Wasm,
the list example result 29 and the bundled guide pass. Native SHA-256:
`{native_sha}`.
Installation and rollback backups are recorded in `build/install/ct103/installed.json`.
Preserve unrelated untracked `zig-native/build/` and `zig-out-modern/`. The dated
checkpoints below are historical; do not rerun completed hills.
'''
def replace_between(name,start,end,new):
 p=root/name;s=p.read_text();a=s.index(start);b=s.index(end,a);p.write_text(s[:a]+new.rstrip()+'\n\n'+s[b:])
replace_between('CONTINUE.md','CT103/CT104 work in progress,','CT97/CT98/BT4 checkpoint,',checkpoint+'\nHistorical CT102 evidence: [partial call-memo replay](zig-native/CT102_QUALIFICATION.md)\nreduced literal CPU by 25.1% against CT97. Its installation is superseded above.')
p=root/'FINISH_PLAN.md';s=p.read_text();a=s.index('CT102 checkpoint,');b=s.index('\n',s.index('The qualified CT102 CLI and compiler are installed locally.',a));p.write_text(s[:a]+checkpoint+s[b:])
p=root/'zig-native/STATUS.md';s=p.read_text();a=s.index('## Principal call-memo replay,');b=s.index('## Row traversal,',a);p.write_text(s[:a]+'## Principal dependency reuse and row normalization, 24 October 2026\n\n'+checkpoint.replace('(zig-native/CT103_QUALIFICATION.md)','(CT103_QUALIFICATION.md)').replace('(COMPILE_HILLS.md)','(../COMPILE_HILLS.md)')+'\nHistorical CT102: [partial call-memo replay](CT102_QUALIFICATION.md),\n25.1% less literal CPU against CT97, is superseded by the combined install above.\n\n'+s[b:])
short=f'''The [compile measurements](COMPILE_MEASUREMENTS.md) separate application compile
cost from building and checking the compiler. The
[latest inference changes](zig-native/CT103_QUALIFICATION.md) reduce retained gdev
literal-edit CPU by **24.8%**, body-edit CPU by **4.2%** and fresh-game CPU by
**6.1%** against `5412320` in seven alternating pairs, with identical Wasm.
Shared-host wall medians are 7.60 / 12.46 s for literal/body edits; body wall time
does not improve. Sub-second editing remains open. These percentages use the
pinned measured candidate. The final release also fixes portable restart replay,
includes `faf3f78` and passes {iq['native']:,} exhaustive native laws and
{iq['guests']:,} guest checks. The expanded development cycle takes 26.05 s,
including a 3.59 s compiler build and 6.90 s complete native compilation. These
are individual observations, not p95 estimates or paired compiler-build gains.
Keep stable writable Zig caches; the measured incremental mode did not improve
real edits. Use `deno task bench:compiler-build --out build/bench/build-next`
for isolated build/edit/revert measurements. See the
[compile hills](COMPILE_HILLS.md), [build hills](BUILD_HILLS.md) and
[performance review](PERFORMANCE_REVIEW.md) for remaining costs and targets.
'''
replace_between('README.md','The [compile measurements]','For a smaller development check',short)
replace_between('zig-native/README.md','[CT102 principal replay]','`blotc build ENTRY',f'''[Principal dependency reuse and row normalization](CT103_QUALIFICATION.md)
reduce literal-edit CPU by 24.8%, body-edit CPU by 4.2% and fresh-game CPU by
6.1% against `5412320` in seven alternating pairs, with identical Wasm.
The literal edit reuses all 20 principal results; body edits still rebuild four
regions. Shared-host literal/body wall medians are 7.60 / 12.46 s, with no body
wall improvement. Sub-second editing remains open. The percentages belong to
the pinned measured candidate. The final release also fixes portable restart
replay, includes `faf3f78` and separately passes {iq['native']:,} exhaustive native laws and
{iq['guests']:,} guest checks. The measured development cycle takes 26.05 s;
its 3.59 s compiler build and 6.90 s native compilation are individual observations.
The [review](../PERFORMANCE_REVIEW.md) separates first-edit frontend work from
steady inference and records the remaining dependencies to investigate.
''')
review='''Latest outcome, 24 October 2026:
[CT103/CT104 implements all four selected changes](zig-native/CT103_QUALIFICATION.md).
Seven alternating pairs against exact `5412320` reduce literal-edit CPU by
24.8%, body-edit CPU by 4.2% and fresh-game CPU by 6.1%; devtools is essentially
unchanged. Literal reuse rises from 18 to all 20 principal results, with one
nonempty result and 4,400 completed-summary publications. Body reuse rises from
15 to 16, leaving four fresh regions. Source, dynamic-input, ownership and
bounded importer checks remain in force. Portable archives still require the
complete source image; only retained reuse admits exact consumed declarations.

The combined cache/reuse measurement meets the literal 20% target but misses the
body 20% target. The 64-slot row-cache simulation covered 12.55% of label visits;
that is diagnostic evidence, not an isolated CPU speedup for the cache.
Shared-host body wall median worsens (10.86 → 12.46 s), so report CPU and wall
separately. The profiled pair also crosses a large load change; its body phase
ratio is not evidence of a 54% causal speedup.

The next measured bottlenecks are the four body-edit regions and inference
outside principal replay. The three largest body regions still collect about
1.83 million, 0.94 million and 0.61 million nodes; their inputs are recorded now,
but they still fail the source-admission checks. Literal builds have no
fresh principal regions, yet ordinary entry/closure queries still revisit tens
of thousands of nodes. Reusing principal results alone does not eliminate that
later work. A clean sequence of three unseen literal and three
unseen body edits matches both compilers and fresh controls. Later literals
take 2.96–3.18 s total, including 1.48–1.51 s inference and 63–67 ms frontend
checking. Body edits take 6.20–7.62 s, including 4.57–6.47 s inference. These are
single profiled observations, not a latency distribution. First-edit checking
still costs about 0.9 s; CT100 needs its own allocation attribution. Keep
constants deferred until their measured share justifies the work.

Next, trace which exact declarations invalidate the largest body regions and
which summary/body queries repeat after all principal hits. Bound an experiment
before widening admission; require changed-callee/type/effect errors, recovery,
owner translation, full allocation failures and byte-identical fresh controls.
Keep the body 20%, four/two-second and sub-second targets open. Do not combine
ratios from different historical intervals into a claimed cumulative gain.

The final installed build includes the concurrent `faf3f78` callback/diagnostic
commit and receives its own complete qualification and strict output screen.
Performance percentages above belong to the pinned `5412320` comparison.

## Historical CT102 analysis

'''
p=root/'PERFORMANCE_REVIEW.md';s=p.read_text();i=s.index('\n')+1;p.write_text(s[:i]+'\n'+review+s[i:].lstrip())
replace_between('COMPILE_MEASUREMENTS.md','Latest qualification:','Latest follow-up:',f'''Latest qualification:
[CT103/CT104 inference reuse and row normalization](zig-native/CT103_QUALIFICATION.md).
Seven alternating pairs against `5412320` show **24.8% less literal-edit CPU**,
**4.2% less body-edit CPU**, and **6.1% less fresh-game CPU** with exact outputs.
Devtools is effectively unchanged. Literal/body wall medians are 7.60 / 12.46 s
on the loaded shared host; the body wall median does not improve. The body 20%
and sub-second targets remain open. First-edit checking and previously unseen
later edits are reported separately. The final build also fixes portable restart replay, includes `faf3f78` and
passes a separate {iq['native']:,}-law exhaustive native gate, {iq['guests']:,} guest checks,
zero lint and exact frozen-output parity. That integration check is not a new
performance comparison. The matching CLI and native compiler are installed.

Historical CT102 qualification: [partial call-memo replay](zig-native/CT102_QUALIFICATION.md)
showed 25.1% less literal CPU against CT97. Earlier measurements below retain
their original baselines; their ratios are not cumulative current measurements.

Historical follow-up:''')
# Correct the boundary label retained by the replacement above.
p=root/'COMPILE_MEASUREMENTS.md';s=p.read_text().replace('Historical follow-up:\n\nLatest follow-up:', 'Historical follow-up:');p.write_text(s)
replace_between('COMPILE_HILLS.md','[CT102 is qualified]','## Historical program:', '''[The four CT103/CT104 changes are qualified](zig-native/CT103_QUALIFICATION.md).
Seven alternating pairs against `5412320` show **24.8% less literal-edit CPU**,
**4.2% less body-edit CPU**, and **6.1% less fresh-game CPU**, with exact outputs.
Devtools is unchanged within the guard. All 20 literal principal results are
reused; body edits reuse 16 and still rebuild four. Literal/body wall medians
are 7.60 / 12.46 s on the loaded shared host. The body wall median is worse;
CPU gains do not establish quiet-host latency. The final combined main build
is separately qualified and installed; the report distinguishes both source pins.

The user prioritizes ordinary edits and rebuilds. The clean unseen-edit sequence
finds 2.96–3.18 s later literal builds and 6.20–7.62 s body builds, with exact
fresh controls. Literal inference is still about 1.5 s; body inference is
4.57–6.47 s. First-edit frontend checking is about 0.9 s, later checking about
0.06–0.07 s. These single profiled observations are not latency distributions.

| Hill | Current evidence and next action | Acceptance target |
| --- | --- | --- |
| CT95–CT97: measurement, spawn preparation and effect rows | Complete; retain dated evidence and frozen workload/settings. | Do not rerun the historical program or weaken output/fault checks. |
| CT98: ordinary edit reuse | Capture capacity and literal principal reuse are fixed. Body edits still rebuild four regions. | Combined literal/body targets remain open: at least 50% cheaper than CT96, then under 4 s wall. Do not multiply separate historical ratios. |
| CT99: constants | Previously measured at 0.217 s in the CT102 literal profile. Reattribute if the residual profile changes. | Defer until eligible cost exceeds 10% of whole-build CPU. |
| CT100: first-edit and fresh frontend allocation | First edit still checks in about 0.9 s; later revisions in 60–70 ms. Attribute allocation callers and cutoff/replay work separately. | At least 25% fewer check allocations and 20% less check time, with no whole-build CPU regression. |
| CT101: combined qualification | CT103 fresh game CPU falls 6.1%; devtools unchanged. Combined main passes its own full gate and strict output screen. | Seven paired comparisons, <=5% unaffected CPU regression, exact outputs, full exhaustive gate and zero lint. Keep the 8 s fresh milestone open. |
| CT102: optional memo output declines | Complete: keep admitted results while omitted outputs receive ordinary checking. | Qualified >=10% literal CPU improvement against CT97; retain ownership and rejection laws. |
| CT103: remaining principal regions | Nonempty import, exact call/summary observations and consumed-source admission implemented. Literal 18→20 hits; body 15→16. Trace the exact consumed declarations blocking the four remaining body regions before extending reuse. | Literal >=20% CPU target met (24.8%); body target missed (4.2%) and remains open. Require exact source/type/effect/catalog rejection, fresh parity, errors/recovery and full OOM. |
| CT104: residual inference and iteration budget | Bounded 64-slot exact-epoch operation-row cache implemented; simulation covers 12.55% of label visits. No isolated cache speedup claim. Attribute repeated summary/body work outside principal replay next. | Both ordinary edit classes below 2 s, then below 1 s on a documented quiet host. Both targets remain open. Report CPU and wall distributions. |

Record each experiment's hypothesis and threshold first. After two bounded
misses, stop that approach and preserve negative evidence. Measure before
widening semantic admission or adding parallelism. See
[the performance review](PERFORMANCE_REVIEW.md). CT1–CT94 below are historical.
''')
replace_between('BUILD_HILLS.md','Current follow-up:','| Hill',f'''Current follow-up: [CT103/CT104](zig-native/CT103_QUALIFICATION.md) keeps
Safe/noLLVM development and native tests. Its expanded static-sharing cycle
passes in 26.05 s: compiler build 3.59 s, complete native compilation 6.90 s,
sampled native execution 0.87 s. The measured actual LLVM release takes 234.85 s;
the final combined-main release takes {release['seconds']:.2f} s. The measured native
gate takes {q['phases']['native-run']:.2f} s, and the combined native gate takes
{iq['phases']['native-run']:.2f} s ({iq['wall_seconds']:.2f} s complete). These separate
intervals are not paired build/gate improvements; no build hill closes.
BT2 remains negative and BT4's scratch-size trials remain complete. The
historical CT97 allocation reduction (44,074 → 37,930 exhaustive scenario runs)
and its halving/whole-gate targets remain unchanged.
''')
p=root/'BUILD_HILLS.md';s=p.read_text().replace('Latest actual LLVM release takes 254.61 s (CT97 observed 196.47 s in a different interval)',f'CT103 measured LLVM release takes 234.85 s; final combined-main release takes {release["seconds"]:.2f} s (different intervals)');p.write_text(s)
print('Updated READMEs, continuation, status, plan and performance/build queues')
