# CT103/CT104: remaining inference reuse and type queries

Base: 541232090b3941ec0c433de54d04c43c1eeb0276. User selected all four identified
costs: nonempty projected results, exact call dependencies, body invalidation,
and repeated type/effect queries. Preserve the 554-file frozen workload and
original options; measure first edits, unseen subsequent edits and reverts.

1. Record positive and negative consumed call proofs in their original owner;
   translate and compare them before replay. A query need not start with an
   empty validated-call table if every consumed fact is recorded. Untracked
   summary/graph consumption continues to decline.
2. Under the complete inference input image, translate nonempty type/row
   results using the existing bounded principal importer. No old owner IDs
   become current evidence. Publish only after result/input preparation succeeds.
3. Investigate a source read boundary smaller than the entire image, using
   exact observed source and catalog inputs. No inference certificate may admit
   runtime values or executable bodies merely because their signatures match.
4. Count row-cache misses, generation invalidation and repeated closed-type
   checks; choose a bounded improvement from the observations.

Implement the selected changes before final qualification. Development screens
use Safe/noLLVM, complete native inventory compilation, focused regression
families and executed Wasm. Final release comparisons use LLVM and seven
alternating pairs. Target at least 20% lower retained edit CPU, no more than 5%
unaffected fresh CPU regression, and exact fresh/edit/revert/restart/error
parity. Full exhaustive gate and zero Zig lint precede committing. Keep negative
evidence and stop an approach after two bounded experiments miss its target.
