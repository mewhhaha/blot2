import hashlib,io,json,tarfile
from pathlib import Path
root=Path('build/remaining-runtime');files={}
def add(p,name=None):
 p=Path(p);assert p.is_file(),p;files[name or str(p)]=p.read_bytes()
for name in ['REPRODUCE.md','qualification.json','install-smoke.log','full-gate-final.log','lint-final.log','checked-replay-tests.log','profile-context-native.log','ablation-source-differences.json','cycle-ablation.patch','gdev-memory-attribution.json.gz','gdev-baseline-pins.json','profile-overhead.json','acyclic-results.json','gdev-scores.json','gdev-compile-results.json','build-gdev.ts','gdev-memory-profile.mjs','score-gdev.py','measure-reduction.ts','measure-profile-overhead.ts','measure-gdev-compile.py','summarize-profiles.py','publish-results.py','archive-evidence.py']:
 add(root/name,'run/'+name)
for name in ['selected','reference_scratch','optional_generate','pipeline']:add(root/f'{name}-memory.json','profiles/'+name+'.json')
for name in ['results.json','wasmtime.json','firefox.json','baseline.wasm','candidate.wasm']:add(root/'kernels'/name,'kernels/'+name)
for name in ['baseline','candidate','ablation']:add(root/f'acyclic-{name}.wasm','reduction/'+name+'.wasm')
for p in sorted(root.glob('*-r?-config.json')):
 if '-profile-' not in p.name:add(p,'application/'+p.name)
for p in sorted(root.glob('*-r?.json')):
 if '-profile-' not in p.name and ('baseline' in p.name or 'final' in p.name or 'cycle-ablation' in p.name):add(p,'application/'+p.name)
for p in sorted(root.glob('*-profile-short-config.json')):
 if '-final-' in p.name or '-cycle-ablation-' in p.name:add(p,'application/'+p.name)
for p in Path('build/bench/iteration/run-192e9ebef5b8faa0').glob('*'):
 if p.is_file():add(p,'gate/'+p.name)
for p in Path('build/bench/iteration/native-execution/run-6d72872430708a5f').glob('*'):
 if p.is_file():add(p,'native/'+p.name)
add('build/bench/iteration/timings.json','gate/timings.json')
for p in Path('benchmarks/runtime-boundaries').glob('*'):
 if p.is_file():add(p,'sources/'+p.name)
for p in [Path('scripts/bench')/n for n in ['runtime_boundaries.ts','runtime_boundaries_browser.ts','runtime_boundaries_wasmtime.py','profile_memory.ts']]:add(p,'runners/'+p.name)
manifest={name:hashlib.sha256(data).hexdigest() for name,data in sorted(files.items())}
files['manifest.json']=(json.dumps(manifest,indent=2)+'\n').encode()
p=Path('zig-native/measurements/runtime-memory-2026-10-26.tar.gz')
with tarfile.open(p,'w:gz') as archive:
 for name,data in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mtime=0;info.mode=0o644;archive.addfile(info,io.BytesIO(data))
with tarfile.open(p) as archive:
 loaded=json.load(archive.extractfile('manifest.json'))
 for name,digest in loaded.items():assert hashlib.sha256(archive.extractfile(name).read()).hexdigest()==digest
print(p,p.stat().st_size,hashlib.sha256(p.read_bytes()).hexdigest(),len(files),'files verified')
