From the repository root at 52798173, build the compiler to populate
compiler-goose/build/stages. Extract the archive into an empty build/type-shapes.
Run python3 build/type-shapes/probe.py, then python3 build/type-shapes/analyze.py.
Next run python3 build/type-shapes/causes/run.py and then causes/summarize.py.
The profiler uses Linux x86-64, nm, clang and buffered files per worker module.
Use an empty directory for each run. The summaries are included for inspection.
In function-change-rows.json bits 0, 1 and 2 identify changed parameter, result
and effect row IDs. Bit 3 means both rows have empty labels and equal cursor
and tail, bit 4 equal tails, bit 5 different cursors and bit 6 empty labels.
