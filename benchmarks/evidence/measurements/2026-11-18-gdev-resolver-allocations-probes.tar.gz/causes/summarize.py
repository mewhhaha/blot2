from pathlib import Path
import struct,bisect,subprocess,json,re,collections
d=Path(__file__).resolve().parent
symbols=[(int(a,16),n) for a,t,n in (line.split() for line in subprocess.check_output(['nm','-n',d/'probe'],text=True).splitlines() if len(line.split())==3) if t.lower()=='t']
off=[a for a,n in symbols];counts=collections.Counter()
for f in d.glob('why-*'):
 for addr,flags in struct.iter_unpack('<II',f.read_bytes()):
  n=re.sub('_g[0-9]+.*','',symbols[bisect.bisect_right(off,addr-1)-1][1])
  counts[n,flags]+=1
assert sum(counts.values())==341886
rows=[{'caller':n,'bits':b,'count':v} for (n,b),v in sorted(counts.items())]
(d/'changes.json').write_text(json.dumps(rows,indent=2)+'\n')
for name in ('all','blot_check_check_finishNormalized', 'blot_check_check_applicationFlow','blot_check_check_ordinaryApplication'):
 why=collections.Counter();row=collections.Counter()
 for (caller,flags),v in counts.items():
  if name!='all' and caller!=name:continue
  why[flags&7]+=v
  if flags&4:row[(bool(flags&8),bool(flags&16),bool(flags&32),bool(flags&64))]+=v
 print(name,why,row)
