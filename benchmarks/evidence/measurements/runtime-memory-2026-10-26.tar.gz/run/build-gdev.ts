import { resolve } from "node:path";
import { createZigProjectCompiler } from "../../compiler/zig_project_client.ts";
const root = resolve("../gdev/.gdev/bench/captures/architecture-slots/sources");
const assets = resolve("../gdev/.gdev/bench/captures/architecture-slots/game/assets");
const assetImports = [];
for await (const item of Deno.readDir(assets)) {
 if (item.name.endsWith(".wgsl")) assetImports.push({module:`${root}/game/assets/${item.name}.blot`,path:`${assets}/${item.name}`,kind:"wgsl" as const});
}
assetImports.push({module:`${root}/game/assets/catalog.json.blot`,path:`${assets}/catalog.json`,kind:"catalog" as const});
const executable = resolve(Deno.args[0] ?? "build/issue-fixes/candidate-blotc");
const name = Deno.args[1] ?? "gdev-baseline";
const openedAt = performance.now();
const compiler = await createZigProjectCompiler({ executable, entry: `${root}/game/main.blot`,
  prelude: `${root}/std/prelude.blot`, stdRoot: `${root}/std`,
  imports: {"ink/":`${root}/ink/`, "game/":`${root}/game/`, "pen/":`${root}/bindings/`},
  nativeAssets: {roots:[`${root}/game`],imports:[...assetImports,{module:`${root}/game/system_names.json.blot`,path:`${root}/game/system_names.json`,kind:"text"}]},
  inferenceBudget:20000000, cacheDirectory:false, ...(Deno.args[2] === "profile" ? {profileMemory:true} : {}),
});
async function usage() {
 const stat = await Deno.readTextFile(`/proc/${compiler.pid}/stat`);
 const fields = stat.slice(stat.lastIndexOf(") ") + 2).trim().split(/\s+/);
 const status = await Deno.readTextFile(`/proc/${compiler.pid}/status`);
 return { ticks: Number(fields[11]) + Number(fields[12]), peak_rss_kib: Number(status.match(/^VmHWM:\s+(\d+)/m)?.[1] ?? 0) };
}
try {
 const before = await usage();
 const started = performance.now();
 const built=await compiler.build();
 const finished = performance.now();
 const after = await usage();
 if(!built.success) throw Error(JSON.stringify(built.diagnostics));
 await Deno.writeFile(`build/remaining-runtime/${name}.wasm`,built.bytes);
 await Deno.writeTextFile(`build/remaining-runtime/${name}-compile.json`,JSON.stringify({stats: built.stats, measurement: {build_wall_ms: finished-started, open_and_build_wall_ms: finished-openedAt, compiler_cpu_ms: (after.ticks-before.ticks)*10, compiler_peak_rss_kib: after.peak_rss_kib, wasm_bytes: built.bytes.length, scope: "Fresh native build including native assets, with retained/restart caches disabled; CPU excludes process startup/project opening; RSS is compiler process only."}},null,2));
 console.log(`${name}: ${built.bytes.length} bytes`);
} finally {await compiler.dispose();}
