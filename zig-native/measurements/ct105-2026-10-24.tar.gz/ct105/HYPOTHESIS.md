# CT105 acceptance before final paired release measurements

Baseline: installed qualified 5cfb4117, native SHA
0185500e446d59d6e813de8cecb3318bcc5983632043eb0129b8a64bad45ee9f.
Frozen manifest d54b0078ea7c8f94fae131e19f7ea46699891d6aba14b61803386595e9704146.
Seven alternating pairs, identical optimized/four-codegen-worker settings,
restart cache disabled in edit series, strict prior Wasm hashes.

Target: >=10% lower median within-pair process CPU for literal and body edits;
no >5% CPU regression on fresh game or devtools. Report individual wall/CPU
medians and paired ratios separately; shared-host latency is not guaranteed.
Sub-second ordinary edits remain an independent unmet goal unless demonstrated.

Work target: remove whole-region lexical scans; reduce argument visits >=40%
fresh and >=30% later literal by replacing collision-prone row certificates.
Report extra solver allocation/RSS from the dense cache; it must not silently
trade an unbounded retained cache for local speed. Final dense payload is4bytes
per row, owned by the solver, with the original epoch/generation gates.

Frontend: exact producer-qualified binding and catalog indexes should avoid
quadratic-budget fallbacks. A remaining semantic graph/contract mismatch must
stay a decline; do not weaken it to force a benchmark hit. Principal observation
completeness alone has not removed the four body regions: consumed module-image
and identity mismatches remain. Report this negative result explicitly.

Required acceptance: complete exhaustive native/guest compiler gate, zero Zig
lint; fresh/edit/revert/restart Wasm equality, unseen edits checked against fresh
compilers, and unchanged input manifests. Development passes are not full gates.
