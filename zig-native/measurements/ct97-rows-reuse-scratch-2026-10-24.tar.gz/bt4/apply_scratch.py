from pathlib import Path
import re
out=Path('build/bench/bt4/originals');out.mkdir(exist_ok=True)
def transform(path, names, size, owner):
 p=Path(path);s=p.read_text();(out/p.name).write_text(s)
 for name in names:
  pattern=re.compile(r'    (?:pub )?fn '+name+r'\([^\n]*\{\n')
  m=pattern.search(s);assert m,name
  end=s.find('\n    }',m.end());block=s[m.start():end]
  allocator=owner[name] if isinstance(owner,dict) else owner
  declaration=f'        var scratch_buffer: [{size}]u8 align(@alignOf(usize)) = undefined;\n        var scratch: std.heap.BufferFirstAllocator = .init(&scratch_buffer, {allocator});\n        const temporary = scratch.allocator();\n'
  block=block.replace(allocator,'temporary')
  at=block.index('\n')+1;block=block[:at]+declaration+block[at:]
  # Keep durability at the existing owning destination, never return scratch.
  if name=='exportMappings':
   block=block.replace('errdefer mappings.deinit(temporary);','defer mappings.deinit(temporary);').replace('return mappings.toOwnedSlice(temporary);',f'return {allocator}.dupe(type_evidence.Mapping, mappings.items);')
  if name=='exportSolved':
   block=block.replace('errdefer rows.deinit(temporary);','defer rows.deinit(temporary);').replace('temporary.free(mappings)',allocator+'.free(mappings)').replace('temporary.dupe(core.BindingRef',allocator+'.dupe(core.BindingRef').replace('temporary.free(selected)',allocator+'.free(selected)').replace('try rows.toOwnedSlice(temporary)',f'try {allocator}.dupe(type_evidence.RowMapping, rows.items)')
  s=s[:m.start()]+block+s[end:]
 p.write_text(s)
transform('zig-native/src/backend/layout.zig',['fromSolverRow','toEvidenceRow','fromEvidenceRow','fromTypeRow'],128,{'fromSolverRow':'self.allocator','toEvidenceRow':'target.allocator','fromEvidenceRow':'self.allocator','fromTypeRow':'self.allocator'})
transform('zig-native/src/backend/core_backend.zig',['mappingEvidence','rowMappingEvidence'],128,'self.allocator')
transform('zig-native/src/eval/core_eval.zig',['exportMappings','exportSolved','closeCertificates'],512,'self.session.allocator')
