"""Archive public compiler evidence; omit binaries, caches and private workload sources."""
from pathlib import Path
import json,hashlib,gzip,tarfile,io
base=Path(__file__).resolve().parent; repo=base.parents[2]; payload={}
sha=lambda b:hashlib.sha256(b).hexdigest()
def add(path,name):
 data=path.read_bytes()
 if path.suffix=='.json':
  j=json.loads(data)
  if isinstance(j,dict) and 'native_qualification' in j:
   for item in j['native_qualification'].values():
    if 'key' in item:item['key_sha256']=sha(item.pop('key').encode())
   data=(json.dumps(j,indent=2)+'\n').encode()
 payload[name]=data
suffixes={'.json','.jsonl','.log','.xml','.txt','.py','.ts','.patch','.sha256'}
for root,prefix in [(base,'ct97'),(base.parent/'bt4','bt4')]:
 for p in root.iterdir():
  if p.is_file() and p.suffix in suffixes and p.name not in ['archive-report.log']:
   add(p,prefix+'/'+p.name)
add(base/'implementation-notes.md','ct97/implementation-notes.md')
for directory in ['row-diagnostic','prefix-screen','prefix-oom','prefix-release-screen','reuse-profile','jump-screen','final-gate','final-cold','final-retained','final-phases','native-screen']:
 for p in (base/directory).rglob('*'):
  if p.is_file() and p.suffix in suffixes and 'cache' not in p.relative_to(base/directory).parts:add(p,'ct97/'+str(p.relative_to(base)))
for snapshot in ['jump-src','final-src']:
 for p in (base/snapshot/'build/bench/check-dev').rglob('*'):
  if p.is_file() and p.suffix in suffixes:add(p,'ct97/'+str(p.relative_to(base)))
for p in (base.parent/'bt4/trial2-oom').iterdir():
 if p.is_file() and p.suffix in suffixes:add(p,'bt4/trial2-oom/'+p.name)
pins=json.loads((base/'final-inputs.json').read_text())
for name,digest in pins['files'].items():
 p=base/'final-src'/name;assert sha(p.read_bytes())==digest
 add(p,'candidate-source/'+name)
for name in ['manifest.json','wasm.json','host.json']:
 add(repo/'build/bench/compile-cost-20261023'/name,'workload-pins/'+name)
summary=json.loads((base/'final-summary.json').read_text());assert summary['targets']['CT97_met'] and summary['targets']['unaffected_devtools']
payload['SHA256SUMS']=''.join(f'{sha(data)}  {name}\n' for name,data in sorted(payload.items())).encode()
archive=repo/'zig-native/measurements/ct97-rows-reuse-scratch-2026-10-24.tar.gz'
with archive.open('wb') as raw,gzip.GzipFile(fileobj=raw,mode='wb',filename='',mtime=0) as gz,tarfile.open(fileobj=gz,mode='w') as tar:
 for name,data in sorted(payload.items()):
  info=tarfile.TarInfo(name);info.size=len(data);info.mode=0o644
  tar.addfile(info,io.BytesIO(data))
with tarfile.open(archive) as tar:
 for line in tar.extractfile('SHA256SUMS').read().decode().splitlines():
  digest,name=line.split('  ',1);assert sha(tar.extractfile(name).read())==digest,name
print(json.dumps({'archive':str(archive),'bytes':archive.stat().st_size,'sha256':sha(archive.read_bytes()),'files':len(payload)},indent=2))
