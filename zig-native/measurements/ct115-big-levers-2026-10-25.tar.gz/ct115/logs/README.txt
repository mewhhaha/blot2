blot-ct115-dev-build.log is an initial main-worktree Safe/noLLVM build, not the diagnostic build.
diagnostic-dev/release-build logs belong to the isolated observational compiler.
topology-build uses Safe/noLLVM; topology clocks are excluded from release cost models.
