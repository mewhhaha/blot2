from pathlib import Path
p=Path('zig-native/src/reuse/declaration_projection.zig');s=p.read_text()
anchor='/// Scratch belongs to one immutable module pair.'
s=s.replace(anchor,'''fn shiftedPoint(old: u32, current: u32, shift: i64) bool {
    return old == current or @as(i64, current) - @as(i64, old) == shift;
}
/// Only diagnostic positions move. Every non-position field remains exact;
/// inconsistent movement within a declaration conservatively declines.
fn normalizePositions(comptime Item: type, old: *Item, current: Item, shift: i64) Error!void {
    if (Item == core.Span) {
        if (!shiftedPoint(old.start, current.start, shift) or !shiftedPoint(old.end, current.end, shift)) return error.Changed;
        old.* = current;
    } else if (comptime @typeInfo(Item) == .@"struct") {
        inline for (@typeInfo(Item).@"struct".field_names) |field| try normalizePositions(@TypeOf(@field(old.*, field)), &@field(old.*, field), @field(current, field), shift);
    }
}

'''+anchor,1)
s=s.replace('return self.run(old, current, binding, closures, constant_types, 0, null);','return self.run(old, current, binding, closures, constant_types, 0, null, &.{});',1)
s=s.replace('    fn run(self: *Workspace,','''    /// Origins were proved unique by the caller for this exact module pair.
    /// They permit only translating positions; IDs, graph edges and payloads
    /// remain exact and no executable validity is established here.
    pub fn definitionEqualWithOrigins(self: *Workspace, old: *const core.Module, current: *const core.Module, binding: u32, closures: ?*std.ArrayList(u32), constant_types: bool, origins: []const bool) Allocator.Error!bool {
        return self.run(old, current, binding, closures, constant_types, 0, null, if (binding < origins.len and origins[binding]) origins else &.{});
    }
    fn run(self: *Workspace,''',1)
s=s.replace('reached: ?*std.ArrayList(core.Id)) Allocator.Error!bool {\n        if (binding == 0','reached: ?*std.ArrayList(core.Id), origins: []const bool) Allocator.Error!bool {\n        if (binding == 0',1)
s=s.replace('        defer self.visits += scan.visits;','''        scan.origins = origins;
        if (origins.len != 0) scan.source_shift = @as(i64, current.sourceNamePoint(binding)) - @as(i64, old.sourceNamePoint(binding));
        defer self.visits += scan.visits;''',1)
s=s.replace('    constant_types: bool = false,','''    constant_types: bool = false,
    origins: []const bool = &.{},
    source_shift: i64 = 0,
    fn bindingShift(self: *const Scan, id: usize) i64 {
        if (self.old.bindings[id].kind != .global) return self.source_shift;
        if (id >= self.origins.len or !self.origins[id]) return 0;
        return @as(i64, self.current.sourceNamePoint(@intCast(id))) - @as(i64, self.old.sourceNamePoint(@intCast(id)));
    }
    fn projectedSlice(self: *const Scan, comptime Item: type, old: []const Item, current: []const Item, list: core.List) Error![]const Item {
        if (self.origins.len == 0) return equalSlice(Item, old, current, list);
        if (list.start > old.len or list.len > old.len - list.start or list.start > current.len or list.len > current.len - list.start) return error.Changed;
        const result = old[list.start..][0..list.len];
        for (result, current[list.start..][0..list.len]) |before, after| {
            var normalized = before;
            try normalizePositions(Item, &normalized, after, self.source_shift);
            if (!std.meta.eql(normalized, after)) return error.Changed;
        }
        return result;
    }''',1)
s=s.replace('        if (!self.constant_types) return equalItem(Item, left, right, id);','        if (!self.constant_types and self.origins.len == 0) return equalItem(Item, left, right, id);',1)
s=s.replace('        var normalized = left[id];\n        if (comptime','''        var normalized = left[id];
        if (self.origins.len != 0) try normalizePositions(Item, &normalized, right[id], if (Item == core.Binding) self.bindingShift(id) else self.source_shift);
        if (comptime''',1)
s=s.replace('            if (!equalConstantType(self.old.types, normalized.ty, self.current.types, right[id].ty))','            if (!self.constant_types and normalized.ty != right[id].ty) return error.Changed;\n            if (!equalConstantType(self.old.types, normalized.ty, self.current.types, right[id].ty))',1)
s=s.replace('            if (!equalConstantType(self.old.types, normalized.scheme.root, self.current.types, right[id].scheme.root))','            if (!self.constant_types and normalized.scheme.root != right[id].scheme.root) return error.Changed;\n            if (!equalConstantType(self.old.types, normalized.scheme.root, self.current.types, right[id].scheme.root))',1)
# Change only the Scan call sites, never the global exact helper or Workspace.
a=s.index('const Scan = struct');b=s.index('\n/// Does not by itself',a);section=s[a:b];section=section.replace('try equalSlice(', 'try self.projectedSlice(').replace('return equalSlice(u32, self.old.extra','return self.projectedSlice(u32, self.old.extra');section=section.replace('                if (self.old.sourceNamePoint(id) != self.current.sourceNamePoint(id)) return error.Changed;\n                if (self.old.runtimeNamePoint(id) != self.current.runtimeNamePoint(id)) return error.Changed;','''                const shift = if (self.origins.len != 0) self.bindingShift(id) else 0;
                if (!shiftedPoint(self.old.sourceNamePoint(id), self.current.sourceNamePoint(id), shift)) return error.Changed;
                if (!shiftedPoint(self.old.runtimeNamePoint(id), self.current.runtimeNamePoint(id), shift)) return error.Changed;''');s=s[:a]+section+s[b:]
s=s.replace('return workspace.run(old, current, binding, closures, constant_types, expression, reached);','return workspace.run(old, current, binding, closures, constant_types, expression, reached, &.{});',1);p.write_text(s)
p=Path('zig-native/src/reuse/principal_reuse_gate.zig');s=p.read_text().replace('workspace.definitionEqual(pin.module, &module, @intCast(id), &reached, constant_types)','workspace.definitionEqualWithOrigins(pin.module, &module, @intCast(id), &reached, constant_types, call_origins[offsets[unit]..offsets[unit + 1]])');p.write_text(s)
p=Path('zig-native/src/reuse/principal_reuse_gate_tests.zig');s=p.read_text().replace('try std.testing.expect(!gate.admitsLocalSource(later));','try std.testing.expect(gate.admitsLocalSource(later));\n    try std.testing.expect(!gate.admits(later));',1).replace('try std.testing.expect(!shifted.admitsLocalSource(earlier));','try std.testing.expect(shifted.admitsLocalSource(earlier));',1);s=s.replace('shifted source positions keep the catalog while shifted declarations are revoked','shifted declaration origins preserve exact relative bodies and revoke changed payloads');s=s.replace('try std.testing.expect(!gate.admitsLocalSource(target(&after.units[0], "doubled")));','try std.testing.expect(gate.admitsLocalSource(target(&after.units[0], "doubled")));',1).replace('try std.testing.expect(!gate.admitsLocalSource(target(&after.units[0], "late")));','try std.testing.expect(gate.admitsLocalSource(target(&after.units[0], "late")));',1);p.write_text(s)
p=Path('scripts/dev_check_areas.ts');s=p.read_text();anchor='      "reuse.principal_reuse_gate_tests.test.declaration projection workspace isolates declined scans generation rollover and allocation failure",';s=s.replace(anchor,anchor+'\n      "reuse.principal_reuse_gate_tests.test.shifted declaration origins preserve exact relative bodies and revoke changed payloads",\n      "reuse.principal_reuse_gate_tests.test.declaration principal projection checks call arguments record destinations tags and binding metadata",',1);p.write_text(s)
