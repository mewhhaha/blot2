import json, statistics, collections
from pathlib import Path
p=Path(__file__).parent
rows=[json.loads(l) for l in (p/'phases/samples.jsonl').read_text().splitlines()]
def med(xs):return statistics.median(xs)
phase=[]
for workload in ['game','devtools']:
 for key in dict.fromkeys(r['phase'] for r in rows if r['workload']==workload):
  base=[r for r in rows if r['workload']==workload and r['phase']==key and r['variant']=='baseline']
  prof=[r for r in rows if r['workload']==workload and r['phase']==key and r['variant']=='candidate']
  s=prof[0]['stats'];ph=s['phaseProfile']['phases']
  item=dict(workload=workload,phase=key,wall_ms=med([r['wall_ms'] for r in base]),cpu_ms=med([r['cpu_ms'] for r in base]),profile_cpu_change_pct=100*(med([r['cpu_ms'] for r in prof])/max(1,med([r['cpu_ms'] for r in base]))-1),phase_ms={k:med([r['stats']['phaseProfile']['phases'][k]['us']/1000 for r in prof]) for k in ph},phase_allocations={k:{f:v[f] for f in ['requested_bytes','allocations']} for k,v in ph.items()},backend_timing=s['backendTiming'],work=s['workCounters'],principals=s['principals'],backend=s['backend'],frontend=s['frontend'],selected=s['selectedQueries'],modules={k:s[k] for k in ['freshModules','cachedModules']})
  phase.append(item)
profiles=[]
for mode in ['fresh','literal','body']:
 root=p/f'stacks-{mode}'
 builds=[json.loads(l) for l in (root/'builds.jsonl').read_text().splitlines()]
 samples=[json.loads(l) for l in (root/'samples.jsonl').read_text().splitlines()]
 for build in builds:
  if not build['sampled']:continue
  counts={k:collections.Counter() for k in ['self','inclusive','directory','copy_callers','sort_callers','heap_callers']};previous={};total=0;intervals=0
  for row in samples:
   run,end=row['run'],row['wall_ns']/1e6;start=previous.get(run);previous[run]=end
   if start is None or not(build['run']==run and build['started_ms']<=start<=end<=build['finished_ms']):continue
   intervals+=1
   for stack,weight in zip(row['st'],row['cpu_ns']):
    if weight is None or weight<=0:continue
    total+=weight
    if not stack:continue
    counts['self'][stack[0][0]]+=weight
    for name in set(f[0] for f in stack):counts['inclusive'][name]+=weight
    owned=next((f for f in stack if '/zig-native/src/' in f[1]),None)
    counts['directory'][owned[1].split('/zig-native/src/',1)[1].split('/')[0] if owned else 'unknown']+=weight
    for group,match in [('copy_callers',lambda n: n.startswith('compiler_rt.mem')),('sort_callers',lambda n: n.startswith('sort.')),('heap_callers',lambda n: n.startswith('runtime.session_heap.Heap'))]:
     if match(stack[0][0]):
      caller=next((f[0] for f in stack[1:] if '/zig-native/src/' in f[1] and not f[0].startswith(('runtime.session_heap.','phase_profile.','eval.parallel_allocator.','runtime.memory.'))),'unknown')
      counts[group][caller]+=weight
  profiles.append(dict(mode=mode,label=build['label'],coverage=total/1e6/build['cpu_ms'],intervals=intervals,**{k:[dict(name=name,percent=100*ns/total,ms=ns/1e6) for name,ns in counter.most_common()] for k,counter in counts.items()}))
memory=[]
if (p/'memory-series-success.json').exists():
 for row in map(json.loads,(p/'memory-series.jsonl').read_text().splitlines()):
  samples=row['samples'];first,last=samples[0],samples[-1];baseline=first['threads'];maxima={}
  for sample in samples:
   for tid,values in sample['threads'].items():maxima[tid]=[max(a,b) for a,b in zip(maxima.get(tid,[0,0,0]),values)]
  threads=[dict(tid=tid,cpu_ms=(v[0]-baseline.get(tid,[0,0,0])[0])/1e6,wait_ms=(v[1]-baseline.get(tid,[0,0,0])[1])/1e6) for tid,v in maxima.items()]
  threads.sort(key=lambda x:-x['cpu_ms']);thread_cpu=sum(t['cpu_ms'] for t in threads)
  kib=lambda s,k:int(s['status'].get(k,'0 kB').split()[0])
  memory.append(dict(revision=row['revision'],wall_ms=row['wall_ms'],cpu_ms=row['cpu_ms'],rss_end_mib=kib(last,'VmRSS')/1024,rss_sample_peak_mib=max(kib(s,'VmRSS') for s in samples)/1024,hwm_mib=kib(last,'VmHWM')/1024,anon_mib=kib(last,'RssAnon')/1024,swap_mib=kib(last,'VmSwap')/1024,minor_faults=last['minor_faults']-first['minor_faults'],major_faults=last['major_faults']-first['major_faults'],thread_cpu_ms=thread_cpu,thread_coverage=thread_cpu/row['cpu_ms'],largest_thread_share=threads[0]['cpu_ms']/thread_cpu,runqueue_wait_ms=sum(t['wait_ms'] for t in threads),threads=threads,smaps=last['smaps']))
out=dict(phases=phase,profiles=profiles,memory=memory)
(p/'analysis.json').write_text(json.dumps(out,indent=2)+'\n')
for x in phase:
 if x['workload']=='game': print(x['phase'],round(x['wall_ms']),x['cpu_ms'],'profile%',round(x['profile_cpu_change_pct'],1),'alloc MiB', {k:round(v['requested_bytes']/2**20) for k,v in x['phase_allocations'].items() if k in ['check','backend']})
for x in profiles:
 print('\nPROFILE',x['mode'],x['label'],'coverage',round(x['coverage']*100,2))
 for k in ['copy_callers','sort_callers','heap_callers']:print(k,[(v['name'],round(v['percent'],2)) for v in x[k][:4]])
 print('inference callers',[(v['name'],round(v['percent'],2)) for v in x['inclusive'] if any(t in v['name'] for t in ['bodyEvidenceMode','collectWithExit','solveStep','importType','resolveOperationRow','wakeAll','closedHeight','retained_revision.Session.mixedFrontend'])])
for x in memory: print('MEM', {k:round(v,3) if isinstance(v,float) else v for k,v in x.items() if k not in ['threads','smaps']})

# PERF_EVENT_IOC_RESET resets counts but not enabled/running time. Take time
# deltas across the retained sequence before computing per-build scaling.
if (p/'pmu-series-success.json').exists():
    previous = {}
    pmu = []
    for row in map(json.loads, (p/'pmu-series.jsonl').read_text().splitlines()):
        if not row.get('counters'): continue
        values, ratios = {}, {}
        for key, value in row['counters'].items():
            before = previous.get(key, (0, 0))
            enabled = value['time_enabled_ns'] - before[0]
            running = value['time_running_ns'] - before[1]
            previous[key] = (value['time_enabled_ns'], value['time_running_ns'])
            values[key] = value['raw'] * enabled / running
            ratios[key] = running / enabled
        pmu.append(dict(revision=row['revision'], user_ms=row['user_ms'], system_ms=row['system_ms'], values=values, running_ratios=ratios, ipc=values['instructions']/values['cycles'], branch_miss_pct=100*values['branch_misses']/values['branches'], cache_miss_pct=100*values['cache_misses']/values['cache_references'], cache_mpki=1000*values['cache_misses']/values['instructions']))
    (p/'pmu-analysis.json').write_text(json.dumps(pmu, indent=2)+'\n')
