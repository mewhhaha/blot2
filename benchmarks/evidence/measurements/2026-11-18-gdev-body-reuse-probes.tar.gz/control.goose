import support.project_packet;
import support.native;
import support.error;
import direct.direct;
import direct.emit;
import direct.types;
import direct.writer;
import direct.function;
import check.core;
import body_guard;

type Core = blot_check_core::Module;
extern fn packetSize(version:u32,unit:u32)->i64="body_packet_size";
extern fn packetRead(version:u32,unit:u32,data:u8&,size:i64)="body_packet_read";
extern fn rss()->u64="body_rss";
extern fn referenceFirst()->bool="body_reference_first";
extern fn seal()="body_seal";
extern fn hasReaders(id:u32)->bool="body_affected";
extern fn hasUntrackedReader()->bool="body_decline";
extern fn changedNode(unit:u32,node:u32,count:u32)="body_changed_node";
extern fn inferred(function:u32)->bool="body_inferred";
extern fn stat(key:u32,value:u64)="body_stat";
extern fn save(kind:u32,data:const u8&,size:i64)="body_save";
reusable[] var buffers:u8[>..];
reusable[] var catalog:Core[>..];

fn readCore(owner:blot_project_packet::Owner, bytes:const u8[:], unit:u32, core:Core&)->i64 {
    var reader=blot_project_packet::Reader{bytes,owner};
    var id:u32=0;
    blot_project_packet::get(reader,id);
    blot_project_packet::get(reader,core);
    assert(reader.failure==blot_error::Error.none && id==unit && core.unit==unit);
    return reader.at;
}

fn emitStock(units:const Core[:],entry:u32,kind:u32) {
    var wasm:u8[>..<]=[];
    var detail:u8[>..<]=[];
    let start=blot_native::clock_ns();
    let result=blot_direct::compile(units,entry,wasm,detail);
    stat(kind,blot_native::clock_ns()-start);
    assert(!result.failed);
    save(kind,wasm[0],wasm.len);
}
fn trial(old:const Core[:], updated:const Core[:], dirty:const bool[:], entry:u32) {
    if referenceFirst() {emitStock(updated,entry,8);emitStock(old,entry,1);}
    else {emitStock(old,entry,1);emitStock(updated,entry,8);}
}
fn main() {
    let owner,err=blot_project_packet::initOwner();assert(err==blot_error::Error.none);
    let newOwner,newErr=blot_project_packet::initOwner();assert(newErr==blot_error::Error.none);
    let old=catalog.alloc_slice(269);
    let updated=catalog.alloc_slice(269);
    var dirty:bool[269]=[false;269];
    var entry:u32=0;
    for i in 0..269 {
        let unit=(i+1) as u32;
        let n=packetSize(0,unit);let m=packetSize(1,unit);
        let a=buffers.alloc_slice(n);packetRead(0,unit,a[0],n);
        let b=buffers.alloc_slice(m);packetRead(1,unit,b[0],m);
        var core=default<Core>();
        let priorEnd=readCore(owner,a,unit,core);old[i]=core;
        var changed=default<Core>();
        let editedEnd=readCore(newOwner,b,unit,changed);updated[i]=changed;
        if !body_guard::same_check_core_Module(old[i],updated[i],true) {dirty[i]=true;stat(11,unit);}
        for body in core.bodies {
            if body.exported {stat(13,unit);entry=unit;}
        }
        buffers.free_slice(b);buffers.free_slice(a);
    }
    assert(entry!=0);
    trial(old,updated,dirty[..],entry);
}
