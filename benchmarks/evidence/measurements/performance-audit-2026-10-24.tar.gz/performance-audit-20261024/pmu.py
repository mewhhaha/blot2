import ctypes,os,sys,json,struct,fcntl
class Attr(ctypes.Structure):
 _fields_=[('type',ctypes.c_uint),('size',ctypes.c_uint),('config',ctypes.c_ulonglong),('sample_period',ctypes.c_ulonglong),('sample_type',ctypes.c_ulonglong),('read_format',ctypes.c_ulonglong),('flags',ctypes.c_ulonglong),('rest',ctypes.c_byte*72)]
libc=ctypes.CDLL(None,use_errno=True);fds={};tid=int(sys.argv[1])
try:
 for name,config in [('cycles',0),('instructions',1),('cache_references',2),('cache_misses',3),('branches',4),('branch_misses',5)]:
  a=Attr();a.size=ctypes.sizeof(a);a.config=config;a.flags=1|(1<<5)|(1<<6);a.read_format=3
  fd=libc.syscall(298,ctypes.byref(a),tid,-1,-1,0)
  if fd<0:raise OSError(ctypes.get_errno(),os.strerror(ctypes.get_errno()))
  fds[name]=fd
 print(json.dumps({'ready':True,'tid':tid,'scope':'one compiler thread, user space only, no inheritance','events':'generic PERF_TYPE_HARDWARE, not AMD-specific raw events'}),flush=True)
 for command in sys.stdin:
  if command.strip()=='start':
   for fd in fds.values():fcntl.ioctl(fd,0x2403,0);fcntl.ioctl(fd,0x2400,0)
   print('{"started":true}',flush=True)
  elif command.strip()=='stop':
   for fd in fds.values():fcntl.ioctl(fd,0x2401,0)
   r={}
   for name,fd in fds.items():
    value,enabled,running=struct.unpack('QQQ',os.read(fd,24))
    r[name]={'raw':value,'time_enabled_ns':enabled,'time_running_ns':running,'running_ratio':running/enabled if enabled else 0,'scaled':value*enabled/running if running else None}
   print(json.dumps(r),flush=True)
  elif command.strip()=='quit':break
finally:
 for fd in fds.values():os.close(fd)
