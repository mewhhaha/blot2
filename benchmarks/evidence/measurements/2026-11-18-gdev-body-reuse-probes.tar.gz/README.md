# Retained function-body experiment

This standalone Linux benchmark consumes Core from actual Gdev Main builds.
The installed compiler serves as the oracle. The prototype has one baseline
revision and accepts scalar-literal changes that preserve the remaining
backend inputs. It records which emitted instances read each literal,
including scalar evaluation through imported `#run` calls. A structural
change uses full emission.

Use the revisions and toolchain recorded in the adjacent measurement. Extract
this archive into an empty `build/body-reuse/` in Blot. Run the commands below
from the Blot repository root, with the three sibling checkouts in place.
The capture files and generated C take about 1 GiB.

```sh
deno task build:compiler
python3 compiler-goose/tools/test_engines.py packet_list
python3 build/body-reuse/capture_compiler.py
deno run -A build/body-reuse/capture.ts build/body-reuse build/body-reuse/capture
deno run -A build/body-reuse/capture.ts build/body-reuse compiler-goose/build/blotc-goose --verify
python3 build/body-reuse/build.py
python3 build/body-reuse/build.py --control
python3 build/body-reuse/run.py
python3 build/body-reuse/timing.py
deno run -A build/body-reuse/release.ts > build/body-reuse/release.jsonl
```

The capture compiler uses an observing wrapper around the real packet
publisher. Its output is checked against an independent optimized fresh build
of every overlay. Each probe decodes all 269 modules. Dirty units are
identified by their portable fields outside the timer, standing in for the
set provided by the retained frontend. Comparator generation uses the source
wire schema. The edit guard compares all portable fields except scalar
literal values and source positions. The probe follows runtime and staged
reads across module boundaries. Inference-mode instances re-enter the
emitter in their original mode.

The control builds the original emitter. The probe adds read tracking,
an owned fixed diagnostic buffer and a flag recording result inference.
The separate executable and the within-process oracle each emit the whole
module again. During ordinary timing, the experiment alternates process
order and oracle order. Timers exclude input file access, output checks and
the initial construction of the retained state. Output assembly is included.
The capture and engine phases have no role in the reported release times.

For a sequence of 512 reversible edits, use the following environment for both
runs. Each generated Wasm image must match the corresponding release image.
The second command forks from the immutable, warmed emitter for every edit,
reads the complete reply through a pipe, and waits for the child. The edit
comparison is timed once and added to each child latency. Both input catalogs
are already in the parent for this backend-only experiment.

```sh
export BLOT_BASE=build/body-reuse/base BLOT_EDIT=build/body-reuse/boolean
export BLOT_BASE_WASM="$BLOT_BASE/main.wasm" BLOT_EDIT_WASM="$BLOT_EDIT/main.wasm"
BLOT_REPEAT=512 build/body-reuse/probe > build/body-reuse/soak.log
BLOT_REPEAT=512 BLOT_SNAPSHOT=1 build/body-reuse/probe > build/body-reuse/snapshot512.log
```

Native metrics 1 and 8 time the full initial and edited backend. Metrics 2
and 3 time change detection plus re-emission, then assembly or the full
fallback. Times are nanoseconds. Metrics 4 through 6 count rebuilt instances,
original functions and newly allocated functions. Metric 10 records exact
oracle equality. Metric 11 records dirty units. Metric 14 gives the fallback
reason (0 admitted, 1 wrapper, 2 structural, 3 failed re-emission, 4 new
layout). Metrics 15–17 record initial RSS growth, literal reads and reserved
read-index bytes. Metrics 20–24 cover repeated edits, appended module bytes,
temporary values, temporary words and RSS growth. Metric 30 is the immutable
snapshot round trip, including fork, real Wasm delivery and child exit.
