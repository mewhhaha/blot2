from pathlib import Path
import argparse,json,subprocess
d=Path(__file__).resolve().parent
root=Path.cwd().resolve()
parser=argparse.ArgumentParser()
parser.add_argument('--opt',default='-O2')
parser.add_argument('--control',action='store_true')
args=parser.parse_args()
name='probe'
if args.control:name='control'
src=d/('src-'+name);src.mkdir(exist_ok=True)
for p in (root/'compiler-goose/src').iterdir():
    if p.name=='main.goose':continue
    if not (src/p.name).exists():(src/p.name).symlink_to(p)
if not (src/'main.goose').exists():(src/'main.goose').symlink_to(d/('control.goose' if args.control else 'main.goose'))
if not args.control:
    direct=src/'direct'
    if direct.is_symlink():direct.unlink()
    direct.mkdir(exist_ok=True)
    for module in (root/'compiler-goose/src/direct').iterdir():
        dest=direct/module.name
        if module.name=='types.goose':
            import re
            text=module.read_text().replace('failure_reason: Text = "",','failure_reason: u8[256] = [0;256], failure_len:i64=0,')
            text=re.sub(r'self_\.failure_reason = (.*?);',r'{let why:const u8[:]=\1;assert(why.len<=256);self_.failure_len=why.len;for ch,i in why {self_.failure_reason[i]=ch;}}',text)
            dest.write_text(text)
        elif module.name=='emit.goose':
            dest.write_text(module.read_text().replace('put(g, g.types.failure_reason);','put(g, g.types.failure_reason[..g.types.failure_len]);'))
        elif module.name=='function_entry.goose':
            if dest.is_symlink():dest.unlink()
            text=module.read_text()
            marker='    let s .= g.s;\n    let code_mark = s.code.len;'
            assert text.count(marker)==1
            text=text.replace(marker,'    if g.s.instances[id].inferring { rememberInference(g.s.instances[id].function); }\n'+marker)
            text=text.replace("    let error = emitInstanceBody(g, id);","    let parent=trackInstance(id);\n    let error = emitInstanceBody(g, id);\n    restoreInstance(parent);")
            text+='\nextern fn trackInstance(id:u32)->u32="body_enter";\nextern fn restoreInstance(id:u32)="body_leave";\n'
            dest.write_text(text+'\nextern fn rememberInference(function:u32)="body_remember_inference";\n')
        elif module.name=='function.goose':
            if dest.is_symlink():dest.unlink()
            text=module.read_text()
            marker='constant => { return constant(g, f, id, n.a); },'
            assert text.count(marker)==1
            text=text.replace(marker,'constant => { observeLiteral(m.unit,id); return constant(g, f, id, n.a); },')
            dest.write_text(text+'\nextern fn observeLiteral(unit:u32,node:u32)="body_read";\n')
        elif module.name=='function_staging.goose':
            if dest.is_symlink():dest.unlink()
            text=module.read_text()
            marker='        constant => {'
            assert text.count(marker)==1
            dest.write_text(text.replace(marker,marker+'\n            observeLiteral(m.unit,id);'))
        elif not dest.exists():dest.symlink_to(module)
from guard import write_guard
write_guard(root,src/"body_guard.goose")
import gzip
receipts=root/"build/goose-port/engine-tests/receipts"
for receipt in sorted(receipts.glob("*.json.gz"),reverse=True):
    stages=json.loads(gzip.decompress(receipt.read_bytes()))["evidence"]["stages"]
    picked=[st for st in stages if st['stage'] in ("packet_list emit","packet_list link")]
    if len(picked)==2:break
else:raise RuntimeError("Run the packet_list native law first")
for st in picked:
    cmd=list(st['command']);file="emit-program"
    if st['stage'].endswith("emit"):
        cmd[cmd.index('-o')+1]=str(d/(name+'.c'))
        cmd[-1]=str(src/'main.goose')
        if '-O0' in cmd:cmd[cmd.index('-O0')]='-O2'
    else:
        file="compile-and-link-program"
        cmd[cmd.index('-O0')]=args.opt
        cmd[cmd.index(next(a for a in cmd if a.endswith('/program.c')))]=str(d/(name+'.c'))
        cmd.insert(-2,str(d/'io.c'))
        cmd[cmd.index('-o')+1]=str(d/name)
    with (d/(name+'-'+file+'.log')).open('w') as f:
        subprocess.run(cmd,check=True,timeout=150,stdout=f,stderr=subprocess.STDOUT)
