All commands run from the Blot repository root on Linux. Use the Gdev, Ink,
Pen and compiler identities in the adjacent type-resolution JSON. The baseline
for the visit counter is 1dbabdb8. Build the compiler before running the probe
so compiler-goose/build/stages contains the chosen compiler and link inputs.
Extract probe.py and probe.c to build/resolve-hill.

    python3 build/resolve-hill/probe.py build/resolve-hill/before-trace
    python3 build/resolve-hill/probe.py build/resolve-hill/after-trace

Run the first command at the baseline and the second at the compiler change.
The script copies the current Goose sources, adds observational calls to the
three type resolvers around each module check, and builds an unoptimized probe.
The probe never supplies a result to the checker. The counters compare full
keys, including collisions, and reset per module. They count visits, exact
repeats, repeats with depth erased, depth zero, cursor zero and projected
stores, split by stage and node class. The stored type's tag and closedness
determine its class on entry. Only the normal live type checker is measured.
Profiling times are unsuitable for release comparisons.

memo.patch applies to the compiler change. It adds a 64-slot direct-mapped
cache for unchanged zero-cursor roots, requires the same mutation generation
and depth limit, and excludes projected stores. Only a successful traversal
that created no type nodes may publish. Restoring a snapshot clears the cache.

The release time_gdev_parse.ts runner alternates two binaries. The included
three-way runner is used from build/resolve-hill to cycle all six orders
across the previous release, candidate and cache prototype. It checks the
same Wasm, edits and diagnostic sequences before timing comparisons.

    deno run -A build/resolve-hill/time.ts --before <previous> --after <candidate> --memo <cache> --rounds 18
    deno run -A build/resolve-hill/time.ts --before <previous> --after <candidate> --memo <cache> --rounds 6 --edits
    deno run -A build/resolve-hill/time.ts --before <previous> --after <candidate> --memo <cache> --rounds 6 --profile

The two direct eight-worker comparisons use scripts/integration/time_gdev_parse.ts
with --rounds 18. Each compares one pair of optimized binaries. The retained
control uses the same runner with --edits --rounds 6. The serial control
uses the three-way runner with frontendWorkers set to 1 and --profile.
The JSON alongside this archive contains input identities, counts and decisions.
