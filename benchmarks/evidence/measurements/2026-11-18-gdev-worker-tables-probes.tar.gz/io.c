#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <sys/stat.h>
static void file(char p[4096],uint32_t u,uint32_t k){snprintf(p,4096,"%s/%u-%u.bin",getenv("BLOT_PACKET_SAMPLES"),u,k);}
int64_t cp_size(uint32_t u,uint32_t k){char p[4096];struct stat st;file(p,u,k);return stat(p,&st)?-1:st.st_size;}
void cp_load(uint32_t u,uint32_t k,uint8_t *bytes,int64_t n){char p[4096];file(p,u,k);FILE*f=fopen(p,"rb");if(!f||fread(bytes,1,n,f)!=(size_t)n||fclose(f))abort();}
static uint64_t hits[2048],bytes[2048],dur[2048];
void cp_hit(uint32_t index,int64_t size,uint64_t ns){if(index>=2048)abort();hits[index]++;bytes[index]+=size;dur[index]+=ns;}
void cp_end(void){for(int i=0;i<2048;i++)if(hits[i])printf("%d %llu %llu %llu\n",i,(unsigned long long)hits[i],(unsigned long long)bytes[i],(unsigned long long)dur[i]);}
#include <stdbool.h>
bool cp_verify(void) {return getenv("BLOT_VERIFY_DIR")!=NULL;}
void cp_save(uint32_t u,uint32_t k,const uint8_t *bytes,int64_t size) {
    char p[4096];snprintf(p,sizeof p,"%s/%u-%u.bin",getenv("BLOT_VERIFY_DIR"),u,k);
    FILE *f=fopen(p,"wb");if(!f || fwrite(bytes,1,size,f)!=(size_t)size || fclose(f))abort();
}
