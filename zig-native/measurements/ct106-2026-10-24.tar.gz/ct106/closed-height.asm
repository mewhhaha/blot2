
zig-native/zig-out/bin/blotc:     file format elf64-x86-64


Disassembly of section .text:

0000000001389e10 <check.types.Store.closedHeight>:
 1389e10:	80 bf 57 0f 00 00 01 	cmpb   $0x1,0xf57(%rdi)
 1389e17:	75 2e                	jne    1389e47 <check.types.Store.closedHeight+0x37>
 1389e19:	0f b7 87 50 0f 00 00 	movzwl 0xf50(%rdi),%eax
 1389e20:	66 83 f8 ff          	cmp    $0xffff,%ax
 1389e24:	74 21                	je     1389e47 <check.types.Store.closedHeight+0x37>
 1389e26:	48 8b 8f 38 0d 00 00 	mov    0xd38(%rdi),%rcx
 1389e2d:	48 83 f9 ff          	cmp    $0xffffffffffffffff,%rcx
 1389e31:	74 14                	je     1389e47 <check.types.Store.closedHeight+0x37>
 1389e33:	48 39 8f 60 0e 00 00 	cmp    %rcx,0xe60(%rdi)
 1389e3a:	75 0b                	jne    1389e47 <check.types.Store.closedHeight+0x37>
 1389e3c:	83 fe 05             	cmp    $0x5,%esi
 1389e3f:	77 09                	ja     1389e4a <check.types.Store.closedHeight+0x3a>
 1389e41:	85 f6                	test   %esi,%esi
 1389e43:	0f 95 c0             	setne  %al
 1389e46:	c3                   	ret
 1389e47:	31 c0                	xor    %eax,%eax
 1389e49:	c3                   	ret
 1389e4a:	55                   	push   %rbp
 1389e4b:	48 89 e5             	mov    %rsp,%rbp
 1389e4e:	48 8b 4f 78          	mov    0x78(%rdi),%rcx
 1389e52:	89 f2                	mov    %esi,%edx
 1389e54:	48 c1 e2 04          	shl    $0x4,%rdx
 1389e58:	31 f6                	xor    %esi,%esi
 1389e5a:	66 39 44 11 0c       	cmp    %ax,0xc(%rcx,%rdx,1)
 1389e5f:	0f b6 44 11 0f       	movzbl 0xf(%rcx,%rdx,1),%eax
 1389e64:	0f 45 c6             	cmovne %esi,%eax
 1389e67:	5d                   	pop    %rbp
 1389e68:	c3                   	ret
