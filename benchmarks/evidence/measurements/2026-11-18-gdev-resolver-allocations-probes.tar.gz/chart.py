from pathlib import Path
import json,collections
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.ticker import FuncFormatter
mpl.rcParams['svg.fonttype']='none'
mpl.rcParams['svg.hashsalt']='blot-gdev-function-shapes'
d=Path(__file__).resolve().parent
out=Path('benchmarks/evidence/measurements/2026-11-18-gdev-resolver-allocations')
data=json.loads((d/'attribution.json').read_text())['rows']
labels={'finishNormalized':'Finish inferred types','resolveUse':'Resolve generic uses','applicationFlow':'Check call divergence','resolveUnification':'Unify types','ordinaryApplication':'Check ordinary calls','certifiedLambdaType':'Certify lambdas'}
counts=collections.defaultdict(collections.Counter)
for r in data:
 n=r['caller'].rsplit('_',1)[-1]
 counts[labels.get(n,'Other callers')][r['tag']]+=r['count']
fig,ax=plt.subplots(figsize=(8.7,3.9)); keys=[*labels.values(),'Other callers']
for i,n in enumerate(keys):
 cc=counts[n];total=sum(cc.values())
 ax.barh(i,cc['function'],color='#205c80',height=.62,label='Functions' if i==0 else None)
 ax.barh(i,total-cc['function'],left=cc['function'],color='#9bccb5',height=.62,label='Other type shapes' if i==0 else None)
 ax.text(total+2100,i,f'{total:,}',va='center',size=9)
ax.set_yticks(range(len(keys)),keys);ax.invert_yaxis();ax.set_xlim(0,180000);ax.set_xticks([0,40000,80000,120000,160000]);ax.xaxis.set_major_formatter(FuncFormatter(lambda x,p:f'{x/1000:.0f}k' if x else '0'))
ax.set_axisbelow(True);ax.grid(axis='x',color='#e1e6e9');ax.tick_params(length=0,labelsize=9,pad=6);ax.spines[:].set_visible(False)
fig.subplots_adjust(left=.205,right=.96,top=.79,bottom=.11);fig.text(.025,.935,'Where Gdev type resolution allocates',fontsize=17,weight='bold',color='#183143');fig.text(.025,.86,'405,857 new type nodes across 269 modules',fontsize=10,color='#475569')
ax.legend(frameon=False,loc='lower right',fontsize=9)
fig.savefig(str(out)+'.png',dpi=145,metadata={'Software':'Matplotlib'});fig.savefig(str(out)+'.svg',metadata={'Date':None})
svg=Path(str(out)+'.svg')
svg.write_text('\n'.join(line.rstrip() for line in svg.read_text().splitlines())+'\n')
