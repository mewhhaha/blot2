from pathlib import Path
import subprocess,time,json,os,statistics
root=Path('/home/mewhhaha/src/blot2');out=root/'build/bench/ct103';src=out/'candidate-src';work=root/'build/bench/compile-cost-20261023'
assert json.loads((out/'screen/results.json').read_text())['success']
pins=json.loads((out/'binaries.json').read_text())
env=dict(os.environ,ZIG_ANALYZER=str(root/'build/tools/zig-analyzer/zig-analyzer-0.17.0-3-x86_64-linux/bin/zig-analyzer'))
common=['deno','task','bench:compile','--baseline',pins['baseline']['path'],'--candidate',pins['candidate']['path'],'--snapshot',str(work/'snapshot'),'--manifest',str(work/'manifest.json'),'--hashes',str(out/'wasm.json')]
commands=[('cold',common+['--workload','game,devtools','--runs','7','--no-retained','--guard-cpu','--out',str(out/'cold')]),('retained',common+['--workload','game','--runs','7','--scenarios','trivia,literal_in_body,body_change','--restart-cache','--out',str(out/'retained')]),('phases',common+['--workload','game','--runs','1','--scenarios','literal_in_body,body_change','--profile','--out',str(out/'phases')]),('warm-series',['deno','run','--allow-all',str(out/'warm_series.ts')]),('gate',['deno','task','test:compiler','--native-shards','4','--phase-seconds','1200','--budget-seconds','1800','--timings-dir',str(out/'gate')])]
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n')
status=[]
for name,cmd in commands:
 if name=='gate':
  assert subprocess.check_output(['zig','version'],text=True).strip()=='0.17.0'
  samples=[json.loads(l) for l in (out/'retained/samples.jsonl').read_text().splitlines()]
  checks={}
  for phase,limit in [('edit:literal_in_body',.8),('edit:body_change',1.05)]:
   selected=[r for r in samples if r['phase']==phase]
   pairs=[{s['variant']:s['cpu_ms'] for s in selected if s['run']==i} for i in sorted({s['run'] for s in selected})]
   ratios=[p['candidate']/p['baseline'] for p in pairs]
   checks[phase]={'ratios':ratios,'median':statistics.median(ratios),'limit':limit,'met':statistics.median(ratios)<=limit}
  (out/'acceptance.json').write_text(json.dumps(checks,indent=2)+'\n');print('ACCEPTANCE',json.dumps(checks),flush=True)
  if any(not v['met'] for v in checks.values()):raise SystemExit('CPU screen missed; review before full qualification')
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'exit_code':result.returncode,'wall_seconds':time.monotonic()-start};status.append(row)
 (out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(row),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
