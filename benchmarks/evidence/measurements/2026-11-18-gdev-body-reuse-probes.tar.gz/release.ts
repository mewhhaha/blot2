import { strict as assert } from "node:assert";
import { resolve } from "node:path";
import { createZigProjectCompiler } from "../../host/zig_project_client.ts";
import { gdevProject } from "../../scripts/integration/gdev_project.ts";
const gdev = resolve("../gdev");
const opts = await gdevProject(
  gdev,
  resolve("std"),
  "src/main.blot",
  resolve("compiler-goose/build/blotc-goose"),
);
const file = resolve(gdev, "src/effects/lighting_look.blot");
const source = await Deno.readTextFile(file);
assert.equal(source.split("const proposed = $Look { sun: true,").length, 2);
const edit = source.replace(
  "const proposed = $Look { sun: true,",
  "const proposed = $Look { sun: false,",
);
for (let i = 0; i < 12; i++) {
  const profile = i % 2 === 1;
  const beginning = performance.now();
  const c = await createZigProjectCompiler({
    ...opts,
    profileBackend: profile,
  });
  try {
    for (const step of ["fresh", "edit"]) {
      const start = step === "fresh" ? beginning : performance.now();
      const r = await c.build({
        sources: step === "edit" ? { [file]: edit } : undefined,
        signal: AbortSignal.timeout(8000),
      });
      const ms = performance.now() - start;
      assert(r.success);
      assert.equal(r.stats.freshModules, step === "edit" ? 1 : 269);
      const digest = Array.from(
        new Uint8Array(await crypto.subtle.digest("SHA-256", r.bytes)),
        (v) => v.toString(16).padStart(2, "0"),
      ).join("");
      assert.equal(
        digest,
        step === "edit"
          ? "4e4fba58869dbd87e760919247d52afebc1c4fae443512747b9c06f61c27e757"
          : "c151554930880a097ff95cd2a487853d11cc84fcbdca9e89209e2fbb1d48ffaa",
      );
      console.log(
        JSON.stringify({
          i,
          profile,
          step,
          ms,
          sha256: digest,
          phases: r.stats.phaseProfile?.phases,
        }),
      );
    }
  } finally {
    await c.dispose();
  }
}
