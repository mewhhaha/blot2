from pathlib import Path
import subprocess,re,struct,collections,json
d=Path(__file__).resolve().parent
name='blot_check_check_finishNormalized_g16'
asm=subprocess.check_output(['objdump','-d','--disassemble='+name,d/'probe'],text=True)
addrs=[int(a,16)+5 for a in re.findall(r'^\s*([0-9a-f]+):.*?\bcall[q]?\s+[^\n]*<blot_check_types_resolve_g',asm,re.M)]
s=(d/'probe-src/check/check.goose').read_text().split('fn finishNormalized(self_',1)[1].split('\n}',1) # locate full function with next definition
s=(d/'probe-src/check/check.goose').read_text().split('fn finishNormalized(self_',1)[1].split('\nfn ',1)[0];targets=[]
for line in s.splitlines():
 if line.startswith('for '):loop=line.split('{')[0].strip()
 for expr in re.findall(r'self_\.types\.resolve\(([^,]*),0\)',line):targets.append((loop,expr))
assert len(targets)==len(addrs),(len(targets),len(addrs))
counts={a:collections.Counter() for a in addrs};mods=collections.defaultdict(collections.Counter)
for f in d.glob('trace-*'):
 b=f.read_bytes();p=0
 while p<len(b):
  h=struct.unpack_from('<13I',b,p);p+=52+h[11]*4
  if h[9] in counts:counts[h[9]][h[4]]+=1;mods[h[9]][f.name.split('-')[-1]]+=1
sites=[dict(loop=l,input=e,allocations=sum(counts[a].values()),functions=counts[a][7],modules=len(mods[a])) for a,(l,e) in zip(addrs,targets)]
assert sum(r['allocations'] for r in sites)==158398
(d/'sites.json').write_text(json.dumps(sites,indent=2)+'\n')
print(sorted(sites,key=lambda r:-r['allocations'])[:8])
