from pathlib import Path
import json,statistics
root=Path.cwd();b=root/'build/bench/ct106';cycles=json.loads((b/'development-cycles-final/results.json').read_text());assert cycles['success'];summary=cycles['summary'];installed=json.loads((root/'build/install/ct106/installed.json').read_text())
section=f'''## Compiler construction and development cycles

Twenty complete `check:dev --area static-sharing` edit/check cycles pass in a
disposable checkout: seven leaf-source edits, seven checker diagnostic edits and
six test-only fixture edits. Every cycle compiles the complete 2,564-law native
inventory and executes the same 78-law family with sampled allocation faults,
55 selected guest checks and local format/type/Zig analysis. Source restoration,
production-versus-test compiler identity and exact native inventory checks pass.
The test-only fixture is compiled as part of the full inventory; the selected
runtime family remains static-sharing. These cycles do not qualify every law
or the experimental source edits as releases.

Observed complete-cycle median is **{summary['median_seconds']:.2f} s**, sample
p95 **{summary['sample_p95_seconds']:.2f} s**, maximum **{summary['maximum_seconds']:.2f} s**.
Initial checkout setup/check and three group-restoration checks are recorded
separately. The first attempted sequence failed a cache-directory teardown race
and is not included as a successful cycle. The completed sequence starts again
from its own initial check. Host global caches are retained, local checkout
caches start fresh, and OS caches are not flushed. Unrelated host work continues.
This is a 20-sample observation, not a universal latency bound or a paired
compiler-build speedup claim.

| Edit class | Complete cycle median | Compiler construction | Full native compilation | Sampled native execution | Guest smoke |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
for kind in ['leaf','checker','test']:
 rows=[s for s in cycles['samples'] if s['kind']==kind]
 vals=[statistics.median(r['wall_seconds'] for r in rows)]+[statistics.median(next(p['wall_seconds'] for p in r['check']['phases'] if p['name']==phase) for r in rows) for phase in ['development-build','native-compile','native-run','guest-smoke']]
 section+='| '+kind+' | '+' | '.join(f'{v:.2f} s' for v in vals)+' |\n'
section+='''
All cycles use Zig 0.17.0 Safe/noLLVM and zero Zig lint findings. The cached
production build on test-only edits is preserved. Native compilation and the
selected guest suite are the next development-cycle costs; the deep principal
law deliberately crosses a 128-level import boundary at depth 130, so shrinking
it below that boundary would remove its coverage.

The actual release timing trace records **227.759 s total**, including
**220.884 s LLVM emission** (about 97%), 0.678 s file work, 5.912 s declarations
and 0.239 s link flush. It reports 855 reachable files, 436 imported files,
12,851 generic instances, 7,699 inline calls and 13,963 declaration timing rows.
CPU categories can overlap and are not an additional wall-time sum. Generic
interface erasure is not justified by this trace. The 150-second release and
480-second exhaustive-native targets remain open. Timing-server shutdown after
successful capture is not a failed compiler build.

'''
p=root/'zig-native/CT106_QUALIFICATION.md';s=p.read_text();s=s.replace('## Qualification',section+'## Qualification')
held='''## Held-out programs

Three-pair screens pass the historical five-program synthetic suite and the
explicit nine-case review matrix: records of width 32/128, effect rows of width
16/64 with explicit providers, closures of depth 16/64, a shared diamond, a small
program and 32 producer modules plus an entry. Fresh, retained and independent
fresh edit controls agree between CT105 and CT106. All **36** original/edited
executions across both compilers return independent expected results and match
the measured Wasm hashes.

Most cases take only a few milliseconds, below useful resolution for 10 ms
process-CPU ticks; no fine CPU percentage or 5% guard is claimed for them.
The depth-64 closure case is about 52 ms fresh and 56 ms edited in the candidate.
These are coarse regression controls, not a substitute for the main workload.
The first effect fixture attempted to export an unhandled custom effect row
and correctly failed `entry_type` in both compilers. Explicit providers repair
the fixture; only the completed rerun is counted as a pass.

'''
s=s.replace('## Memory and attribution',held+'## Memory and attribution')
s=s.replace('Release comparison, development-cycle and installation results will be added\nbefore this checkpoint is committed. The installed compiler is still CT105.',f'''The matching CLI and native compiler are installed at `~/.local/bin/blot` and
`~/.local/bin/blotc`, with rollback copies. Staged and installed checks run from
outside the repository: format, format-check, source-check, build, matching
CLI/native Wasm, no-import instantiation and list-example result **29** all pass.
The bundled guide matches its source. Installed CLI SHA-256:
`{installed['installed_sha256']['blot']}`.

The [evidence archive](measurements/ct106-2026-10-24.tar.gz) and
[SHA-256 sidecar](measurements/ct106-2026-10-24.tar.gz.sha256) preserve raw pairs,
hardware counters, memory sequences, timing frames, all qualification attempts,
20-cycle results, source/binary/manifest pins, the source patch, new source/tool
files and installation records. Internal `SHA256SUMS` is verified after writing.
Private workload sources, binaries, generated Wasm and caches are excluded;
public generated synthetic fixtures are included. Reproducing gdev requires the
matching frozen source manifest. See the [ledger](../COMPILER_CT106_WORK.md) for
all 86 dispositions, including partial and remaining work.''')
p.write_text(s)
short=f'''[CT106](zig-native/CT106_QUALIFICATION.md) measures 20 complete Safe/noLLVM
static-sharing edit/check cycles: **{summary['median_seconds']:.2f} s median**,
**{summary['sample_p95_seconds']:.2f} s observed p95**, **{summary['maximum_seconds']:.2f} s maximum**.
Leaf/checker compiler construction medians are 4.29/4.88 s; the test-only cached
compiler build is 0.36 s. Complete native compilation takes 7.20–8.03 s by edit
class, and guest smoke about 9.7–9.9 s. Every cycle compiles all 2,564 native
laws, runs the same 78-law sampled family and 55 guests, and passes local checks.
The first failed teardown sequence is excluded and preserved; the completed
sequence verifies every source restoration, compiler identity and inventory.
These are observed distributions on a shared host, not paired build speedups or
universal latency bounds. Full release qualification remains separate.

The actual LLVM release trace spends 220.88 of 227.76 s in emission. Keep
Safe/noLLVM for development and the complete native inventory; focus next on
native compilation, the measured guest cost and LLVM emission. The deep guest
fixture is already just above its required 128-level boundary. Correct build
identity recomputation preserves compiled-artifact caches and fixes the observed
stale digest. [Experiment tools](scripts/bench/README.md) document reproduction.

'''
p=root/'DEVELOPMENT_TURNAROUND.md';s=p.read_text();a=s.index('The latest [CT105');z=s.index('The [CT96',a);s=s[:a]+short+'Historical development measurements follow.\n\n'+s[z:];p.write_text(s)
p=root/'BUILD_HILLS.md';s=p.read_text();a=s.index('Current follow-up:');z=s.index('Historical follow-up:',a);s=s[:a]+short+'''BT3's current-host latency thresholds are observed across the 20-cycle sample;
this is evidence for the selected family, not whole-subsystem qualification.
BT1's sub-0.1-second command target, BT4's paired exhaustive-gate improvement and
BT5's sub-150-second release target remain open. Four native shards span about
599–649 s, so rebalancing alone has limited headroom. No generic-interface or
incremental-mode policy is changed on this evidence.

'''+s[z:];p.write_text(s)
# Add the installation and observed distribution beside the main user entry.
p=root/'README.md';s=p.read_text();key='Use `deno task check:dev --area static-sharing` for Safe/noLLVM development and';s=s.replace(key,f'''The qualified CLI and native compiler are installed locally. Twenty complete
selected edit/check cycles measure {summary['median_seconds']:.2f} s median and {summary['sample_p95_seconds']:.2f} s observed p95,
with source/identity restoration verified. These are shared-host observations.

'''+key);p.write_text(s)
p=root/'zig-native/README.md';s=p.read_text().replace('The final gate passes 2,564 exhaustive native laws, 1,655 guest checks,','The matching CLI and native compiler are installed locally. The final gate\npasses 2,564 exhaustive native laws, 1,655 guest checks,');p.write_text(s)
# Keep the dated old continuation text historical, replacing only the current block.
p=root/'CONTINUE.md';s=p.read_text();a=s.index('CT106 in progress,');z=s.index('Historical post-CT105 review',a);s=s[:a]+f'''CT106 qualified and installed, 24 October 2026:
[qualification and measurements](zig-native/CT106_QUALIFICATION.md),
[all 86 dispositions](COMPILER_CT106_WORK.md).
Seven alternating pairs against CT105 reduce first-literal CPU 19.1% (3.62 →
2.91 s wall median). Fresh CPU improves 2.4%, body CPU is effectively unchanged,
and literal-revert CPU rises 3.5%. Both fresh guards pass; ordinary body,
two-second and sub-second targets remain open. Keep the frozen 554-file workload
and strict Wasm pins when comparing another candidate.

Final native SHA-256:
`7d7ea08313e865a633ec9be2acc0347bc1560490ce8caca82e96df1c5b2dba69`.
Identity-file SHA-256:
`c6f01a199871b66d90fb24354c1d165bfff7bdc10323ea83c7c92cc8964a004f`.
Installed CLI SHA-256:
`{installed['installed_sha256']['blot']}`.
Installation and rollback records: `build/install/ct106/installed.json`.

Full qualification passes 2,564 exhaustive native laws, 1,655 guests, 48 smoke
checks and 57 tooling checks. The final guest pass resumes exact verified native
evidence; its ~52 s is not the complete gate cost (native execution 648.72 s).
Twenty complete development cycles pass: {summary['median_seconds']:.2f} s median, {summary['sample_p95_seconds']:.2f} s observed p95,
78 selected native laws and 55 guests, zero lint, every source restored. Failed
cache-teardown attempts, the moving-gdev input rejection and the full-/tmp
attempt remain preserved and are not passes. The isolated qualified checkout
uses frozen sibling fixtures and workspace-backed temporary storage.

The first frontend edit checks one module instead of 22. Operation interner
candidates fall from 90.45M to 0.74M; actual argument-height checks fall to 1.79M.
Four body principals still fail their own source-position check after two
narrowing attempts. Preserve exact provenance. Query-key changes did not reduce
candidate counts. Finer arena bins, notification coalescing, semantic-worker
default changes and host-native CPU targeting did not earn adoption.

A 200-distinct-edit sequence passes 232 requests with 12 sampled fresh controls.
Follow-up profiled windows show fixed small-heap/virtual capacity while RSS
rises, supporting residency changes during that window, not an indefinite
memory bound. All-thread PMU and CPU-set screens, nine held-out structural
programs, 36 runtime executions and the actual Zig timing trace are archived.
LLVM emission is about 97% of the measured release build.

Remaining work is explicit in the ledger: stable declaration origins, residual
query validation/import, cache/membership ablations, backend planning/encoding
reuse and broader allocator/phase attribution. These are not claimed complete.
Preserve unrelated `zig-native/build/` and `zig-out-modern/`. Do not rerun the
historical program or report failed acceptance targets as completed hills.

'''+s[z:];p.write_text(s)
