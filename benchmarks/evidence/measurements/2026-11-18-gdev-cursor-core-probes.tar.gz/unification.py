from pathlib import Path
import json,subprocess,shutil
d=Path('build/cursor-core/unify').resolve();d.mkdir(exist_ok=True);src=d/'src';shutil.copytree('compiler-goose/src',src,dirs_exist_ok=True)
p=src/'check/types.goose';s=p.read_text()
needle='        let a, ae = resolveUnification(self_, pair.a);';assert s.count(needle)==1
s=s.replace(needle,'''        let visits=self_.normalization.unify_resolve_entries;let added=self_.nodes.len;
'''+needle)
needle='        let an = node(self_, a); let bn = node(self_, b);\n        if rowIdentity'
s=s.replace(needle,'''        let an = node(self_, a); let bn = node(self_, b);
        var category:u32=6;
        if a==b {category=0;} else if a==never || b==never {category=1;}
        else if an.tag==Tag.variable && bn.tag==Tag.variable {category=2;}
        else if an.tag==Tag.variable || bn.tag==Tag.variable {category=3;}
        else if an.tag==Tag.function && bn.tag==Tag.function {category=4;}
        else if an.tag==bn.tag {category=5;}
        countUnify(category,self_.normalization.unify_resolve_entries-visits,(self_.nodes.len-added) as u64,pair.a==pair.b);
        if rowIdentity''',1)
assert s.count('countUnify(')==1
p.write_text(s+'\nextern fn countUnify(kind:u32,visits:u64,nodes:u64,identical:bool)="cu_count";\n')
p=src/'reuse/persistent_unit.goose';s=p.read_text();needle='let error=self_.checkModule(unit);';assert s.count(needle)==1;p.write_text(s.replace(needle,'beginUnify();'+needle+'endUnify(unit);')+'\nextern fn beginUnify()="cu_begin";\nextern fn endUnify(id:u32)="cu_end";\n')
(d/'log.c').write_text('''#include <stdint.h>
#include <string.h>
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
static _Thread_local uint64_t counts[7][4];
void cu_begin(void){memset(counts,0,sizeof counts);}
void cu_count(uint32_t k,uint64_t v,uint64_t n,_Bool equal){counts[k][0]++;counts[k][1]+=v;counts[k][2]+=n;counts[k][3]+=equal;}
void cu_end(uint32_t id){
char buf[2048];int n=snprintf(buf,sizeof buf,"%u",id);for(int i=0;i<7;i++)for(int j=0;j<4;j++)n+=snprintf(buf+n,sizeof(buf)-n," %llu",(unsigned long long)counts[i][j]);buf[n++]='\\n';
int fd=open(getenv("BLOT_CURSOR_LOG"),O_WRONLY|O_APPEND|O_CREAT,0600);if(fd<0 || write(fd,buf,n)!=n)abort();close(fd);}
''')
get=lambda name:json.load(open('compiler-goose/build/stages/'+name+'.json'))['command']
cmd=get('emit-program');cmd[cmd.index('-o')+1]=str(d/'prog.c');cmd[cmd.index('--header')+1]=str(d/'prog.h');cmd[cmd.index('-O2')]='-O0';cmd[-1]=str(src/'main.goose')
with (d/'emit.log').open('w') as f:subprocess.run(cmd,check=True,stdout=f,stderr=f,timeout=150)
cmd=get('compile-and-link-program');cmd[cmd.index('-O2')]='-O0';cmd[cmd.index(next(a for a in cmd if a.endswith('blot_goose.c')))]=str(d/'prog.c');cmd.insert(-2,str(d/'log.c'));cmd[-1]=str(d/'compiler')
with (d/'clang.log').open('w') as f:subprocess.run(cmd,check=True,stdout=f,stderr=f,timeout=70)
w=d/'traced';w.write_text(f'#!/bin/sh\nexport BLOT_CURSOR_LOG="{d}/modules.tsv"\nexec "{d}/compiler" "$@"\n');w.chmod(0o755)
with (d/'main.log').open('w') as f:subprocess.run(['deno','run','-A','scripts/integration/build_gdev.ts','--compiler',w,'--timeout-ms','45000',d/'main'],stdout=f,check=True,timeout=55)
