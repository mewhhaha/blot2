from pathlib import Path
import subprocess,time,json,hashlib,os
root=Path('/home/mewhhaha/src/blot2');out=root/'build/bench/ct103';src=out/'candidate-src';work=root/'build/bench/compile-cost-20261023'
baseline=out/'baseline-src/zig-native/zig-out/bin/blotc';candidate=src/'zig-native/zig-out/bin/blotc'
assert subprocess.check_output(['zig','version'],text=True).strip()=='0.17.0'
common=['deno','task','bench:compile','--baseline',str(baseline),'--candidate',str(candidate),'--snapshot',str(work/'snapshot'),'--manifest',str(work/'manifest.json'),'--hashes',str(out/'wasm.json')]
commands=[('release-final',['deno','task','build:compiler']),('screen',common+['--workload','game,devtools','--runs','1','--scenarios','trivia,literal_in_body,body_change','--restart-cache','--write-hashes','--out',str(out/'screen')])]
(out/'screen-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
for name,cmd in commands:
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:result=subprocess.run(cmd,cwd=src,stdout=log,stderr=subprocess.STDOUT)
 print(json.dumps({'name':name,'exit_code':result.returncode,'seconds':time.monotonic()-start}),flush=True)
 if result.returncode:raise SystemExit(result.returncode)
 if name=='release-final':(out/'binaries.json').write_text(json.dumps({k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in [('baseline',baseline),('candidate',candidate)]},indent=2)+'\n')
