import check.types;
import check.effects;
import support.error;

fn arrow(store:blot_check_types::Store&,a:u32,b:u32,r:u32=0)->u32 {
    let id,error=store.functionWithEffects(a,b,r);
    assert(error==blot_error::Error.none);return id;
}

fn main() {
    let ok=blot_error::Error.none;
    let u=blot_check_types::u32_type;let b=blot_check_types::boolean;let unit=blot_check_types::unit;
    var store,init=blot_check_types::initWithOptions(blot_check_types::Options{closed_graphs:true,..});
    assert(init==ok);
    let x,xe=store.fresh();assert(xe==ok);
    let shared=arrow(store,x,x);
    let conflict=arrow(store,u,b);
    let checkpoint=store.mark();
    assert(store.unify(shared,conflict)==blot_error::Error.type_mismatch);
    assert(store.cursor()==checkpoint.effects.next_position && store.versions.len==checkpoint.versions);
    let unbound,e0=store.resolve(x,0);assert(e0==ok && unbound==x);
    let equals=arrow(store,b,b);
    assert(store.unify(shared,equals)==ok);
    let fixed,e1=store.resolve(x,0);assert(e1==ok && fixed==b);

    // A parent alias created between writes selects a later child and a later effect.
    let child,ce=store.fresh();let alias,ae=store.fresh();assert(ce==ok && ae==ok);
    let row,re=store.freshEffects();let open,oe=store.freshEffects();assert(re==ok && oe==ok);
    let signature=arrow(store,child,child,row);
    match store.effects.node(row).tail {
        variable v => {
            assert(store.effects.appendVersion(v.value,0)==ok);
            assert(store.appendVersion(child,u)==ok);
            assert(store.appendVersion(alias,signature)==ok);
            assert(store.effects.appendVersion(v.value,open)==ok);
            assert(store.appendVersion(child,b)==ok);
        },
        _ => {assert(false);},
    }
    let old_case=arrow(store,u,u);
    assert(store.unify(signature,old_case)==ok);
    let wrong=store.mark();
    assert(store.unify(alias,old_case)==blot_error::Error.type_mismatch);
    assert(store.cursor()==wrong.effects.next_position && store.versions.len==wrong.versions);
    assert(store.unify(alias,equals)==ok);
    let closed,e2=store.resolveEffects(open,0);assert(e2==ok && closed==0);

    // The parameter closes the shared effect. The result requires that same
    // effect to contain Foreign and must fail, rolling back both effect stores.
    let tail,te=store.freshEffects();assert(te==ok);
    let foreign,fe=store.effects.row([blot_check_types::foreign_operation],blot_check_effects::Tail.closed);assert(fe==ok);
    let effectful=arrow(store,unit,unit,tail);
    let left=arrow(store,effectful,effectful);
    let pure=arrow(store,unit,unit);
    let impure=arrow(store,unit,unit,foreign);
    let right=arrow(store,pure,impure);
    let mark=store.mark();
    assert(store.unify(left,right)==blot_error::Error.effect_mismatch);
    assert(store.effects.versions.len==mark.effects.versions && store.cursor()==mark.effects.next_position);
    let retained,e3=store.resolveEffects(tail,0);assert(e3==ok && retained==tail);
    store.deinit();
}
