import {strict as assert} from "node:assert";
import {resolve} from "node:path";
import {gdevProject} from "../../scripts/integration/gdev_project.ts";
import {createZigProjectCompiler} from "../../host/zig_project_client.ts";
const [set="cold", rounds="10"]=Deno.args;
const folder=resolve("build/parse-pilot");
const root=resolve("../gdev");
const expected="c151554930880a097ff95cd2a487853d11cc84fcbdca9e89209e2fbb1d48ffaa";
const file=resolve(root,"src/effects/lighting_look.blot");
const original=await Deno.readTextFile(file);
const needle="const proposed = $Look { sun: true,";
assert.equal(original.split(needle).length,2);
const edit=original.replace(needle,"const proposed = $Look { sun: false,");
const broken=original.replace(needle,"const proposed = $Look { sun: unresolved_probe,");
const syntax=original.replace(needle,"const proposed = $Look { sun: ),");
const badLex=original+'\nprivate const bad_probe = "\\q"\n';
const digest=async(b:Uint8Array<ArrayBuffer>)=>Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256",b)),v=>v.toString(16).padStart(2,"0")).join("");
let modes=set==="smoke"?["control","p8trace"]:set==="worker"?["p1trace","p8trace"]:set==="edits"?["p1","p8"]:["p1","p8"];
const references=new Map<string,string>();
for(let round=0;round<Number(rounds);round++){
 const order=round%2===0?modes:[...modes].reverse();
 for(const mode of order){
  const profile=set==="smoke"||set==="worker";
  const opts=await gdevProject(root,resolve("std"),"src/main.blot",resolve(folder,mode));
  const start=performance.now();
  const c=await createZigProjectCompiler({...opts,frontendWorkers:8,profileBackend:profile});
  try{
   const steps=(set==="edits"||set==="smoke")?[["fresh",original],["edit",edit],["reject",broken],["syntax",syntax],["lex",badLex],["recover",original]]:[["fresh",original]];
   for(const [step,src] of steps){
    const t=performance.now();
    const r=step==="fresh"?await c.build({signal:AbortSignal.timeout(9000)}):await c.build({sources:{[file]:src},signal:AbortSignal.timeout(9000)});
    const ms=performance.now()-(step==="fresh"?start:t);
    const fp=r.success?await digest(r.bytes):JSON.stringify(r.diagnostics);
    assert.equal(r.success,!["reject","syntax","lex"].includes(step),fp);
    if(step==="fresh"||step==="recover")assert.equal(fp,expected);
    if(references.has(step))assert.equal(references.get(step),fp,step);else references.set(step,fp);
    const row:any={mode,round:round+1,step,ms,success:r.success};
    if(r.success){row.hash=fp;row.fresh=r.stats.freshModules;row.cached=r.stats.cachedModules;
      if(profile){row.phases=r.stats.phaseProfile?.phases;row.checking=r.stats.phaseProfile?.checking;}
    }else row.diagnostics=r.diagnostics;
    console.log(JSON.stringify(row));
   }
  }finally{await c.dispose();}
 }
}
