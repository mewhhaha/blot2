import { createZigProjectCompiler } from "../../../compiler/zig_project_client.ts";
import type { NativeAssetImport } from "../../../compiler/native_assets.ts";
import { resolve } from "node:path";
import { createHash } from "node:crypto";
const repo=Deno.cwd();
const game=resolve(repo,"build/bench/gdev-current-20261023/snapshot/gdev");
const out=resolve(repo,"build/bench/gdev-current-20261023");
const executable=Deno.args[0]??"/home/mewhhaha/.local/bin/blotc";
const count=Number(Deno.args[1]??5);
const label=Deno.args[2]??"current";
const settings=JSON.parse(await Deno.readTextFile(resolve(game,"pen.json"))).compiler.settings;
const stdRoot=resolve(game,settings.std);
const imports=Object.fromEntries(Object.entries(settings.imports).map(([k,v])=>[k,resolve(game,String(v))]));
const nativeAssets={roots:settings.nativeAssets.roots.map((p:string)=>resolve(game,p)),imports:settings.nativeAssets.imports.map((v:NativeAssetImport)=>({...v,module:resolve(game,String(v.module)),path:resolve(game,String(v.path))}))};
function hash(bytes:Uint8Array){return createHash("sha256").update(bytes).digest("hex")}
async function inputs(){
 const files:Record<string,string>={};
 async function visit(path:string){for await(const e of Deno.readDir(path)){if(e.name.startsWith("."))continue;const p=resolve(path,e.name);if(e.isDirectory)await visit(p);else if(e.isFile)files[p]=hash(await Deno.readFile(p));}}
 for(const dir of [stdRoot,resolve(game,"src"),resolve(game,"devtools"),resolve(game,"pen"),resolve(game,"../ink/lib")])await visit(dir);
 files[resolve(game,"pen.json")]=hash(await Deno.readFile(resolve(game,"pen.json")));
 return files;
}
async function usage(pid:number){
 let ns=0;for await(const task of Deno.readDir(`/proc/${pid}/task`)){try{ns+=Number((await Deno.readTextFile(`/proc/${pid}/task/${task.name}/schedstat`)).split(" ")[0])}catch(e){if(!(e instanceof Deno.errors.NotFound))throw e}}
 const s=await Deno.readTextFile(`/proc/${pid}/stat`);const v=s.slice(s.lastIndexOf(") ")+2).trim().split(/\s+/);
 const status=await Deno.readTextFile(`/proc/${pid}/status`);
 return {cpu_ms:ns/1e6,tick_ms:(Number(v[11])+Number(v[12]))*10,peak_rss_kib:Number(status.match(/^VmHWM:\s+(\d+)/m)?.[1]??0)};
}
const compilerBefore=hash(await Deno.readFile(executable));
const before=await inputs();
const samples:Record<string,unknown>[]=[];
const expected:Record<string,string>={};
try {
 for(let run=1;run<=count;run++)for(const [name,entry] of [["game","src/main.blot"],["devtools","devtools/main.blot"]]){
  console.error(`Opening ${name} run ${run}`);
  const start=performance.now();
  const compiler=await createZigProjectCompiler({executable,entry:resolve(game,entry),stdRoot,prelude:resolve(stdRoot,"prelude.blot"),imports,nativeAssets,inferenceBudget:settings.inferenceBudget,codegenTier:settings.codegenTier??"optimized",codegenWorkers:4,cacheDirectory:false});
  const open_ms=performance.now()-start;
  console.error(`Building ${name} run ${run}; open=${open_ms.toFixed(1)}ms`);
  try{
   const cpuBefore=await usage(compiler.pid);const buildStart=performance.now();const result=await compiler.build();const wall_ms=performance.now()-buildStart;const cpuAfter=await usage(compiler.pid);
   if(!result.success){const sample={name,run,success:false,open_ms,wall_ms,cpu_ms:cpuAfter.cpu_ms-cpuBefore.cpu_ms,tick_cpu_ms:cpuAfter.tick_ms-cpuBefore.tick_ms,peak_rss_kib:cpuAfter.peak_rss_kib,diagnostics:result.diagnostics,stats:result.attemptStats};samples.push(sample);console.log(JSON.stringify({...sample,stats:undefined}));continue;}
   const sha=hash(result.bytes);if(expected[name]&&sha!==expected[name])throw Error(`${name} output changed between fresh runs`);expected[name]=sha;
   const againStart=performance.now();const again=await compiler.build();const no_op_ms=performance.now()-againStart;
   if(!again.success||hash(again.bytes)!==sha)throw Error(`${name} no-op output mismatch`);
   const sample={name,run,success:true,open_ms,wall_ms,cpu_ms:cpuAfter.cpu_ms-cpuBefore.cpu_ms,tick_cpu_ms:cpuAfter.tick_ms-cpuBefore.tick_ms,peak_rss_kib:cpuAfter.peak_rss_kib,wasm_bytes:result.bytes.length,wasm_sha256:sha,no_op_ms,stats:result.stats};samples.push(sample);
   console.log(JSON.stringify({...sample,stats:undefined}));
  }finally{await compiler.dispose()}
 }
}catch(error){
 console.error(error);
 throw error;
}finally{
 const after=await inputs();const changed=[...new Set([...Object.keys(before),...Object.keys(after)])].filter(p=>before[p]!==after[p]);
 const compilerAfter=hash(await Deno.readFile(executable));
 const summary={date:new Date().toISOString(),executable,compiler_sha256:compilerBefore,compiler_unchanged:compilerBefore===compilerAfter,codegen_tier:settings.codegenTier??"optimized",workers:4,persistent_cache:false,inputs_unchanged:changed.length===0,changed,inputs:before,samples};
 await Deno.writeTextFile(resolve(out,`${label}-results.json`),JSON.stringify(summary,null,2)+"\n");
 if(changed.length)throw Error(`Inputs changed during measurement: ${changed.join(", ")}`);
 if(compilerBefore!==compilerAfter)throw Error("Compiler changed during measurement");
}
