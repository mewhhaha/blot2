import subprocess, json, os
from pathlib import Path
root=Path.cwd()
base=["deno","task","bench:compile","--baseline","build/bench/ct109/candidate-1-blotc","--runs","3","--workload","game,devtools","--scenarios","literal_in_body,body_change","--snapshot","build/bench/compile-cost-20261023/snapshot","--manifest","build/bench/compile-cost-20261023/manifest.json","--hashes","build/bench/ct103/wasm.json","--guard-cpu"]
env=dict(os.environ,TMPDIR=str(root/"build/bench/ct109/tmp"))
results=[]
for name,binary in [("row-ablation-pairs","row-ablation-blotc"),("composite-ablation-pairs","composite-ablation-blotc")]:
 print("Starting "+name,flush=True)
 with open(root/("build/bench/ct109/"+name+".log"),"w") as log:
  done=subprocess.run(base+["--candidate","build/bench/ct109/"+binary,"--out","build/bench/ct109/"+name],stdout=log,stderr=subprocess.STDOUT,env=env)
 results.append({"name":name,"exit":done.returncode})
 print(name+" exit "+str(done.returncode),flush=True)
(root/"build/bench/ct109/ablation-exits.json").write_text(json.dumps(results,indent=2)+"\n")
