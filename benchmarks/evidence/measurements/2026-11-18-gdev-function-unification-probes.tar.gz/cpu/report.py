from pathlib import Path
from collections import Counter
from statistics import median
import json,subprocess,bisect,re,struct,sys,hashlib
d=Path('build/function-pairs/cpu')
binary=Path('build/resolve-hill/candidate')
symbols=[]
for line in subprocess.check_output(['nm','-nS',str(binary)],text=True).splitlines():
    m=re.fullmatch(r'([0-9a-f]+) ([0-9a-f]+) [tTwW] (\S+)',line)
    if m: symbols.append((int(m[1],16),int(m[2],16),m[3]))
assert symbols==sorted(symbols,key=lambda x:x[0])
starts=[s[0] for s in symbols]
namespaces=set()
for p in Path('compiler-goose/src').rglob('*.goose'):
    m=re.search(r'^namespace +(\w+);',p.read_text(),re.M)
    if m:namespaces.add(m[1])
namespaces=sorted(namespaces,key=len,reverse=True)
sampled_paths=sorted((d/'samples').glob('run.*'),key=lambda p:p.stat().st_mtime_ns)
runs=[]; per_function=Counter();per_module=Counter();raw=[]
for path in sampled_paths:
    counts=Counter(struct.iter_unpack('<III',path.read_bytes()));pids={k[0] for k in counts};local=Counter()
    if not counts:continue
    for (pid,kind,offset),n in counts.items():
        name='other shared libraries'
        group=name
        if kind==1:name=group='libc'
        if kind==0:
            i=bisect.bisect_right(starts,offset)-1
            name='executable padding'
            if i>=0 and offset<symbols[i][0]+symbols[i][1]:
                name=re.sub(r'_g\d+(?:_\d+)*(?:\..*)?$', '',symbols[i][2])
            group=next((prefix for prefix in namespaces if name.startswith(prefix+'_')),'native and runtime')
        per_module[group]+=n;per_function[name]+=n;local[group]+=n
    raw.append([[pid,kind,offset,n] for (pid,kind,offset),n in sorted(counts.items())])
    runs.append(dict(samples=sum(local.values()),processes=len(pids),groups=dict(local)))
timings=[json.loads(line) for line in (d/'runs.jsonl').read_text().splitlines()]
assert len(runs)==len(timings)==12 and min(r['processes'] for r in runs)>=8
assert all(r['success'] and r['hash']=='c151554930880a097ff95cd2a487853d11cc84fcbdca9e89209e2fbb1d48ffaa' for r in timings)
doc=dict(binarySha256=hashlib.sha256(binary.read_bytes()).hexdigest(),freshBuilds=len(runs),samples=per_module.total(),processesPerRun=[r['processes'] for r in runs],modules=per_module.most_common(),functions=per_function.most_common(45),runs=runs)
(d/'summary.json').write_text(json.dumps(doc,indent=2)+'\n')
(d/'raw.json').write_text(json.dumps(raw,separators=(',',':')))
for counts in (per_module,per_function):
    print([(k,round(100*n/counts.total(),1)) for k,n in counts.most_common(20)])
