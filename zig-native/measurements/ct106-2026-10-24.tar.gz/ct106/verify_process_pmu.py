import subprocess,json,sys
worker=subprocess.Popen([sys.executable,'-u','-c','''import sys,threading
print("ready",flush=True)
def work():
 x=0
 for i in range(3000000): x+=i
for line in sys.stdin:
 n=int(line)
 jobs=[threading.Thread(target=work) for _ in range(n)]
 for job in jobs:job.start()
 for job in jobs:job.join()
 print("done",flush=True)
'''],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
monitor=None
try:
 assert worker.stdout.readline().strip()=='ready'
 monitor=subprocess.Popen([sys.executable,'scripts/bench/process_pmu.py',str(worker.pid)],stdin=subprocess.PIPE,stdout=subprocess.PIPE,text=True)
 ready=json.loads(monitor.stdout.readline());assert ready['ready']
 rows=[]
 for count in [1,2]:
  monitor.stdin.write('start\n');monitor.stdin.flush();assert json.loads(monitor.stdout.readline())['started']
  worker.stdin.write(str(count)+'\n');worker.stdin.flush();assert worker.stdout.readline().strip()=='done'
  monitor.stdin.write('stop\n');monitor.stdin.flush();result=json.loads(monitor.stdout.readline())
  result['new_threads']=count;rows.append(result)
 instructions=[sum(r['raw'] for r in row['counters'] if r['event']=='instructions') for row in rows]
 assert instructions[0]>1000000 and 1.7<instructions[1]/instructions[0]<2.3,instructions
 result={'success':True,'ready':ready,'samples':rows,'instruction_ratio':instructions[1]/instructions[0]}
 open('build/bench/ct106/process-pmu-verification.json','w').write(json.dumps(result,indent=2)+'\n')
 print('New-thread coverage passed; instruction ratio',result['instruction_ratio'])
finally:
 if monitor:
  monitor.stdin.write('quit\n');monitor.stdin.flush();assert monitor.wait(timeout=5)==0
 worker.stdin.close();assert worker.wait(timeout=5)==0
