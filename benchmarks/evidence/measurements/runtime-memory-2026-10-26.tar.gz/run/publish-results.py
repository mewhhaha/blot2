import hashlib,json,platform,statistics,subprocess
from pathlib import Path
root=Path('build/remaining-runtime')
def read(name):return json.loads((root/name).read_text())
def sha(path):return hashlib.sha256(Path(path).read_bytes()).hexdigest()
kernels={engine:read(f'kernels/{name}.json') for engine,name in [('deno','results'),('wasmtime','wasmtime'),('firefox','firefox')]}
for d in kernels.values():assert d['complete']
game=read('gdev-scores.json');compile=read('gdev-compile-results.json');reduction=read('acyclic-results.json');overhead=read('profile-overhead.json')
for d in [game,compile,reduction,overhead]:assert d['complete']
profiles=read('gdev-memory-attribution.json')
for d in profiles.values():d.pop('active_sites');assert d['complete']
public={name:read(f'{name}-memory.json') for name in ['selected','reference_scratch','optional_generate','pipeline']}
for d in public.values():assert d['complete']
summary=[]
for scene in ['maxed-day-hitting','maxed-piles2000']:
 row={'scene':scene}
 for side in ['baseline','final','cycle-ablation']:
  runs=[r for r in game['rows'] if r['scene']==scene and r['side']==side];assert len(runs)==3
  row[side]={'mean_frame_ms_median':statistics.median(r['mean_ms'] for r in runs),'process_cpu_seconds_median':statistics.median(r['process']['user_seconds']+r['process']['system_seconds'] for r in runs),'frame_mean_range_ms':[min(r['mean_ms'] for r in runs),max(r['mean_ms'] for r in runs)],'counters':runs[0]['counters'],'memory_max':max(r['memory_max'] for r in runs),'last_100_growth_max':max(r['last_100_growth'] for r in runs)}
 summary.append(row)
report={'qualification':read('qualification.json'),'format':1,'complete':True,'date':'2026-10-26','baseline_commit':'fdfaa899aa57ae80ab1b2a50b4eefcd995472a5f','candidate_compiler_sha256':sha(root/'candidate-blotc'),'cycle_ablation_compiler_sha256':sha(root/'cycle-ablation/zig-native/zig-out/bin/blotc'),'host':{'platform':platform.platform(),'cpu':next((s.split(':',1)[1].strip() for s in Path('/proc/cpuinfo').read_text().splitlines() if s.startswith('model name')),None)},'kernels':kernels,'application_runtime':game,'application_summary':summary,'application_compile':compile,'acyclic_reduction':reduction,'profile_overhead':overhead,'public_memory_profiles':public,'application_memory_profiles':profiles,'ablation_source_differences':read('ablation-source-differences.json'),'application_active_sites_archive_sha256':sha(root/'gdev-memory-attribution.json.gz')}
p=Path('benchmarks/results/runtime-memory-2026-10-26.json');p.write_text(json.dumps(report,indent=2)+'\n')
print(p,p.stat().st_size);print(json.dumps(summary,indent=2));print('Compile medians',compile['medians'])
