from pathlib import Path
import subprocess,time,json,hashlib,os
root=Path('/home/mewhhaha/src/blot2');out=root/'build/bench/ct105';work=root/'build/bench/compile-cost-20261023'
base=out/'baseline/blotc';candidate=root/'zig-native/zig-out/bin/blotc'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={'base_commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'baseline':{'path':str(base),'sha256':sha(base)},'candidate':{'path':str(candidate),'sha256':sha(candidate)},'manifest_sha256':sha(work/'manifest.json'),'source':{str(p.relative_to(root)):sha(p) for p in sorted((root/'zig-native/src').rglob('*.zig'))}}
assert pins['baseline']['sha256']=='0185500e446d59d6e813de8cecb3318bcc5983632043eb0129b8a64bad45ee9f'
(out/'final-pins.json').write_text(json.dumps(pins,indent=2)+'\n')
bench=['deno','task','bench:compile','--baseline',str(base),'--candidate',str(candidate),'--snapshot',str(work/'snapshot'),'--manifest',str(work/'manifest.json'),'--hashes',str(root/'build/bench/ct103/wasm.json'),'--workload','game,devtools','--scenarios','literal_in_body,body_change']
commands=[('pairs',bench+['--runs','7','--guard-cpu','--out',str(out/'pairs')]),('phases',bench+['--runs','1','--profile','--out',str(out/'phases')]),('warm-series',['deno','run','--allow-all',str(out/'warm_series.ts')]),('memory-series',['deno','run','--allow-all',str(out/'memory_series.ts')]),('restart',bench+['--runs','1','--restart-cache','--out',str(out/'restart')]),('gate',['deno','task','test:compiler','--timings-dir',str(out/'gate')])]
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');statuses=[]
env=os.environ.copy();env['ZIG_ANALYZER']=str(out/'tools/bin/zig-analyzer')
for name,cmd in commands:
 assert sha(candidate)==pins['candidate']['sha256']
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'name':name,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start,'load':os.getloadavg()};statuses.append(row);(out/'status.json').write_text(json.dumps(statuses,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for name,digest in pins['source'].items():assert sha(root/name)==digest,name
assert sha(candidate)==pins['candidate']['sha256']
(out/'release-checks-success.json').write_text(json.dumps({'success':True,'source_unchanged':True,'binaries_unchanged':True})+'\n')
