#!/usr/bin/env python3
"""Run CT96 release comparisons only after the isolated full gate succeeds."""
import hashlib
import json
from pathlib import Path
import shutil
import subprocess

root = Path(__file__).resolve().parent
repo = root.parents[2]
work = root / 'blot2'
baseline = repo / 'build/bench/compile-cost-20261023'
gate = json.loads((root / 'gate/timings.json').read_text())
assert gate['success'] and not gate['active']
candidate = root / 'candidate'
candidate.mkdir(exist_ok=True)
shutil.copy2(work / 'zig-native/zig-out/bin/blotc', candidate / 'blotc')
sha = lambda path: hashlib.sha256(path.read_bytes()).hexdigest()
(candidate / 'identity.json').write_text(json.dumps({
    'base': '63c931fd2e9eca212fc282df70b373de9a9b1a79',
    'change': 'CT96 generator-owned spawn capability view',
    'sha256': sha(candidate / 'blotc'),
    'baseline_sha256': sha(baseline / 'baseline/blotc'),
    'compiler_source': json.loads((root / 'candidate-pins.json').read_text()),
}, indent=2) + '\n')
common = ['deno', 'task', 'bench:compile',
          '--baseline', str(baseline / 'baseline/blotc'), '--candidate', str(candidate / 'blotc'),
          '--snapshot', str(baseline / 'snapshot'), '--manifest', str(baseline / 'manifest.json'),
          '--hashes', str(baseline / 'wasm.json')]
commands = [
    ('cold', common + ['--workload', 'game,devtools', '--runs', '7', '--no-retained', '--guard-cpu', '--out', str(root / 'cold')]),
    ('retained', common + ['--workload', 'game', '--runs', '1', '--scenarios', 'trivia,literal_in_body,body_change', '--restart-cache', '--out', str(root / 'retained')]),
    ('stacks', ['deno', 'task', 'profile:compile', '--blotc', str(candidate / 'blotc'),
                '--snapshot', str(baseline / 'snapshot'), '--manifest', str(baseline / 'manifest.json'),
                '--workload', 'game', '--runs', '2', '--min-ms', '15', '--max-ms', '30',
                '--out', str(root / 'stacks')]),
    ('stacks-summary', ['python3', 'scripts/bench/summarize_stacks.py', str(root / 'stacks')]),
]
(root / 'measurement-commands.json').write_text(json.dumps(commands, indent=2) + '\n')
for name, command in commands:
    print('Starting', name, flush=True)
    with (root / (name + '.log')).open('w') as log:
        subprocess.run(command, cwd=work, stdout=log, stderr=subprocess.STDOUT, check=True)
    print('Completed', name, flush=True)
print('All measurement passes completed', flush=True)
