CT106 evidence: final release 7d7ea08313e865a633ec9be2acc0347bc1560490ce8caca82e96df1c5b2dba69.
The historical file final-blotc (de3bf00...) predates the build-identity and heap-profile additions; only its same-source CPU-target screen uses it.
Complete qualification is qualification-final-disk/timings.json; its native evidence resumes run-ab5742e3da0626f5. Failed, invalidated and interrupted attempts are retained and are not passes.
Source changes are relative to 342a6f9, plus the explicitly included new source/tool files. final-pins.json records native/build/guest file identities. The later Git commit is authoritative for final documentation.
Public generated synthetic fixtures are included. Source snapshots from the private workload, binaries, generated Wasm and caches are excluded. Reproduction requires the frozen manifest's matching source tree.
Hardware events cover userspace whole requests, all existing and inherited future threads. Generic cache counts do not identify a cache level. Affinity trials constrain CPU sets rather than pinning each worker individually.
All 86 suggestions have dispositions; partial, conditional and unfinished items are not claimed as implementations.
