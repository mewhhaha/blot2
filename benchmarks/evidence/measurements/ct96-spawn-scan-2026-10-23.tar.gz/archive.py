"""Verify and archive CT96's isolated qualification and paired measurements."""
from pathlib import Path
import gzip, hashlib, io, json, re, tarfile
import statistics
import xml.etree.ElementTree as ET

base = Path(__file__).resolve().parent
repo = base.parents[2]
def read(path): return json.loads(path.read_text())
def sha(data): return hashlib.sha256(data).hexdigest()
gate = read(base / 'gate/timings.json')
assert gate['success'] and not gate['active']
phases = {r['name']: r for r in gate['phases']}
assert all(r['code'] == 0 for r in phases.values())
run = Path(phases['guests']['stdout']).parent
native = read(base / 'gate/native-execution/results.json')
assert native['success'] and native['allocation_failures'] == 'full'
nrun = Path(next(p for p in native['artifacts'] if p.endswith('inventory.stdout.log'))).parent
records = [json.loads(line.split('\t', 1)[1]) for path in nrun.glob('shard-*.stderr.log')
           for line in path.read_text().splitlines() if line.startswith('BLOT_NATIVE_TEST\t')]
assert len(records) == len({r['name'] for r in records}) == 2539
assert all(r['status'] == 'passed' and r['allocation_failures'] == 'full' and not r['leaks'] and not r['logged_errors'] for r in records)
def cases(name):
    rows = list(ET.parse(Path(phases[name]['stdout']).parent / (name + '.junit.xml')).iter('testcase'))
    assert rows and all(all(c.find(k) is None for k in ['failure', 'error', 'skipped']) for c in rows)
    return len(rows)
cold, retained = [read(base / name / 'results.json') for name in ['cold', 'retained']]
assert all(r['success'] and r['inputs_unchanged'] and not r['unexpected_problems'] for r in [cold, retained])
samples = [json.loads(s) for s in (base / 'cold/samples.jsonl').read_text().splitlines()]
def ratios(workload):
    groups = [{s['variant']: s for s in samples if s['run'] == i and s['workload'] == workload} for i in range(7)]
    assert all(set(g) == {'baseline', 'candidate'} for g in groups)
    return [g['candidate']['cpu_ms'] / g['baseline']['cpu_ms'] for g in groups]
profile = read(base / 'stacks/cpu-report.json')
windows = [json.loads(s) for s in (base / 'stacks/builds.jsonl').read_text().splitlines()]
windows = [b for b in windows if b['sampled']]
previous, spawn_ns = {}, 0
for line in (base / 'stacks/samples.jsonl').read_text().splitlines():
    row = json.loads(line); end = row['wall_ns'] / 1e6
    start = previous.get(row['run']); previous[row['run']] = end
    if start is None or not any(b['run'] == row['run'] and b['started_ms'] <= start <= end <= b['finished_ms'] for b in windows): continue
    for stack, weight in zip(row['st'], row['cpu_ns']):
        if weight and weight > 0 and stack and stack[0][0].endswith('prepareSpawnApplication'): spawn_ns += weight
spawn = 100 * spawn_ns / (profile['covered_cpu_ms'] * 1e6)
game_ratios, devtools_ratios = ratios('game'), ratios('devtools')
summary = {
    'base_commit': '63c931fd2e9eca212fc282df70b373de9a9b1a79',
    'scope': 'Isolated CT96 only; concurrent text-capability changes are excluded.',
    'native_laws': len(records), 'guests': cases('guests'), 'smoke': cases('smoke'),
    'harness': int(re.findall(r'ok \| (\d+) passed \| 0 failed', Path(phases['harness']['stdout']).read_text())[-1]),
    'gate_wall_seconds': gate['wall_seconds'],
    'phase_seconds': {n: p['wall_seconds'] for n, p in phases.items()},
    'candidate_sha256': sha((base / 'candidate/blotc').read_bytes()),
    'game_paired_cpu_ratios': game_ratios,
    'game_paired_cpu_ratio_median': statistics.median(game_ratios),
    'devtools_paired_cpu_ratios': devtools_ratios,
    'devtools_paired_cpu_ratio_median': statistics.median(devtools_ratios),
    'spawn_sampled_cpu_percent': spawn,
    'profile_coverage': profile['coverage_ratio'],
    'acceptance': statistics.median(game_ratios) <= .8 and statistics.median(devtools_ratios) <= 1.05 and spawn < 5,
    'cold_costs': cold['costs'], 'retained_costs': retained['costs'],
}
assert '0 findings remain' in (base / 'lint.log').read_text()
pins = read(base / 'candidate-pins.json')
for name, digest in pins['sha256'].items():
    # The gate intentionally packages its generated compiler; all original inputs remain pinned.
    assert sha((base / 'blot2' / name).read_bytes()) == digest, name
summary['source_inputs_unchanged'] = True
(base / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
safe = json.loads(json.dumps(gate))
for value in safe.get('native_qualification', {}).values():
    if 'key' in value: value['key_sha256'] = sha(value.pop('key').encode())
payload = {'gate.json': (json.dumps(safe, indent=2) + '\n').encode()}
def add(path, name=None):
    data = path.read_bytes()
    if path.suffix == '.json':
        value = json.loads(data)
        if isinstance(value, dict) and 'native_qualification' in value:
            for item in value['native_qualification'].values():
                if 'key' in item: item['key_sha256'] = sha(item.pop('key').encode())
            data = (json.dumps(value, indent=2) + '\n').encode()
    payload[name or str(path.relative_to(base))] = data
for path in base.iterdir():
    if path.name == 'archive-report.log': continue
    if path.is_file() and path.suffix in {'.json', '.log', '.txt', '.py', '.patch'}: add(path)
add(base / 'candidate/identity.json')
for directory in ['cold', 'retained', 'stacks']:
    for path in (base / directory).iterdir():
        if path.is_file() and path.suffix in {'.json', '.jsonl', '.log', '.txt'}: add(path)
for directory in (base / 'gate').glob('run-*'):
    for path in directory.iterdir():
        if path.suffix in {'.log', '.xml'}: add(path)
for directory in (base / 'gate/native-execution').glob('run-*'):
    for path in directory.iterdir():
        if path.is_file(): add(path)
for directory in ['development', 'development-fixed']:
    for path in (base / directory).rglob('*'):
        if path.is_file() and path.suffix in {'.json', '.log', '.xml'}: add(path)
for name in ['zig-native/src/backend/core_backend.zig', 'zig-native/src/backend/backend_emission.zig', 'zig-native/tests/task_surface_execution.test.ts']:
    add(base / 'blot2' / name, 'candidate-source/' + name)
for name in ['manifest.json', 'wasm.json', 'host.json', 'baseline/identity.json']:
    add(repo / 'build/bench/compile-cost-20261023' / name, 'baseline/' + name)
payload['SHA256SUMS'] = ''.join(f'{sha(data)}  {name}\n' for name, data in sorted(payload.items())).encode()
archive = repo / 'zig-native/measurements/ct96-spawn-scan-2026-10-23.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as tar:
    for name, data in sorted(payload.items()):
        info = tarfile.TarInfo(name); info.size = len(data); info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as tar:
    for line in tar.extractfile('SHA256SUMS').read().decode().splitlines():
        digest, name = line.split('  ', 1)
        assert sha(tar.extractfile(name).read()) == digest, name
print(json.dumps({k:v for k,v in summary.items() if k not in ['cold_costs','retained_costs']}, indent=2))
print('Archive', archive.name, 'bytes', archive.stat().st_size, 'sha256', sha(archive.read_bytes()))
