# Core and interface worker tables

The adjacent measurements pin all three sibling sources, both optimized
compiler binaries and the toolchain. The archive omits the 538 local
packets per build. The capture shim calls the real publisher, then saves a
copy of each successfully published packet. The O0 capture binaries are
used only to generate data. Ordinary Gdev latency uses the O2 release builds.

Extract these files under build/core-packets in the repository. Run commands
from the repository root. Start at 4aa525c1 and build the release compiler.
Save its optimized binary and run python3 build/core-packets/capture.py input.
Apply production.patch and build the release compiler again. Save the new
optimized binary and run capture.py new-input. Each capture uses the emitted
C from its own source checkout. Use distinct empty capture directories.
Stamps inside trailing timing counters vary between runs.

Run the packet_list engine test with the pinned Goose executable and stdlib.
Set BLOT_ENGINE_RECEIPT to the emitted gzip receipt including packet_list
emit and link stages. harness.py reuses the toolchain, native objects and
-O2 flags to compile small Goose probes. Run harness.py with each of the
arguments fields, arrays, audit-old and audit-new. The first two stages read
input/ and write their counts and labels under their own stage directories.
fields instruments a single ordinary packet codec to measure costs per
record field. arrays compares the previous scalar and verified image paths
for each selected table, checks decoded element equality and byte counts.

For each audit stage, create its canonical/ subdirectory. Run its executable
with BLOT_PACKET_SAMPLES naming the matching input directory and
BLOT_VERIFY_DIR naming that stage's canonical/ directory. Both executables
independently encode the portable BLOTDEP1 image with a zero key. Run
python3 build/core-packets/replay_trials.py to compare all 538 portable
records, then time twelve alternating pairs on the captured workload.
File reads and canonical snapshot generation are outside the codec timers.

time.ts uses the standard Gdev integration harness and records waited child
CPU via Linux getrusage after each compiler is disposed. Use deno run -A
build/core-packets/time.ts with --before and --after binary paths, and
--rounds 20. Swap executables for a second fresh window; run --edits and
--profile separately. Optional sample.c is the 1 ms process CPU sampler
from the function-unification evidence. Its raw records contain PID, image
kind, relative instruction address and sample multiplicity. Sampling is
separate from ordinary timings.

compare-bodies.ts also saves the retained edited Wasm at the --wasm path
plus ".edit". Run a single --edits pair with --wasm build/core-packets/main.wasm
and pass that path and its .edit counterpart to body_diff.py. It compares
each defined body at the same ordinal and every section payload.

The native regression tests exercise invalid
discriminants, truncations, owner decoding, counts and budgets.
