from pathlib import Path
import subprocess,time,json,hashlib,os
root=Path('/home/mewhhaha/src/blot2');out=root/'build/bench/ct105';work=root/'build/bench/compile-cost-20261023'
base=out/'baseline/blotc';candidate=root/'zig-native/zig-out/bin/blotc'
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins=json.loads((out/'final-pins.json').read_text())
assert sha(base)==pins['baseline']['sha256']
bench=['deno','task','bench:compile','--baseline',str(base),'--candidate',str(candidate),'--snapshot',str(work/'snapshot'),'--manifest',str(work/'manifest.json'),'--hashes',str(root/'build/bench/ct103/wasm.json'),'--workload','game,devtools','--scenarios','literal_in_body,body_change']
commands=[('pairs',bench+['--runs','7','--guard-cpu','--out',str(out/'pairs')]),('phases',bench+['--runs','1','--profile','--out',str(out/'phases')]),('warm-series',['deno','run','--allow-all',str(out/'warm_series.ts')]),('memory-series',['deno','run','--allow-all',str(out/'memory_series.ts')]),('restart',bench+['--runs','1','--restart-cache','--out',str(out/'restart')]),('gate',['deno','task','test:compiler','--native-shards','4','--phase-seconds','1800','--budget-seconds','2400','--timings-dir',str(out/'gate')])]
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');statuses=json.loads((out/'status.json').read_text())
env=os.environ.copy();env['ZIG_ANALYZER']=str(out/'tools/bin/zig-analyzer')
for name,cmd in commands:
 if any(r['name']==name and r['exit_code']==0 for r in statuses):continue
 assert sha(candidate)==pins['candidate']['sha256']
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT,env=env)
 row={'name':name,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start,'load':os.getloadavg()};statuses.append(row);(out/'status.json').write_text(json.dumps(statuses,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
for name,digest in pins['source'].items():assert sha(root/name)==digest,name
assert sha(candidate)==pins['candidate']['sha256']
(out/'release-checks-success.json').write_text(json.dumps({'success':True,'source_unchanged':True,'binaries_unchanged':True})+'\n')
