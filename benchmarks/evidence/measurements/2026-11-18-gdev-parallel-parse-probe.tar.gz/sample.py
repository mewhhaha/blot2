import collections,os,struct,shlex,re,subprocess,sys,json,bisect
from pathlib import Path
d=Path('build/parse-pilot').resolve(); exe=d/'candidate'
suffix=''
if 'ordinary' in sys.argv:suffix='-ordinary'
syms=subprocess.check_output(['nm','-n','-S',exe],text=True).splitlines()
off=next(l.split()[0] for l in syms if l.endswith(' d lane_meter'))
script=d/'sampled'
keys={'BLOT_PARSE_WIDTH':'8','BLOT_LANE_TIMING':d/('sample'+suffix+'.lanes'),'BLOT_SAMPLE_OFFSET':off,'BLOT_SAMPLE_EXE':exe,'BLOT_SAMPLE_OUT':d/('samples'+suffix+'.bin'),'LD_PRELOAD':d/'sample.so'}
script.write_text('#!/bin/sh\n'+''.join('export '+k+'='+shlex.quote(str(v))+'\n' for k,v in keys.items())+'exec '+shlex.quote(str(exe))+' "$@"\n');script.chmod(0o755)
if len(sys.argv)>1 and sys.argv[1]=='run':
 with (d/('sampled'+suffix+'.jsonl')).open('w') as f:subprocess.run(['deno','run','-A','scripts/integration/time_gdev_parse.ts','--before',script,'--after',script,'--rounds','3']+([] if suffix else ['--profile']),check=True,stdout=f)
segments=[]
for l in syms:
 a=l.split(maxsplit=3)
 if len(a)==4 and a[2] in ('t','T','w','W'):segments.append((int(a[0],16),int(a[1],16),a[3]))
starts=[a[0] for a in segments];counts=collections.Counter()
for (pc,) in struct.iter_unpack('=Q',(d/('samples'+suffix+'.bin')).read_bytes()):
 i=bisect.bisect_right(starts,pc)-1
 name='outside executable'
 if i>=0 and pc<starts[i]+segments[i][1]:name=re.sub(r'_g\d+(?:_\d+)*$','',segments[i][2])
 counts[name]+=1
(d/('samples'+suffix+'.json')).write_text(json.dumps(dict(counts.most_common()),indent=2))
print(sum(counts.values()),counts.most_common(25))
