import hashlib,json,statistics,subprocess
from pathlib import Path
root=Path('build/remaining-runtime')
sides={'baseline':'build/issue-fixes/candidate-blotc','candidate':str(root/'candidate-blotc')}
def sha(path): return hashlib.sha256(Path(path).read_bytes()).hexdigest()
source_root=Path('../gdev/.gdev/bench/captures/architecture-slots/sources')
assets_root=Path('../gdev/.gdev/bench/captures/architecture-slots/game/assets')
def inputs():
 return {str(p):sha(p) for base in [source_root,assets_root] for p in sorted(base.rglob('*')) if p.is_file() and '.cache' not in p.parts and '.gdev' not in p.relative_to(base).parts}
pins=inputs(); compiler_pins={k:sha(v) for k,v in sides.items()}
results={side:[] for side in sides}
for round in range(3):
 for side in (list(sides) if round%2==0 else list(reversed(sides))):
  name=f'gdev-compile-{side}-r{round}'
  subprocess.run(['deno','run','-A',str(root/'build-gdev.ts'),sides[side],name],check=True)
  r=json.loads((root/f'{name}-compile.json').read_text());r['wasm_sha256']=sha(root/f'{name}.wasm');results[side].append(r)
assert pins==inputs()
assert compiler_pins=={k:sha(v) for k,v in sides.items()}
for side,runs in results.items(): assert len({x['wasm_sha256'] for x in runs})==1,side
report={'complete':True,'scope':'Three alternating fresh compiler processes, cache disabled, frozen gdev source and native assets, no profiling. Build CPU excludes startup/open. Shared-host screen; no ordinary-edit claim.','compiler_sha256':compiler_pins,'source_sha256':pins,'results':results,'medians':{side:{metric:statistics.median(x['measurement'][metric] for x in runs) for metric in runs[0]['measurement'] if metric!='scope'} for side,runs in results.items()}}
(root/'gdev-compile-results.json').write_text(json.dumps(report,indent=2)+'\n')
print(json.dumps(report['medians'],indent=2))
