//! Region-local storage with bump blocks and reusable large buffers.
//! Reset cannot allocate or fail; only raw storage
//! returns to the pool. Published evidence must be copied to its durable owner.
const std = @import("std");
const A = std.mem.Allocator;
const Alignment = std.mem.Alignment;
pub const limit = 64 * 1024 * 1024;
pub const Costs = struct {
    large_requested_bytes: usize = 0,
    large_provided_bytes: usize = 0,
    large_fresh_bytes: usize = 0,
    large_reused_bytes: usize = 0,
    large_remap_growth_bytes: usize = 0,
    small_padding_bytes: usize = 0,
};
pub const Stats = struct {
    requested: usize = 0,
    reused: usize = 0,
    retained_bytes: usize = 0,
    max_capacity: usize = 0,
    oversized_discards: usize = 0,
    discarded_bytes: usize = 0,
    costs: Costs = .{},
};
const Block = struct {
    next: ?*Block = null,
    capacity: usize,
    used: usize = 0,
    fn bytes(self: *Block) []u8 {
        return @as([*]u8, @ptrCast(self))[0 .. @sizeOf(Block) + self.capacity];
    }
    fn position(self: *Block, alignment: Alignment) ?usize {
        const base = @intFromPtr(self);
        const end = std.math.add(usize, base, @sizeOf(Block) + self.used + @sizeOf(Header)) catch return null;
        const padded = std.math.add(usize, end, @max(alignment.toByteUnits(), @alignOf(Header)) - 1) catch return null;
        return (padded & ~(@max(alignment.toByteUnits(), @alignOf(Header)) - 1)) - base - @sizeOf(Block);
    }
};

const Header = struct { large: ?*Large };
const Large = struct {
    next: ?*Large = null,
    previous: ?*Large = null,
    free_next: ?*Large = null,
    capacity: usize,
    bin: usize,
    fn bytes(self: *Large) []u8 {
        return @as([*]u8, @ptrCast(self))[0..self.capacity];
    }
};
const bin_count = @bitSizeOf(usize) * 4;
const large_threshold = 4096;

const SizeClass = struct {
    capacity: usize,
    bin: usize,
    fn forBytes(needed: usize, compact: bool) ?SizeClass {
        const power = std.math.ceilPowerOfTwo(usize, needed) catch return null;
        const exponent: usize = std.math.log2_int(usize, power);
        // Below the session heap's direct-map boundary, its own power-of-two
        // classes would erase the saving. Above it, four subdivisions limit
        // rounding waste without turning every request into a separate bin.
        if (!compact or power <= 32768) return .{ .capacity = power, .bin = exponent * 4 + 3 };
        const step = power / 8;
        const parts = (needed - 1) / step + 1;
        return .{ .capacity = parts * step, .bin = exponent * 4 + parts - 5 };
    }
};

pub const Arena = struct {
    backing: A,
    head: ?*Block = null,
    tail: ?*Block = null,
    current: ?*Block = null,
    capacity: usize = 0,
    costs: Costs = .{},
    compact_large_bins: bool = true,
    large: ?*Large = null,
    available: [bin_count]?*Large = @splat(null),
    // The Arena is heap-stable and exclusively leased. These adapters measure
    // logical client requests, not the backing block totals or retained capacity.
    solver_meter: @import("../runtime/memory.zig").TrackedAllocator = undefined,
    scratch_meter: @import("../runtime/memory.zig").TrackedAllocator = undefined,

    fn beginLease(self: *Arena) void {
        self.costs = .{};
        self.solver_meter = .{ .backing = self.allocator() };
        self.scratch_meter = .{ .backing = self.allocator() };
    }
    pub fn solverAllocator(self: *Arena) A {
        return self.solver_meter.allocator();
    }
    pub fn scratchAllocator(self: *Arena) A {
        return self.scratch_meter.allocator();
    }

    pub fn allocator(self: *Arena) A {
        return .{ .ptr = self, .vtable = &.{ .alloc = alloc, .resize = resize, .remap = remap, .free = free } };
    }
    fn deinit(self: *Arena) void {
        const backing = self.backing;
        var cursor = self.head;
        while (cursor) |block| {
            cursor = block.next;
            backing.rawFree(block.bytes(), .of(Block), @returnAddress());
        }
        var large = self.large;
        while (large) |block| {
            large = block.next;
            backing.rawFree(block.bytes(), .of(Large), @returnAddress());
        }
        backing.destroy(self);
    }
    fn reset(self: *Arena) void {
        var cursor = self.head;
        while (cursor) |block| : (cursor = block.next) block.used = 0;
        self.current = self.head;
        self.available = @splat(null);
        var large = self.large;
        while (large) |block| : (large = block.next) {
            block.free_next = self.available[block.bin];
            self.available[block.bin] = block;
        }
    }
    fn alloc(raw: *anyopaque, len: usize, alignment: Alignment, ret: usize) ?[*]u8 {
        const self: *Arena = @ptrCast(@alignCast(raw));
        if (len >= large_threshold) return self.allocLarge(len, alignment, ret);
        var cursor = self.current;
        while (cursor) |block| : (cursor = block.next) {
            const start = block.position(alignment) orelse return null;
            if (start > block.capacity or len > block.capacity - start) continue;
            self.costs.small_padding_bytes += start - block.used;
            block.used = start + len;
            self.current = block;
            const result = block.bytes().ptr + @sizeOf(Block) + start;
            header(result).* = .{ .large = null };
            return result;
        }
        const needed = std.math.add(usize, len, @max(alignment.toByteUnits(), @alignOf(Header)) - 1 + @sizeOf(Header)) catch return null;
        const growth = if (self.tail) |last| @as(usize, @min(last.capacity, 512 * 1024)) * 2 else 4096;
        const capacity = @max(needed, growth);
        const size = std.math.add(usize, @sizeOf(Block), capacity) catch return null;
        const total = std.math.add(usize, self.capacity, size) catch return null;
        const memory = self.backing.rawAlloc(size, .of(Block), ret) orelse return null;
        const block: *Block = @ptrCast(@alignCast(memory));
        block.* = .{ .capacity = capacity };
        if (self.tail) |last| last.next = block else self.head = block;
        self.tail = block;
        self.current = block;
        self.capacity = total;
        const start = block.position(alignment).?;
        self.costs.small_padding_bytes += start;
        block.used = start + len;
        const result = memory + @sizeOf(Block) + start;
        header(result).* = .{ .large = null };
        return result;
    }
    fn header(memory: [*]u8) *Header {
        return @ptrCast(@alignCast(memory - @sizeOf(Header)));
    }
    fn allocLarge(self: *Arena, len: usize, alignment: Alignment, ret: usize) ?[*]u8 {
        const align_bytes = @max(alignment.toByteUnits(), @alignOf(Header));
        const overhead = std.math.add(usize, @sizeOf(Large) + @sizeOf(Header), align_bytes - 1) catch return null;
        const needed = std.math.add(usize, len, overhead) catch return null;
        const size_class = SizeClass.forBytes(needed, self.compact_large_bins) orelse return null;
        const capacity = size_class.capacity;
        const bin = size_class.bin;
        const block = if (self.available[bin]) |available| reused: {
            self.available[bin] = available.free_next;
            self.costs.large_reused_bytes += available.capacity;
            break :reused available;
        } else created: {
            const total = std.math.add(usize, self.capacity, capacity) catch return null;
            const memory = self.backing.rawAlloc(capacity, .of(Large), ret) orelse return null;
            const new: *Large = @ptrCast(@alignCast(memory));
            new.* = .{ .next = self.large, .capacity = capacity, .bin = bin };
            if (self.large) |first| first.previous = new;
            self.large = new;
            self.capacity = total;
            self.costs.large_fresh_bytes += capacity;
            break :created new;
        };
        const start = std.mem.alignForward(usize, @intFromPtr(block) + @sizeOf(Large) + @sizeOf(Header), align_bytes);
        const result: [*]u8 = @ptrFromInt(start);
        self.costs.large_requested_bytes += len;
        self.costs.large_provided_bytes += block.capacity;
        header(result).* = .{ .large = block };
        return result;
    }
    fn resize(raw: *anyopaque, memory: []u8, _: Alignment, len: usize, _: usize) bool {
        const self: *Arena = @ptrCast(@alignCast(raw));
        if (header(memory.ptr).large) |block| {
            const offset = @intFromPtr(memory.ptr) - @intFromPtr(block);
            return len <= block.capacity - offset;
        }
        if (self.current) |block| {
            const payload = @intFromPtr(block) + @sizeOf(Block);
            if (@intFromPtr(memory.ptr) + memory.len == payload + block.used and @intFromPtr(memory.ptr) >= payload) {
                const start = @intFromPtr(memory.ptr) - payload;
                if (len > block.capacity - start) return false;
                block.used = start + len;
                return true;
            }
        }
        return len <= memory.len;
    }
    fn remap(raw: *anyopaque, memory: []u8, alignment: Alignment, len: usize, ret: usize) ?[*]u8 {
        if (resize(raw, memory, alignment, len, ret)) return memory.ptr;
        const self: *Arena = @ptrCast(@alignCast(raw));
        const block = header(memory.ptr).large orelse return null;
        // The payload offset stays invariant when the backing alignment already
        // satisfies it. More strongly aligned allocations use ordinary copying.
        if (block.capacity < 1024 * 1024 or alignment.toByteUnits() > @alignOf(Large)) return null;
        const offset = @intFromPtr(memory.ptr) - @intFromPtr(block);
        const needed = std.math.add(usize, len, offset) catch return null;
        const size_class = SizeClass.forBytes(needed, self.compact_large_bins) orelse return null;
        const capacity = size_class.capacity;
        const growth = capacity - block.capacity;
        const total = std.math.add(usize, self.capacity - block.capacity, capacity) catch return null;
        const moved = self.backing.rawRemap(block.bytes(), .of(Large), capacity, ret) orelse return null;
        const next: *Large = @ptrCast(@alignCast(moved));
        next.capacity = capacity;
        next.bin = size_class.bin;
        if (next.previous) |previous| previous.next = next else self.large = next;
        if (next.next) |following| following.previous = next;
        self.capacity = total;
        self.costs.large_remap_growth_bytes += growth;
        const result = moved + offset;
        header(result).* = .{ .large = next };
        return result;
    }
    fn free(raw: *anyopaque, memory: []u8, alignment: Alignment, ret: usize) void {
        const self: *Arena = @ptrCast(@alignCast(raw));
        if (header(memory.ptr).large) |block| {
            block.free_next = self.available[block.bin];
            self.available[block.bin] = block;
            return;
        }
        if (self.current) |block| {
            const end = @intFromPtr(block) + @sizeOf(Block) + block.used;
            if (@intFromPtr(memory.ptr) + memory.len == end) {
                block.used -= memory.len + @sizeOf(Header);
                return;
            }
        }
        _ = alignment;
        _ = ret;
    }
};

pub const Pool = struct {
    original: A,
    compact_large_bins: bool = true,
    slot: ?*Arena = null,
    stats: Stats = .{},

    pub fn init(a: A) Pool {
        return .{ .original = a };
    }
    pub fn deinit(self: *Pool) void {
        if (self.slot) |arena| arena.deinit();
        self.* = undefined;
    }
    fn matches(self: *const Pool, a: A) bool {
        return a.ptr == self.original.ptr and a.vtable == self.original.vtable;
    }
    pub fn take(self: *Pool, a: A) A.Error!*Arena {
        self.stats.requested += 1;
        if (self.matches(a)) if (self.slot) |arena| {
            self.slot = null;
            self.stats.reused += 1;
            self.stats.retained_bytes = 0;
            arena.beginLease();
            return arena;
        };
        const arena = try a.create(Arena);
        arena.* = .{ .backing = a, .compact_large_bins = self.compact_large_bins };
        arena.beginLease();
        return arena;
    }
    pub fn give(self: *Pool, arena: *Arena) void {
        self.stats.max_capacity = @max(self.stats.max_capacity, arena.capacity);
        inline for (@typeInfo(Costs).@"struct".field_names) |field| @field(self.stats.costs, field) += @field(arena.costs, field);
        if (!self.matches(arena.backing) or arena.capacity > limit) {
            self.stats.oversized_discards += @intFromBool(arena.capacity > limit);
            self.stats.discarded_bytes += arena.capacity;
            arena.deinit();
            return;
        }
        if (self.slot) |old| {
            if (old.capacity >= arena.capacity) {
                arena.deinit();
                return;
            }
            old.deinit();
        }
        arena.reset();
        self.slot = arena;
        self.stats.retained_bytes = arena.capacity;
    }
};

fn ownershipScenario(backing: A) !void {
    var tracked: @import("../runtime/memory.zig").TrackedAllocator = .{ .backing = backing };
    const a = tracked.allocator();
    var pool = Pool.init(a);
    var alive = true;
    defer if (alive) pool.deinit();
    const arena = try pool.take(a);
    var leased = true;
    defer if (leased) pool.give(arena);
    const scratch = arena.allocator();
    const small = try scratch.alloc(u8, 17);
    @memset(small, 13);
    const aligned = try scratch.alignedAlloc(u8, .fromByteUnits(4096), 257);
    @memset(aligned, 29);
    const wide = try scratch.alloc(u8, 70_000);
    @memset(wide, 71);
    const expanded = try scratch.realloc(wide, 80_000);
    const large = try scratch.alloc(u8, 1024 * 1024);
    const following = try scratch.alloc(u8, 1024 * 1024);
    for (expanded[0..70_000]) |byte| try std.testing.expectEqual(@as(u8, 71), byte);
    for (small) |byte| try std.testing.expectEqual(@as(u8, 13), byte);
    for (aligned) |byte| try std.testing.expectEqual(@as(u8, 29), byte);
    scratch.free(small);
    scratch.free(aligned);
    scratch.free(expanded);
    scratch.free(large);
    scratch.free(following);
    const allocations = tracked.counts.allocations;
    pool.give(arena);
    leased = false;
    try std.testing.expectEqual(allocations, tracked.counts.allocations);
    const next = try pool.take(a);
    var next_leased = true;
    defer if (next_leased) pool.give(next);
    _ = try next.allocator().alloc(u8, 17);
    _ = try next.allocator().alignedAlloc(u8, .fromByteUnits(4096), 257);
    _ = try next.allocator().alloc(u8, 70_000);
    try std.testing.expectEqual(allocations, tracked.counts.allocations);
    // Return explicitly so all backing storage can be checked after teardown.
    pool.give(next);
    next_leased = false;
    pool.deinit();
    alive = false;
    try std.testing.expectEqual(@as(usize, 0), tracked.counts.live_bytes);
}

fn compactBinsScenario(a: A) !void {
    var capacities: [2]usize = undefined;
    for ([_]bool{ false, true }, 0..) |compact, policy| {
        var pool = Pool.init(a);
        defer pool.deinit();
        pool.compact_large_bins = compact;
        const arena = try pool.take(a);
        var leased = true;
        defer if (leased) pool.give(arena);
        const scratch = arena.allocator();
        var first = try scratch.alloc(u8, 65536);
        @memset(first, 31);
        const neighbor = try scratch.alignedAlloc(u8, .fromByteUnits(4096), 70000);
        @memset(neighbor, 53);
        capacities[policy] = arena.capacity;
        first = try scratch.realloc(first, 90000);
        for (first[0..65536]) |byte| try std.testing.expectEqual(@as(u8, 31), byte);
        for (neighbor) |byte| try std.testing.expectEqual(@as(u8, 53), byte);
        scratch.free(first);
        scratch.free(neighbor);
        pool.give(arena);
        leased = false;
        const next = try pool.take(a);
        defer pool.give(next);
        const restored = try next.allocator().alignedAlloc(u8, .fromByteUnits(4096), 70000);
        try std.testing.expect(@intFromPtr(restored.ptr) % 4096 == 0);
        try std.testing.expect(next.costs.large_reused_bytes != 0);
    }
    try std.testing.expect(capacities[1] < capacities[0]);
}

test "compact arena bins preserve aligned neighbors growth reuse and allocation failure ownership" {
    try compactBinsScenario(std.testing.allocator);
    try @import("../allocation_failures.zig").checkAllAllocationFailures(std.testing.allocator, compactBinsScenario, .{});
}

fn growingBuffers(backing: A) !void {
    var tracked: @import("../runtime/memory.zig").TrackedAllocator = .{ .backing = backing };
    const a = tracked.allocator();
    var pool = Pool.init(a);
    var alive = true;
    defer if (alive) pool.deinit();
    const arena = try pool.take(a);
    var leased = true;
    defer if (leased) pool.give(arena);
    const scratch = arena.allocator();
    var growing = try scratch.alloc(u8, 70000);
    @memset(growing, 31);
    const pinned = try scratch.alloc(u8, 140000);
    @memset(pinned, 53);
    for ([_]usize{ 180000, 300000, 600000 }) |size| {
        const previous = growing.len;
        growing = try scratch.realloc(growing, size);
        for (growing[0..previous]) |byte| try std.testing.expectEqual(@as(u8, 31), byte);
        @memset(growing[previous..], 31);
        for (pinned) |byte| try std.testing.expectEqual(@as(u8, 53), byte);
    }
    const allocations = tracked.counts.allocations;
    const shortened = try scratch.realloc(growing, 1);
    try std.testing.expectEqual(@as(u8, 31), shortened[0]);
    scratch.free(shortened);
    const reused = try scratch.alloc(u8, 600000);
    try std.testing.expectEqual(allocations, tracked.counts.allocations);
    scratch.free(pinned);
    scratch.free(reused);
    pool.give(arena);
    leased = false;
    pool.deinit();
    alive = false;
    try std.testing.expectEqual(@as(usize, 0), tracked.counts.live_bytes);
}

test "region arenas preserve live buffers during large remapping shrinking recycling and allocation failure" {
    try growingBuffers(std.testing.allocator);
    try growingBuffers(std.heap.page_allocator);
    try @import("../allocation_failures.zig").checkAllAllocationFailures(std.testing.allocator, growingBuffers, .{});
}

test "region arenas preserve aligned live allocations and reset without allocating" {
    try ownershipScenario(std.testing.allocator);
    try @import("../allocation_failures.zig").checkAllAllocationFailures(std.testing.allocator, ownershipScenario, .{});
}

test "region client meters keep nested solver scratch owners separate and reset on lease reuse" {
    const a = std.testing.allocator;
    var pool = Pool.init(a);
    defer pool.deinit();
    const outer = try pool.take(a);
    var outer_live = true;
    defer if (outer_live) pool.give(outer);
    const solver = outer.solverAllocator();
    const scratch = outer.scratchAllocator();
    const pinned = try solver.alloc(u8, 37);
    @memset(pinned, 19);
    var growth = try scratch.alloc(u8, 70000);
    growth = try scratch.realloc(growth, 180000);
    const inner = try pool.take(a);
    const nested = try inner.solverAllocator().alloc(u8, 53);
    try std.testing.expectEqual(@as(usize, 53), inner.solver_meter.counts.allocated_bytes);
    try std.testing.expectEqual(@as(usize, 37), outer.solver_meter.counts.allocated_bytes);
    try std.testing.expect(outer.scratch_meter.counts.allocated_bytes >= 180000);
    try std.testing.expectEqual(@as(usize, 0), inner.scratch_meter.counts.allocated_bytes);
    inner.solverAllocator().free(nested);
    pool.give(inner);
    for (pinned) |byte| try std.testing.expectEqual(@as(u8, 19), byte);
    solver.free(pinned);
    scratch.free(growth);
    try std.testing.expectEqual(@as(usize, 0), outer.solver_meter.counts.live_bytes);
    try std.testing.expectEqual(@as(usize, 0), outer.scratch_meter.counts.live_bytes);
    pool.give(outer);
    outer_live = false;
    const next = try pool.take(a);
    defer pool.give(next);
    try std.testing.expectEqual(@as(usize, 0), next.solver_meter.counts.allocated_bytes);
    try std.testing.expectEqual(@as(usize, 0), next.scratch_meter.counts.allocated_bytes);
}
