import support.project_packet;
import support.error;
import check.types;

fn main() {
    // The standalone proof builds the same codec with a 16-byte packet limit.
    let value = blot_check_types::List {0x12345678, 0xaabbccdd};
    for offset in 0..19 {
        var packet:u8[>..<] = [];
        packet.resize(offset, 0x55);
        var writer = blot_project_packet::Writer {packet};
        blot_project_packet::put(writer,value);
        var expected = offset;
        if offset <= 8 {expected += 8;assert(writer.failure==blot_error::Error.none);}
        else {
            if offset<=12 {expected+=4;}
            assert(writer.failure==blot_error::Error.artifact_limit);
        }
        assert(packet.len==expected && writer.depth==0);
        if expected>offset {assert(packet[offset]==0x78 && packet[offset+3]==0x12);}
        if expected>offset+4 {assert(packet[offset+4]==0xdd && packet[offset+7]==0xaa);}
    }
}
