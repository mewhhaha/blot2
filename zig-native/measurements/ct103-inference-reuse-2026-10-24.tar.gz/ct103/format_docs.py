from pathlib import Path
import subprocess
ranges=[
 ('README.md','The [compile measurements]','For a smaller development check'),
 ('zig-native/README.md','[Principal dependency reuse','`blotc build ENTRY'),
 ('CONTINUE.md','CT103/CT104 checkpoint,','CT97/CT98/BT4 checkpoint,'),
 ('FINISH_PLAN.md','CT103/CT104 checkpoint,','The preceding CT97 batch:'),
 ('zig-native/STATUS.md','## Principal dependency reuse','## Row traversal,'),
 ('PERFORMANCE_REVIEW.md','Latest outcome,','## Historical CT102 analysis'),
 ('COMPILE_MEASUREMENTS.md','Latest qualification:','Historical follow-up:'),
 ('COMPILE_HILLS.md','## Current queue:','## Historical program:'),
 ('BUILD_HILLS.md','Current follow-up:','Run the isolated build measurement'),
]
for name,start,end in ranges:
 p=Path(name);s=p.read_text();a=s.index(start);b=s.index(end,a)
 r=subprocess.run(['deno','fmt','--no-config','--ext','md','--prose-wrap','always','-'],input=s[a:b],text=True,capture_output=True,check=True)
 p.write_text(s[:a]+r.stdout.rstrip()+'\n\n'+s[b:])
print('Formatted updated documentation sections')
