# Gdev function-pair experiments
Use checkout b5d57724a1a3e8363662a6eb04831adcc07824ef from this repository.
fields.patch, worklist.patch, combined.patch and safe.patch each apply
independently with git apply. Build each using deno task build:compiler
and copy the release executable before changing source. The report gives
the fingerprints of the measured executables. Keep the unmodified release
at build/resolve-hill/candidate. The original scratch builds used the same
Goose and C optimization flags as the release and separate source trees.

To repeat the four-way benchmark, extract compare.ts to build/function-pairs/
and supply paths for --before (release), --after (fields), --worklist and
--combined. Use --rounds 16 for fresh runs, --rounds 8 --edits and
--rounds 4 --profile. Run from the repository root with deno run -A.
For safe.patch use scripts/integration/time_gdev_parse.ts with two compilers.
The second twenty-pair window swaps --before and --after.

The ordinary native regression suite is in compiler-goose/tests/resolution_views.goose
at c2fd3dd2. With the patched Goose toolchain installed, run
python3 compiler-goose/tools/test_engines.py resolution_views with
--goose and --stdlib pointing at that toolchain. The three standalone
Goose programs also work as the main.goose entry with compiler-goose/src
available as the import root. Use the emitted commands from the engine-test
receipt for a native build. Link tokens.c for cases.goose. It prints 4096
lines which compare byte for byte between the release and all four experiments.
The size/depth results are the last two output lines of scopes.goose.
negative-control.patch applies on top of worklist.patch. It makes laws.goose
fail at the ordered substitution where one variable is both input and output.

oracle.patch applies on top of worklist.patch, and safe-probe.patch on top
of safe.patch. Link the corresponding .c file alongside the native compiler
and set BLOT_CURSOR_LOG to an empty results file. Run a fresh Main build.
The oracle columns are module followed by matching and differing child IDs
for each of 32 tag codes. The safe probe columns are module, immediate,
full, both effects equal row ID zero, and all other eligible effect pairs.

To sample an unmodified Linux x86-64 release, extract cpu/ under
build/function-pairs. Create cpu/samples, chmod +x cpu/release, and compile
cpu/sample.c with cc -O2 -fPIC -shared -o cpu/sample.so cpu/sample.c -ldl -pthread
in build/function-pairs. Use an empty samples directory for each series.
From the repository root, run deno run -A scripts/integration/time_gdev_parse.ts
with --before and --after both set to build/function-pairs/cpu/release and
--rounds 6. Write stdout to build/function-pairs/cpu/runs.jsonl and run
python3 build/function-pairs/cpu/report.py. The sampler is loaded only in
the benchmark compiler and its descendants. It writes module-relative
instruction addresses and uses nm on the exact measured executable.
To obtain specialization names, generate the unmodified release C using
the pinned emit-program stage, place the result at cpu/release.c, and
run build/function-pairs/cpu/packet_types.py after the sample report.
The report maps all 35 sampled packet get/put symbols to parameter types.
