import { strict as assert } from "node:assert";
import { createZigProjectCompiler } from "/workspace/.numeric-tuning/compiler/zig_project_client.ts";
import { gdevWorkloads, editedSources, sessionOptions } from "/workspace/.numeric-tuning/scripts/bench/gdev.ts";
const root = "/workspace/.numeric-tuning";
const [exe, snapshot, out] = Deno.args;
assert(exe && snapshot && out);
await Deno.mkdir(out);
const sha = async (bytes: Uint8Array<ArrayBuffer>) => [...new Uint8Array(await crypto.subtle.digest("SHA-256", bytes))].map(x=>x.toString(16).padStart(2,"0")).join("");
const pins: Record<string,string> = {};
for (const path of [exe, `${root}/scripts/bench/gdev-manifest.json`, new URL(import.meta.url).pathname]) pins[path] = await sha(await Deno.readFile(path));
const manifest = JSON.parse(await Deno.readTextFile(`${root}/scripts/bench/gdev-manifest.json`));
for (const [file, expected] of Object.entries(manifest)) { const path=`${snapshot}/${file}`; assert.equal(await sha(await Deno.readFile(path)),expected); pins[path]=expected as string; }
async function pinStd(dir:string) { for await(const f of Deno.readDir(dir)){const path=`${dir}/${f.name}`; if(f.isDirectory) await pinStd(path);else if(f.isFile && f.name.endsWith('.blot'))pins[path]=await sha(await Deno.readFile(path));}}
await pinStd(`${root}/std`);
const [workload] = await gdevWorkloads(root,snapshot);
const scenario = workload.scenarios.find(x=>x.name==='literal_constant');assert(scenario);
const seed = await editedSources(workload, scenario);
const source = (index:number) => Object.fromEntries(Object.entries(seed).map(([p,s])=>{assert(s.includes('const floor_half_extent = 61.0'));return[p,s.replace('const floor_half_extent = 61.0',`const floor_half_extent = ${60+index}.0`)];}));
const options = {...sessionOptions(exe,workload),cacheDirectory:`${out}/checkpoint`,codegenWorkers:1,semanticWorkers:1,profileBackend:true};
const report = {started:new Date().toISOString(),pins,options,scope:'64 distinct scalar edits; four independent fresh controls, failed-edit recovery, no-op and checkpoint restart. Per-process schedstat CPU and RSS; profile allocation counts separate.',rows:[] as unknown[]};
await Deno.writeTextFile(`${out}/metadata.json`,JSON.stringify(report,null,2)+'\n');
async function usage(pid:number){let ns=0;for await(const t of Deno.readDir(`/proc/${pid}/task`)){try{ns+=Number((await Deno.readTextFile(`/proc/${pid}/task/${t.name}/schedstat`)).split(' ')[0]);}catch(e){if(!(e instanceof Deno.errors.NotFound))throw e;}}const status=await Deno.readTextFile(`/proc/${pid}/status`);return{ns,rss:Number(status.match(/^VmRSS:\s+(\d+)/m)?.[1]??0),peak:Number(status.match(/^VmHWM:\s+(\d+)/m)?.[1]??0)};}
async function record(row:unknown){report.rows.push(row);await Deno.writeTextFile(`${out}/samples.jsonl`,JSON.stringify(row)+'\n',{append:true});}
const compiler = await createZigProjectCompiler(options);
async function build(label:string, sources:Record<string,string>, success=true){const before=await usage(compiler.pid),start=performance.now();const result=await compiler.build({sources:{...workload.overlay,...sources}});const after=await usage(compiler.pid);assert.equal(result.success,success,JSON.stringify(result));const digest=result.success?await sha(result.bytes):null;await record({label,cpu_ms:(after.ns-before.ns)/1e6,wall_ms:performance.now()-start,rss_kib:after.rss,peak_rss_kib:after.peak,wasm_sha256:digest,stats:result.success?result.stats:result.attemptStats,diagnostics:result.success?[]:result.diagnostics});return digest;}
let original:string|null=null;
try{
 original=await build('population',{});assert.equal(await build('noop',{}),original);
 for(let i=1;i<=64;i++){
  const input=source(i);const hash=await build(`edit:${i}`,input);
  if([1,16,32,64].includes(i)){
   const control=await createZigProjectCompiler({...options,cacheDirectory:false});
   try{const fresh=await control.build({sources:{...workload.overlay,...input}});assert(fresh.success);assert.equal(await sha(fresh.bytes),hash);await record({label:`fresh-control:${i}`,wasm_sha256:hash});}finally{await control.dispose();}
  }
  if(i===32){const bad=Object.fromEntries(Object.entries(input).map(([p,s])=>[p,s+'\nentry const broken = fn () =>\n']));await build('rejected:32',bad,false);assert.equal(await build('recovery:32',input),hash);}
  if(i%8===0)console.log(`verified ${i}/64 distinct edits`);
 }
 assert.equal(await build('revert',{}),original);
}finally{await compiler.dispose();}
const restarted=await createZigProjectCompiler(options);
try{const value=await restarted.build({sources:{...workload.overlay}});assert(value.success);assert.equal(await sha(value.bytes),original);await record({label:'checkpoint-restart',wasm_sha256:original,stats:value.stats});assert.equal(value.stats.restartCacheLoaded,true,'checkpoint was not loaded');}finally{await restarted.dispose();}
for(const [path,expected] of Object.entries(pins))assert.equal(await sha(await Deno.readFile(path)),expected,path);
await Deno.writeTextFile(`${out}/report.json`,JSON.stringify({...report,finished:new Date().toISOString()},null,2)+'\n');
console.log('64 distinct edits, recovery, fresh controls and checkpoint restart passed');
