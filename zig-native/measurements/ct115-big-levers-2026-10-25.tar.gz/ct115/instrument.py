"""Add bounded, profile-only module observations to an isolated CT114 source copy."""
from pathlib import Path
import hashlib, json, difflib

work = Path(__file__).resolve().parent
root = work / 'diagnostic-work/blot2'
changed = {}
def edit(name, fn):
    path = root / name
    before = path.read_text()
    after = fn(before)
    assert before != after
    path.write_text(after)
    changed[name] = (before, after)

trace = r'''
// CT115 diagnostic-only trace. Fixed bounds and truncation are explicit.
pub const ModuleTrace = struct {
    unit: u32 = 0,
    filename: [320]u8 = @splat(0),
    dependencies: [128]u32 = @splat(0),
    dependency_count: usize = 0,
    truncated: bool = false,
    syntax_nodes: usize = 0,
    wall_ns: u64 = 0,
    cpu_ns: u64 = 0,
    headers_cpu_ns: u64 = 0,
    bodies_cpu_ns: u64 = 0,
    allocations: u64 = 0,
    requested_bytes: u64 = 0,
    imported_schemes: u64 = 0,
    candidates: u64 = 0,
    type_nodes: u64 = 0,
    free_type_visits: u64 = 0,
    free_row_visits: u64 = 0,
    pub fn jsonStringify(self: *const ModuleTrace, stream: *std.json.Stringify) std.Io.Writer.Error!void {
        try stream.beginObject();
        inline for (@typeInfo(ModuleTrace).@"struct".field_names) |field| {
            if (comptime !std.mem.eql(u8, field, "filename") and !std.mem.eql(u8, field, "dependencies")) {
                try stream.objectField(field);
                try stream.write(@field(self, field));
            }
        }
        try stream.objectField("filename");
        try stream.write(std.mem.sliceTo(&self.filename, 0));
        try stream.objectField("dependencies");
        try stream.write(self.dependencies[0..self.dependency_count]);
        try stream.endObject();
    }
};
const TraceClock = @import("backend/backend_timing.zig").Clock;
pub const ModuleScope = struct {
    profile: ?*Profile = null,
    slot: usize = 0,
    wall: TraceClock = .{ .io = null, .previous = null },
    cpu: TraceClock = .{ .io = null, .previous = null, .kind = .cpu_thread },
    before: @import("work_counters.zig").Frontend = .{},
    allocations: u64 = 0,
    bytes: u64 = 0,
    pub fn end(self: *ModuleScope) void {
        const profile = self.profile orelse return;
        const cpu = self.cpu.lapNanos();
        const wall = self.wall.lapNanos();
        const trace = &profile.modules[self.slot];
        trace.cpu_ns = cpu;
        trace.wall_ns = wall;
        trace.allocations = @atomicLoad(u64, &profile.allocations[@backingInt(Phase.check)], .monotonic) - self.allocations;
        trace.requested_bytes = @atomicLoad(u64, &profile.requested_bytes[@backingInt(Phase.check)], .monotonic) - self.bytes;
        inline for (.{ "imported_schemes", "candidates", "type_nodes" }) |field| @field(trace, field) = @field(profile.checking, field) - @field(self.before, field);
        inline for (.{ "free_type_visits", "free_row_visits" }) |field| @field(trace, field) = @field(profile.checking.normalization, field) - @field(self.before.normalization, field);
        profile.module_active = null;
    }
};
pub fn beginModule(unit: u32, filename: []const u8, imports: anytype, prelude: u32, nodes: usize) ModuleScope {
    const profile = installed orelse return .{};
    if (profile.active != .check) return .{};
    if (profile.module_count == profile.modules.len) {
        profile.module_overflow += 1;
        return .{};
    }
    const slot = profile.module_count;
    profile.module_count += 1;
    profile.module_active = slot;
    const trace = &profile.modules[slot];
    trace.unit = unit;
    trace.syntax_nodes = nodes;
    const len = @min(filename.len, trace.filename.len - 1);
    @memcpy(trace.filename[0..len], filename[0..len]);
    trace.truncated = filename.len != len;
    if (prelude != 0 and prelude != unit) {
        trace.dependencies[0] = prelude;
        trace.dependency_count = 1;
    }
    for (imports) |dependency| {
        if (std.mem.findScalar(u32, trace.dependencies[0..trace.dependency_count], dependency.target) != null) continue;
        if (trace.dependency_count == trace.dependencies.len) {
            trace.truncated = true;
            break;
        }
        trace.dependencies[trace.dependency_count] = dependency.target;
        trace.dependency_count += 1;
    }
    return .{
        .profile = profile, .slot = slot, .before = profile.checking,
        .allocations = @atomicLoad(u64, &profile.allocations[@backingInt(Phase.check)], .monotonic),
        .bytes = @atomicLoad(u64, &profile.requested_bytes[@backingInt(Phase.check)], .monotonic),
        .wall = TraceClock.init(profile.io), .cpu = TraceClock.initKind(profile.io, .cpu_thread),
    };
}
pub const PartScope = struct {
    trace: ?*ModuleTrace = null,
    clock: TraceClock = .{ .io = null, .previous = null, .kind = .cpu_thread },
    pub fn end(self: *PartScope, comptime field: []const u8) void {
        if (self.trace) |trace| @field(trace, field) += self.clock.lapNanos();
    }
};
pub fn beginModulePart() PartScope {
    const profile = installed orelse return .{};
    if (profile.active != .check) return .{};
    const slot = profile.module_active orelse return .{};
    return .{ .trace = &profile.modules[slot], .clock = TraceClock.initKind(profile.io, .cpu_thread) };
}
'''
def phase(text):
    marker='    checking: @import("work_counters.zig").Frontend = .{},'
    assert text.count(marker)==2
    text=text.replace(marker, marker+'\n    modules: [256]ModuleTrace = @splat(.{}),\n    module_count: usize = 0,\n    module_overflow: usize = 0,')
    text=text.replace('    nanos: [phase_count]u64', '    module_active: ?usize = null,\n    nanos: [phase_count]u64',1)
    text=text.replace('        result.checking = self.checking;', '        result.checking = self.checking;\n        result.modules = self.modules;\n        result.module_count = self.module_count;\n        result.module_overflow = self.module_overflow;',1)
    text=text.replace('            try stream.write(self.checking);', '            try stream.write(self.checking);\n            try stream.objectField("module_trace");\n            try stream.write(self.modules[0..self.module_count]);\n            try stream.objectField("module_trace_overflow");\n            try stream.write(self.module_overflow);',1)
    return text+trace
edit('zig-native/src/phase_profile.zig',phase)
def project(text):
    marker='    fn checkModule(self: *Engine, unit: project.UnitId) !void {\n'
    assert text.count(marker)==1
    return text.replace(marker,marker+'        var module_trace = @import("../phase_profile.zig").beginModule(unit, self.source.filename(unit), self.source.unitImports(unit), if (self.source.unit(unit).implicit_prelude) self.source.prelude_unit else 0, self.source.unit(unit).tree.nodes.items.len);\n        defer module_trace.end();\n')
edit('zig-native/src/reuse/project_check.zig',project)
def checker(text):
    marker='    try engine.collectModuleHeaders(imports, headers, catalogs, source_catalogs, allow_imports, options.inherited_fixities);\n    try engine.validateModuleBodies();'
    assert text.count(marker)==1
    return text.replace(marker,'''    var header_trace = @import("../phase_profile.zig").beginModulePart();
    try engine.collectModuleHeaders(imports, headers, catalogs, source_catalogs, allow_imports, options.inherited_fixities);
    header_trace.end("headers_cpu_ns");
    var body_trace = @import("../phase_profile.zig").beginModulePart();
    try engine.validateModuleBodies();
    body_trace.end("bodies_cpu_ns");''')
edit('zig-native/src/check/check.zig',checker)
patch=[]
for name,(before,after) in changed.items():
    patch.extend(difflib.unified_diff(before.splitlines(True),after.splitlines(True),fromfile='a/'+name,tofile='b/'+name))
(work/'diagnostic.patch').write_text(''.join(patch))
(work/'changed-files.json').write_text(json.dumps(list(changed),indent=2)+'\n')
print('Instrumented',len(changed),'isolated files; main compiler sources unchanged')
