from pathlib import Path
import json,statistics,hashlib
p=Path(__file__).parent
read=lambda f:json.loads((p/f).read_text())
rows=lambda f:[json.loads(l) for l in (p/f).read_text().splitlines()]
med=statistics.median
pairs=rows('pairs/samples.jsonl');summary=[]
for workload in ['game','devtools']:
 for phase in dict.fromkeys(r['phase'] for r in pairs if r['workload']==workload):
  selected=[r for r in pairs if r['workload']==workload and r['phase']==phase]
  variants={v:[r for r in selected if r['variant']==v] for v in ['baseline','candidate']}
  if not all(variants.values()):continue
  b={r['run']:r for r in variants['baseline']};c={r['run']:r for r in variants['candidate']}
  ratios={metric:[c[i][metric]/b[i][metric] for i in sorted(b.keys()&c.keys()) if b[i][metric]>0] for metric in ['cpu_ms','wall_ms']}
  summary.append({'workload':workload,'phase':phase,'samples':{v:len(rs) for v,rs in variants.items()},'medians':{v:{metric:med([r[metric] for r in rs]) for metric in ['cpu_ms','wall_ms','peak_rss_kib']} for v,rs in variants.items()},'paired':{metric:{'ratios':rs,'median':med(rs) if rs else None} for metric,rs in ratios.items()}})
report={'pairs':summary,'baseline':read('final-pins.json')['baseline'],'candidate':read('final-pins.json')['candidate']}
if (p/'pairs/results.json').exists():report['pair_success']=read('pairs/results.json')['success']
if (p/'phases/samples.jsonl').exists():
 report['phases']=[]
 for row in rows('phases/samples.jsonl'):
  s=row['stats'];backend=s.get('backendTiming',{});ph=s.get('phaseProfile',{}).get('phases',{})
  report['phases'].append({k:row[k] for k in ['workload','phase','variant','wall_ms','cpu_ms']}|{'phase_ms':{k:v['us']/1000 for k,v in ph.items()},'allocations':{k:{f:v[f] for f in ['requested_bytes','allocations']} for k,v in ph.items()},'backend_timing':backend,'work':s.get('workCounters',{}),'principals':s.get('principals',{}),'attempts':s.get('attemptStats',{})})
if (p/'warm-series-success.json').exists():
 report['warm_success']=read('warm-series-success.json');report['warm']=[{k:r[k] for k in ['variant','revision','wall_ms','cpu_ms','wasm_sha256']} for r in rows('warm-series.jsonl')]
if (p/'memory-series-success.json').exists():
 report['memory_success']=read('memory-series-success.json');report['memory']=[]
 for row in rows('memory-series.jsonl'):
  samples=row['samples'];first,last=samples[0],samples[-1];baseline=first['threads'];maxima={}
  for sample in samples:
   for tid,values in sample['threads'].items():maxima[tid]=[max(a,b) for a,b in zip(maxima.get(tid,[0,0,0]),values)]
  threads=[dict(tid=tid,cpu_ms=(v[0]-baseline.get(tid,[0,0,0])[0])/1e6,wait_ms=(v[1]-baseline.get(tid,[0,0,0])[1])/1e6) for tid,v in maxima.items()]
  threads.sort(key=lambda x:-x['cpu_ms']);total=sum(t['cpu_ms'] for t in threads)
  kib=lambda s,k:int(s['status'].get(k,'0 kB').split()[0])
  report['memory'].append(dict(revision=row['revision'],wall_ms=row['wall_ms'],cpu_ms=row['cpu_ms'],rss_end_mib=kib(last,'VmRSS')/1024,rss_sample_peak_mib=max(kib(s,'VmRSS') for s in samples)/1024,hwm_mib=kib(last,'VmHWM')/1024,swap_mib=kib(last,'VmSwap')/1024,minor_faults=last['minor_faults']-first['minor_faults'],major_faults=last['major_faults']-first['major_faults'],thread_coverage=total/row['cpu_ms'],largest_thread_share=threads[0]['cpu_ms']/total,runqueue_wait_ms=sum(t['wait_ms'] for t in threads),smaps=last['smaps']))
if (p/'gate/timings.json').exists():report['gate']=read('gate/timings.json')
report['targets']={}
for row in summary:
 if row['phase'] in ['fresh','edit:literal_in_body','edit:body_change']:
  ratio=row['paired']['cpu_ms']['median'];limit=.9 if row['workload']=='game' and row['phase'].startswith('edit:') else 1.05
  report['targets'][row['workload']+':'+row['phase']]={'limit':limit,'ratio':ratio,'met':ratio is not None and ratio<=limit}
(p/'analysis.json').write_text(json.dumps(report,indent=2)+'\n')
for r in summary:
 b,c=r['medians']['baseline'],r['medians']['candidate'];print(r['workload'],r['phase'],r['samples'],'wall',round(b['wall_ms']),round(c['wall_ms']),'cpu',round(b['cpu_ms']),round(c['cpu_ms']),'ratio',r['paired']['cpu_ms']['median'])
print(report['targets'])
