from pathlib import Path
import gzip,json,subprocess,concurrent.futures,shutil,sys,statistics,os
d=Path('build/packet-list').resolve();root=Path.cwd();src=root/'compiler-goose/src';from argparse import ArgumentParser
opts=ArgumentParser();opts.add_argument('--receipt',required=True,type=Path)
ref=json.load(gzip.open(opts.parse_args().receipt))['evidence']
def build(mode):
 name,case=mode;at=d/(name+'-'+case);top=at/'src';top.mkdir(parents=True,exist_ok=True)
 for path in src.iterdir():
  if path.name in ('main.goose','support'):continue
  if not (top/path.name).exists():(top/path.name).symlink_to(path)
 support=top/'support';support.mkdir(exist_ok=True)
 for path in (src/'support').iterdir():
  dest=support/path.name
  if path.name not in ('project_packet.goose','project_packet_codecs.goose'):
   if not dest.exists():dest.symlink_to(path)
   continue
  s=path.read_text() if name=='candidate' else subprocess.check_output(['git','show','944bbfcb:compiler-goose/src/support/'+path.name],text=True)
  if case=='bounds':s=s.replace('let limit:i64=536870912;', 'let limit:i64=16;')
  dest.write_text(s)
 shutil.copyfile(d/(case+'.goose'),top/'main.goose')
 with (at/'build.log').open('w') as log:
  for stage in ref['stages']:
   if stage['stage'] not in ('resolution_views emit','resolution_views link'):continue
   cmd=list(stage['command'])
   cmd[cmd.index('-o')+1]=str(at/'program.c') if stage['stage'].endswith('emit') else str(at/'run')
   if stage['stage'].endswith('emit'):cmd[-1]=str(top/'main.goose')
   else:cmd[cmd.index(next(a for a in cmd if a.endswith('/program.c')))]=str(at/'program.c')
   cmd=['-O2' if a=='-O0' else a for a in cmd]
   subprocess.run(cmd,stdout=log,stderr=subprocess.STDOUT,timeout=45,check=True)
 if case=='bounds':subprocess.run([at/'run'],check=True)
with concurrent.futures.ThreadPoolExecutor(4) as exe:list(exe.map(build,[(n,c) for n in ('release','candidate') for c in ('micro','bounds')]))
rows=[]; checksum=sum(((i*2654435761)&0xffffffff)+(((i*2654435761)&0xffffffff)^0xa55a3cc3) for i in range(262144))
for i in range(20):
 order=['release','candidate']
 if i%2:order.reverse()
 for n in order:
  r=[int(v) for v in subprocess.check_output([d/(n+'-micro')/'run'],text=True,timeout=10).splitlines()]
  assert len(r)==3 and r[-1]==checksum,(r,checksum)
  rows.append(dict(round=i+1,mode=n,writeNs=r[0],readNs=r[1],records=262144,checksum=r[2]))
(d/'micro.json').write_text(json.dumps(rows,indent=2)+'\n')
for k in ['writeNs','readNs']:
 print(k,[(n,round(statistics.median(r[k] for r in rows if r['mode']==n)/262144,2)) for n in order])
