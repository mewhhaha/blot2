#include <stdint.h>
#include <string.h>
#include <stdlib.h>
#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
static _Thread_local uint32_t n[32][2];
void fp_begin(void){ memset(n,0,sizeof n); }
void fp_child(uint32_t tag,_Bool same){if(tag>=32)abort(); n[tag][!same]++;}
void fp_end(uint32_t mod){uint32_t sum=0;char buf[2048];int k=snprintf(buf,sizeof buf,"%u",mod);
for(int i=0;i<32;i++)for(int j=0;j<2;j++) k+=snprintf(buf+k,sizeof(buf)-k," %u",n[i][j]);
buf[k++]='\n';const char*p=getenv("BLOT_CURSOR_LOG");if(!p) return;int fd=open(p,O_WRONLY|O_APPEND|O_CREAT,0600); if(fd<0||write(fd,buf,k)!=k)abort();close(fd);}
