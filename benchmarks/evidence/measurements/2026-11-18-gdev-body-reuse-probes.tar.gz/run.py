from pathlib import Path
from hashlib import sha256
import os,json,subprocess,sys,time
p=Path(__file__).resolve().parent
base=p/'base'
def h(file):return sha256(file.read_bytes()).hexdigest()
def run(name,baseName,editName):
    a=base if baseName=='base' else p/baseName;b=base if editName=='base' else p/editName
    env=dict(os.environ,BLOT_BASE=str(a),BLOT_EDIT=str(b))
    result=p/'results'/name;result.mkdir(parents=True,exist_ok=True)
    for f in result.glob('*.wasm'):f.unlink()
    proc=subprocess.run([p/'probe'],env=dict(env,BLOT_SAVE=str(result)),stdout=subprocess.PIPE,stderr=subprocess.STDOUT,timeout=10)
    (result/'log').write_bytes(proc.stdout)
    counts={}
    for l in proc.stdout.decode(errors='replace').splitlines():
        if not l[:1].isdigit():continue
        k,v=map(int,l.split());counts.setdefault(k,[]).append(v)
    originalWasm=base/'main.wasm' if baseName=='base' else a/'main.wasm'
    row=dict(name=name,base=baseName,edit=editName,dirty=counts.get(11,[]),exit=proc.returncode,counts=counts,old=h(originalWasm),fresh=h(base/'main.wasm' if editName=='base' else b/'main.wasm'))
    for i,key in ((1,'initial'),(2,'reused'),(3,'oracle')):
        f=result/(str(i)+'.wasm')
        if f.exists():row[key]=h(f)
    print(name,len(row["dirty"]),counts.get(4),counts.get(6),row.get('initial')==row['old'],row.get('reused')==row['fresh'],row.get('oracle')==row['fresh'],proc.returncode,flush=True)
    assert proc.returncode==0 and row.get('initial')==row['old'] and row.get('reused')==row['fresh'] and row.get('oracle')==row['fresh'], name
    return row
if __name__=='__main__':
    cases=[(v,'base',v) for v in ('boolean','integer','width','float','call','shape','phase','helper','entry')]
    cases += [('staged-provider','stage-base','stage-edit'),('reverse','boolean','shape'),('reachable-integer-width','shape','value-width'),('reachable-float','phase','value-float'),('undo','boolean','base')]
    out = [run(*c) for c in cases]
    (p/'matrix.json').write_text(json.dumps(out,indent=2)+'\n')
