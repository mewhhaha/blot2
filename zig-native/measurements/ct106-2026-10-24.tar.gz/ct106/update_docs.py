from pathlib import Path
import json
root=Path.cwd()
def between(file,start,end,text):
 p=root/file;s=p.read_text();a=s.index(start);b=s.index(end,a);p.write_text(s[:a]+text+s[b:])
current='''The [CT106 qualification](zig-native/CT106_QUALIFICATION.md) records **19.1%
less first-literal-edit CPU** against CT105 in seven alternating release pairs,
with identical Wasm. First-literal wall median falls from 3.62 to **2.91 s**;
fresh CPU improves 2.4%, body CPU is effectively unchanged and literal-revert
CPU rises 3.5%. These are shared-host observations. Body-edit, two-second and
sub-second targets remain open.

Exact frontend correspondence now checks one module on the first edit instead
of 22. Bounded operation indexes/certificates, lexical links and import scratch
remove repeated work. The report includes 200 distinct edits, allocator/CPU
attribution, exhaustive qualification and rejected experiments. All 86 review
suggestions have a [disposition](COMPILER_CT106_WORK.md); conditional alternatives
and unfinished architectural work are explicit.

'''
between('README.md','The [latest performance changes]','For a smaller development check,',current+'''Use `deno task check:dev --area static-sharing` for Safe/noLLVM development and
`deno task test:compiler` for complete qualification. Compiler identity now
recomputes build configuration after a stale-digest bug was reproduced; normal
compiled-artifact caches remain reusable. The actual LLVM release trace spends
220.88 of 227.76 seconds in emission. The
[experiment tools](scripts/bench/README.md),
[compile measurements](COMPILE_MEASUREMENTS.md),
[compile hills](COMPILE_HILLS.md), [build hills](BUILD_HILLS.md) and
[turnaround measurements](DEVELOPMENT_TURNAROUND.md) keep construction,
verification and application performance separate.

''')
between('zig-native/README.md','[CT105 solver scans','`blotc build ENTRY',current.replace('(zig-native/CT106_QUALIFICATION.md)','(CT106_QUALIFICATION.md)').replace('(COMPILER_CT106_WORK.md)','(../COMPILER_CT106_WORK.md)')+'''The final gate passes 2,564 exhaustive native laws, 1,655 guest checks,
48 smoke checks and 57 tooling checks. Four body principals still require
stronger source-origin correspondence. See the
[development-cycle measurements](../DEVELOPMENT_TURNAROUND.md) and
[measurement tools](../scripts/bench/README.md).

''')
for file,start,end in [('zig-native/STATUS.md','## Solver scans, row certificates and frontend indexes, 24 October 2026','Historical CT103/CT104 checkpoint'),('FINISH_PLAN.md','[CT105 is qualified and installed]','Historical CT103/CT104 checkpoint')]:
 t=current
 if file.startswith('zig-native/'):
  t=t.replace('(zig-native/CT106_QUALIFICATION.md)','(CT106_QUALIFICATION.md)').replace('(COMPILER_CT106_WORK.md)','(../COMPILER_CT106_WORK.md)')
  t='## Exact frontend reuse and bounded inference work, 24 October 2026\n\n'+t
 t+='Full qualification passes 2,564 exhaustive native laws and 1,655 guest checks.\nThe broader completion requirements below remain open; this performance pass\ndoes not close unrelated language or upstream-issue work.\n\n'
 between(file,start,end,t)
between('COMPILE_HILLS.md','[CT105 is qualified]','The comparison and diagnostic sequence below',current+'''Next work is (1) stable origins for the four body-principal declines,
(2) residual query validation/import and the later-literal regression, and
(3) complete-output emission costs. The first-edit failure was incidental
immutable-constructor sharing, now fixed without weakening variable injectivity.
Selected-query key changes did not reduce candidate counts. Finer arena bins
and write coalescing were rejected. The 0.8-second non-inference milestone is
not met; deeper caching remains conditional on exact ownership/provenance.

''')
p=root/'COMPILE_HILLS.md';s=p.read_text().replace("First edit still checks in about 0.9 s; later revisions in 60–70 ms. Attribute allocation callers and cutoff/replay work separately.","CT106 checks one module on the first edit after fixing immutable-constructor sharing; see the current qualification for paired CPU and profiling results.").replace("Four body regions still fail source module/identity checks; literal revert still creates 2,422 regions. Trace equivalent query inputs and the specific changed source subgraphs.","CT106 narrows containing-declaration reads, but all four body regions still fail their own source-position check. Body CPU is unchanged and later-literal CPU rises 3.5%.").replace("Exact producer/catalog indexes leave 60,950 comparisons, then unit 42 declines in graph checking. Record the first graph pair and ownership reason.","Fixed in CT106: equal immutable constructors may differ in sharing; variables remain injective. First-edit checking drops from 22 modules to one.")
p.write_text(s)
for file in ['COMPILE_MEASUREMENTS.md','PERFORMANCE_REVIEW.md']:
 p=root/file;s=p.read_text();first,rest=s.split('\n',1)
 if file=='COMPILE_MEASUREMENTS.md':rest=rest.replace('Latest diagnostic review,','Historical CT105 diagnostic review,',1).replace('Latest qualification,','Historical CT105 qualification,',1)
 else:rest=rest.replace('## Post-CT105 review','## Historical post-CT105 review',1)
 p.write_text(first+'\n\n'+current+rest.lstrip('\n'))
p=root/'DEVELOPMENT_TURNAROUND.md';s=p.read_text().replace('The current static-sharing family selects 52 native laws','The current static-sharing family selects 78 native laws');p.write_text(s)
# Prepend the full paired comparison to the technical record.
p=root/'zig-native/CT106_QUALIFICATION.md';s=p.read_text();mark='## Implementation and correctness boundaries'
r=json.loads((root/'build/bench/ct106/final-pairs/pair-ranges.json').read_text())
t='''## Seven alternating release pairs

Baseline native SHA-256:
`0eadf4bb1a0cc7448f59156091a7287e2456aedfd4b31452197a0a3437a1da78`.
The frozen 554-file gdev/Ink/stdlib manifest is
`d54b0078ea7c8f94fae131e19f7ea46699891d6aba14b61803386595e9704146`:
189 game modules, optimized codegen, four backend workers, a 200-million
inference budget, profiling off and persistent restart cache disabled.
Every fresh/edit/revert result matches the previous strict Wasm pins and the
independent fresh controls. All seven pairs are retained.

| Workload / phase | Baseline wall | CT106 wall | Baseline CPU | CT106 CPU | Paired CPU change |
| --- | ---: | ---: | ---: | ---: | ---: |
'''
for row in r['rows']:
 if row['phase'] in ['population','noop']:continue
 vals=[row[v][k]['median']/1000 for k in ['wall_ms','cpu_ms'] for v in ['baseline','candidate']]
 t+='| '+row['workload']+' / '+row['phase']+' | '+' | '.join(f'{v:.3f} s' for v in vals)+f" | {100*(row['paired_cpu_ratio']-1):+.1f}% |\n"
t+='''
CPU changes are medians of ratios within each pair, not ratios of independent
medians. Process CPU includes workers at 10 ms resolution; no-op percentages
are not useful. Wall time excludes project/process opening. Host load changes
from 8.52 to 5.54 on 16 logical CPUs, with unrelated applications active. Raw
ranges, order and inputs are retained; these are not quiet-host latency bounds.

Fresh-game and devtools regression guards pass. The first-edit improvement is
substantial; the proposed 10% fresh/body and 10% later-literal targets are not
met. Body CPU is effectively unchanged and later-literal CPU regresses 3.5%.
Neither two-second nor sub-second ordinary edits are reached. Work-counter
reductions must not be presented as a larger end-to-end improvement.

Median lifetime peak RSS is 483.44 → 482.04 MiB fresh, 707.82 → 688.28 MiB after
the first literal, and 755.50 → 752.61 MiB after the body edit. Retained peaks
include preceding requests; they are not per-edit live memory.

'''
s=s.replace(mark,t+mark);p.write_text(s)
