import support.project_packet;
import support.native;
import support.error;
import direct.direct;
import direct.emit;
import direct.types;
import direct.writer;
import direct.function;
import check.core;
import body_guard;

type Core = blot_check_core::Module;
extern fn packetSize(version:u32,unit:u32)->i64="body_packet_size";
extern fn packetRead(version:u32,unit:u32,data:u8&,size:i64)="body_packet_read";
extern fn snapshots()->bool="body_snapshot_test";
extern fn childSnapshot()->bool="body_snapshot";
extern fn reply(image:const u8&,size:i64)="body_reply";
extern fn verifyReply(version:u32)="body_verify_reply";
extern fn repetitions()->u32="body_repetitions";
extern fn verifyOutput(version:u32,data:const u8&,size:i64)="body_verify";
extern fn rss()->u64="body_rss";
extern fn referenceFirst()->bool="body_reference_first";
extern fn seal()="body_seal";
extern fn hasReaders(id:u32)->bool="body_affected";
extern fn hasUntrackedReader()->bool="body_decline";
extern fn changedNode(unit:u32,node:u32,count:u32)="body_changed_node";
extern fn inferred(function:u32)->bool="body_inferred";
extern fn stat(key:u32,value:u64)="body_stat";
extern fn save(kind:u32,data:const u8&,size:i64)="body_save";
reusable[] var buffers:u8[>..];
reusable[] var catalog:Core[>..];

fn readCore(owner:blot_project_packet::Owner, bytes:const u8[:], unit:u32, core:Core&)->i64 {
    var reader=blot_project_packet::Reader{bytes,owner};
    var id:u32=0;
    blot_project_packet::get(reader,id);
    blot_project_packet::get(reader,core);
    assert(reader.failure==blot_error::Error.none && id==unit && core.unit==unit);
    return reader.at;
}

fn buildInitial(g:blot_direct_emit::Generator&,entry:u32) {
    var baseline:u8[>..<]=[];
    let before=rss();
    let start=blot_native::clock_ns();
    assert(blot_direct::build(g,entry,baseline)==blot_direct_types::Error.none);
    stat(1,blot_native::clock_ns()-start);
    stat(15,rss()-min(before,rss()));
    save(1,baseline[0],baseline.len);
}

fn referenceImage(updated:const Core[:],entry:u32,fresh:u8[>..<]&) {
    var detail:u8[>..<]=[];
    let referenceStart=blot_native::clock_ns();
    let reference=blot_direct::compile(updated,entry,fresh,detail);
    stat(8,blot_native::clock_ns()-referenceStart);
    assert(!reference.failed);
    save(3,fresh[0],fresh.len);
}
fn trial(old:const Core[:], updated:const Core[:], dirty:const bool[:], entry:u32) {
    var types=blot_direct_types::Types{units:old,..};
    blot_direct_types::init(types);
    var module=blot_direct_writer::Module{..};
    var state=blot_direct_emit::State{..};
    var initial=blot_direct_emit::Generator{types,module,state,old};
    buildInitial(initial,entry);
    let sealStart=blot_native::clock_ns();
    var reason:u32=0;
    for changed,i in dirty {
        if !changed {continue;}
        if !body_guard::same_check_core_Module(old[i],updated[i],false) {reason=2;break;}
        for node,id in old[i].nodes {
            if node.tag==blot_check_core::Tag.constant && node.a!=updated[i].nodes[id].a {
                changedNode(old[i].unit,id as u32,old[i].nodes.len as u32);
            }
        }
    }
    seal();
    if hasUntrackedReader() {reason=1;}
    let sealTime=blot_native::clock_ns()-sealStart;
    if snapshots() {
        assert(reason==0);
        let textStart=module.text.len;let valsStart=state.vals.len;let wordsStart=state.words.len;
        let before=rss();
        let rounds=repetitions();
        assert(rounds>0);
        for k in 0..rounds {
            var version:u32=1;
            if k%2==1 {version=0;}
            let start=blot_native::clock_ns();
            if childSnapshot() {
                var inputs=updated;
                if version==0 {inputs=old;}
                types.units=inputs;
                var child=blot_direct_emit::Generator{types,module,state,inputs};
                for i in 0..state.instances.len {
                    if !hasReaders(i as u32) {continue;}
                    state.instances[i].inferring=inferred(state.instances[i].function);
                    assert(blot_direct_function::emitInstance(child,i as u32)==blot_direct_types::Error.none);
                    state.instances[i].inferring=false;
                }
                var image:u8[>..<]=[];
                blot_direct_writer::assemble(module,image);
                reply(image[0],image.len);
            }
            stat(30,blot_native::clock_ns()-start+sealTime);
            verifyReply(version);
        }
        stat(20,rounds);
        stat(21,(module.text.len-textStart) as u64);
        stat(22,(state.vals.len-valsStart) as u64);
        stat(23,(state.words.len-wordsStart) as u64);
        let after=rss();stat(24,after-min(before,after));
        return;
    }
    var fresh:u8[>..<]=[];
    if referenceFirst() {referenceImage(updated,entry,fresh);}
    let begin=blot_native::clock_ns();
    let previousFunctions=module.functions.len;
    let previousInstances=state.instances.len;
    types.units=updated;
    var revised=blot_direct_emit::Generator{types,module,state,updated};
    var emitted:u32=0;
    if reason==0 {
        for i in 0..previousInstances {
            if !hasReaders(i as u32) {continue;}
            let item=state.instances[i];
            state.instances[i].inferring=inferred(item.function);
            let err=blot_direct_function::emitInstance(revised,i as u32);
            state.instances[i].inferring=false;
            if err!=blot_direct_types::Error.none {reason=3;break;}
            emitted++;
        }
        if previousFunctions!=module.functions.len || previousInstances!=state.instances.len {reason=4;}
    }
    stat(14,reason);
    let generated=blot_native::clock_ns();
    var result:u8[>..<]=[];
    if reason==0 {blot_direct_writer::assemble(module,result);}
    else {
        var detail:u8[>..<]=[];
        let fallback=blot_direct::compile(updated,entry,result,detail);
        assert(!fallback.failed);
    }
    stat(2,generated-begin+sealTime);
    stat(3,blot_native::clock_ns()-generated);
    stat(4,emitted);
    stat(5,previousFunctions as u64);
    stat(6,(module.functions.len-previousFunctions) as u64);
    save(2,result[0],result.len);
    if !referenceFirst() {referenceImage(updated,entry,fresh);}
    stat(9,0);
    if fresh[..]==result[..] {stat(10,1);}
    let cycles=repetitions();
    if cycles==0 {return;}
    assert(reason==0 && fresh[..]==result[..]);
    let textStart=module.text.len;let valsStart=state.vals.len;let wordsStart=state.words.len;
    let firstRss=rss();
    for k in 0..cycles {
        let version=(k%2) as u32;
        var units=old;
        if version==1 {units=updated;}
        types.units=units;
        var next=blot_direct_emit::Generator{types,module,state,units};
        for i in 0..previousInstances {
            if !hasReaders(i as u32) {continue;}
            let fnIndex=state.instances[i].function;
            state.instances[i].inferring=inferred(fnIndex);
            assert(blot_direct_function::emitInstance(next,i as u32)==blot_direct_types::Error.none);
            state.instances[i].inferring=false;
        }
        var image:u8[>..<]=[];
        blot_direct_writer::assemble(module,image);
        verifyOutput(version,image[0],image.len);
    }
    stat(20,cycles);
    stat(21,(module.text.len-textStart) as u64);
    stat(22,(state.vals.len-valsStart) as u64);
    stat(23,(state.words.len-wordsStart) as u64);
    let lastRss=rss();stat(24,lastRss-min(firstRss,lastRss));

}
fn main() {
    let owner,err=blot_project_packet::initOwner();assert(err==blot_error::Error.none);
    let newOwner,newErr=blot_project_packet::initOwner();assert(newErr==blot_error::Error.none);
    let old=catalog.alloc_slice(269);
    let updated=catalog.alloc_slice(269);
    var dirty:bool[269]=[false;269];
    var entry:u32=0;
    for i in 0..269 {
        let unit=(i+1) as u32;
        let n=packetSize(0,unit);let m=packetSize(1,unit);
        let a=buffers.alloc_slice(n);packetRead(0,unit,a[0],n);
        let b=buffers.alloc_slice(m);packetRead(1,unit,b[0],m);
        var core=default<Core>();
        let priorEnd=readCore(owner,a,unit,core);old[i]=core;
        var changed=default<Core>();
        let editedEnd=readCore(newOwner,b,unit,changed);updated[i]=changed;
        if !body_guard::same_check_core_Module(old[i],updated[i],true) {dirty[i]=true;stat(11,unit);}
        for body in core.bodies {
            if body.exported {stat(13,unit);entry=unit;}
        }
        buffers.free_slice(b);buffers.free_slice(a);
    }
    assert(entry!=0);
    trial(old,updated,dirty[..],entry);
}
