from pathlib import Path
import shutil, json, subprocess
d=Path(__file__).resolve().parent
src=d/'probe-src'
shutil.copytree('compiler-goose/src',src,dirs_exist_ok=True)
p=src/'check/types.goose'
s=p.read_text()
s=s.replace('fn add(self_: Store&, value: Node)', '''extern fn markEntry()="ap_enter";
extern fn markExit()="ap_leave";
extern fn markNode(owner:u64,generation:u16,id:u32,tag:u32,a:u32,b:u32,c:u32,closed:u8,word:const u32&,count:u32)="ap_node";
fn add(self_: Store&, value: Node)''')
s=s.replace('return 0,self_.nodes.failure;} return id,','''return 0,self_.nodes.failure;}
    let zero:u32=0; var start:u32=0; var count:u32=0;
    if value.tag==Tag.record { start=value.a; count=value.b*2; }
    if value.tag==Tag.product { start=value.a; count=value.b; }
    if value.tag==Tag.nominal || value.tag==Tag.projection || value.tag==Tag.instance_selection {
        start=value.c+1; count=self_.extra.items[value.c]; if value.tag==Tag.projection { count+=1; }
    }
    if count!=0 {markNode(self_.owner_id,self_.closed_generation,id,tagCode(value.tag),value.a,value.b,value.c,owned.closed_height,self_.extra.items[start],count);}
    else {markNode(self_.owner_id,self_.closed_generation,id,tagCode(value.tag),value.a,value.b,value.c,owned.closed_height,zero,0);}
    return id,''',1)
s=s.replace('let attribution_start = self_.nodes.len;', 'markEntry(); let attribution_start = self_.nodes.len;',1).replace('saturatedAdd(self_.normalization.resolve_nodes_added','markExit(); saturatedAdd(self_.normalization.resolve_nodes_added',1)
p.write_text(s)
p=src/'reuse/persistent_unit.goose'
s=p.read_text().replace('let error=self_.checkModule(unit);','beginProbe(unit);let error=self_.checkModule(unit);endProbe();')
p.write_text(s+'\nextern fn beginProbe(unit:u32)="ap_begin";\nextern fn endProbe()="ap_end";\n')
read=lambda n:json.load(open('compiler-goose/build/stages/'+n+'.json'))['command']
cmd=read('emit-program');cmd[cmd.index('-o')+1]=str(d/'probe.generated.c');cmd[cmd.index('--header')+1]=str(d/'probe.h');cmd[cmd.index('-O2')]='-O0';cmd[-1]=str(src/'main.goose')
subprocess.run(cmd,check=True)
cmd=read('compile-and-link-program');cmd[cmd.index('-O2')]='-O0';cmd[cmd.index(next(a for a in cmd if a.endswith('blot_goose.c')))]=str(d/'probe.generated.c');cmd[-2:-2]=['-fno-omit-frame-pointer','-fno-optimize-sibling-calls','-no-pie',str(d/'probe.c')];cmd[-1]=str(d/'probe');subprocess.run(cmd,check=True)
wrapper=d/'traced'
wrapper.write_text('#!/bin/sh\nBLOT_SHAPES_DIR="$(dirname "$0")"\nexport BLOT_SHAPES_DIR\nexec "$BLOT_SHAPES_DIR/probe" "$@"\n')
wrapper.chmod(0o755)
subprocess.run(['deno','run','-A','scripts/integration/build_gdev.ts','--compiler',wrapper,'--timeout-ms','45000',d/'traced-wasm'],check=True)
