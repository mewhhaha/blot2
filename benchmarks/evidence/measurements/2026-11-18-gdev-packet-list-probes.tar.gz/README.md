# Gdev type-list codec measurements

Use base checkout 944bbfcb94ce0348bce3800a695fb47af48423e8 and the project's
pinned Goose toolchain. Build the unmodified release with deno task
build:compiler and copy its executable. Apply codec.patch and rebuild.
The same 262144 descriptors feed each encoder and decoder. The checksum
consumes both decoded U32 values. A separate native check reduces the
packet cap to 16 bytes to cover partially written final words cheaply.

For the native benchmark, extract the archive into build/packet-list after
applying codec.patch. Run compiler-goose/tools/test_engines.py resolution_views
with the pinned --goose and --stdlib paths from compiler-goose/build. Run
python3 build/packet-list/micro.py --receipt PATH with the gzip receipt it
prints. The runner extracts the old codec from Git, compiles both native
benchmarks at -O2 in independent directories, runs both reduced-limit laws,
and alternates twenty pairs of fresh processes. To run the wire/read laws
on the regular 512 MiB limit, run the packet_list engine test at c0055539.

For end-to-end timings use scripts/integration/time_gdev_parse.ts with the
unmodified and candidate executables in --before and --after. confirm.ts adds Linux getrusage
for the confirmation windows, writing waited child CPU totals to stderr.
Keep it under build/packet-list so that its relative imports resolve.
It uses the same timed session-open to Wasm-return boundaries. Run --rounds
20 twice, swapping the executable order for the second window. Separately
run --edits --rounds 8 and --profile --rounds 4. After integration, run
confirm.ts --rounds 20 and confirm.ts --rounds 10 --edits with both paths. The measurement JSON
identifies the Gdev, Ink and Pen revisions. The two benchmarks use warm
filesystem pages. Fresh means that the compiler process is new.

sample.c is the optional Linux x86-64 signal sampler, rearmed after fork.
It writes three uint32 words per sample to BLOT_PAIR_SAMPLES. Preload its
compiled .so only in the benchmark wrapper for the requested compiler.
Use one file per compiler invocation. The archived raw sample records
contain PID, image kind, relative instruction address and multiplicity.
sample_report.py matches PCs to ELF symbols with nm and the parameter
types in each compiler's emitted C. Its paths refer to this experiment's
scratch layout. The previous function-unification archive has the release
wrapper and complete setup example.
