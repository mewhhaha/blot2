from pathlib import Path
import subprocess,time,json,hashlib,os
root=Path('/home/mewhhaha/src/blot2');base=root/'build/bench/ct103';src=base/'integration-src';work=root/'build/bench/compile-cost-20261023'
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pin=read(base/'integration-release.json');assert pin['exit_code']==0
assert sha(Path(pin['path']))==pin['sha256']
assert subprocess.check_output(['zig','version'],text=True).strip()=='0.17.0'
env=dict(os.environ,ZIG_ANALYZER=str(root/'build/tools/zig-analyzer/zig-analyzer-0.17.0-3-x86_64-linux/bin/zig-analyzer'))
commands=[('integration-gate',['deno','task','test:compiler','--native-shards','4','--phase-seconds','1800','--budget-seconds','2400','--timings-dir',str(base/'integration-gate')]),('integration-screen',['deno','task','bench:compile','--baseline',read(base/'binaries.json')['candidate']['path'],'--candidate',pin['path'],'--snapshot',str(work/'snapshot'),'--manifest',str(work/'manifest.json'),'--hashes',str(base/'wasm.json'),'--workload','game,devtools','--runs','1','--scenarios','trivia,literal_in_body,body_change','--restart-cache','--out',str(base/'integration-screen')])]
(base/'integration-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
status=[]
for name,cmd in commands:
 print('START',name,flush=True);start=time.monotonic()
 with (base/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=src,env=env,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'exit_code':r.returncode,'seconds':time.monotonic()-start};status.append(row)
 (base/'integration-status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 assert sha(Path(pin['path']))==pin['sha256']
