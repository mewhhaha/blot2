#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
static FILE *data;
static uintptr_t callers[256],parents[256];
static unsigned depth,unit;
void ap_begin(uint32_t u){char f[256];snprintf(f,sizeof(f),"%s/trace-%u-%u",getenv("BLOT_SHAPES_DIR"),getpid(),u);data=fopen(f,"wb");if(!data)abort();unit=u;depth=0;}
void ap_end(void){if(depth)abort();fclose(data);data=0;}
__attribute__((noinline)) void ap_enter(void){if(!data)return;if(depth>=256)abort();callers[depth]=(uintptr_t)__builtin_return_address(1);parents[depth]=(uintptr_t)__builtin_return_address(2);depth++;}
void ap_leave(void){if(data)depth--;}
void ap_node(uint64_t owner,uint16_t generation,uint32_t id,uint32_t tag,uint32_t a,uint32_t b,uint32_t c,uint8_t closed,const uint32_t *p,uint32_t count){
if(!data)return;
uint32_t hdr[]={owner,owner>>32,generation,id,tag,a,b,c,closed,depth?callers[0]:0,depth?parents[0]:0,count,depth};fwrite(hdr,sizeof hdr,1,data);if(count)fwrite(p,4,count,data);
}
