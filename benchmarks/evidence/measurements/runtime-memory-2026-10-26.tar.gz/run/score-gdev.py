import hashlib,json,pathlib,statistics,subprocess,time,os
root=pathlib.Path('build/remaining-runtime').resolve()
scenes=['maxed-day-hitting','maxed-piles2000']
expected={
 'maxed-day-hitting':('d71f9918bc2f55a9f8cc3d1d250c319366122d4da7836173218d2b8bf1bd7b72','85cde44663320c262ac815122bf6ca7da43e362ea0c3a513bf5cc7c3ee3c541e'),
 'maxed-piles2000':('144b95cf370f5563d1e21dfb6c9fec6fff54ef05cacdbff431fc1f97b50516d5','11dfe03c50744db4c7059a77351e13d42535df2d046bdf921dda71f2adb19eed')}
pins={name:hashlib.sha256((root/f'gdev-{name}.wasm').read_bytes()).hexdigest() for name in ['baseline','final','cycle-ablation']}
report={'complete':False,'pins':pins,'started':time.time(),'scope':'Three counterbalanced process rounds; frozen input tapes; 600 warmup and 600 measured frames. Raw optimized Wasm, Node/V8 inspector at 1 kHz. guest_ms excludes between-frame host work; process CPU includes startup, restore, all 1200 frames, validation and witness hashing. Timed without competing builds/tests.','rows':[]}
seen={}
for repeat,order in enumerate([['baseline','final','cycle-ablation'],['final','cycle-ablation','baseline'],['cycle-ablation','baseline','final']]):
 for scene in scenes if repeat%2==0 else list(reversed(scenes)):
  for side in order:
   config=root/f'{scene}-{side}-r{repeat}-config.json';out=root/f'{scene}-{side}-r{repeat}.json';usage=root/f'{scene}-{side}-r{repeat}-usage.json'
   with (root/'gdev-scored.log').open('a') as log:
    started=time.monotonic()
    child=subprocess.Popen(['node','../gdev/performance/runtime/profile.mjs',str(config)],stdout=log,stderr=log)
    _,status,resources=os.wait4(child.pid,0)
    child.returncode=os.waitstatus_to_exitcode(status)
    assert child.returncode==0,child.returncode
    usage.write_text(json.dumps({'user_seconds':resources.ru_utime,'system_seconds':resources.ru_stime,'wall_seconds':time.monotonic()-started,'peak_rss_kib':resources.ru_maxrss})+'\n')
   d=json.loads(out.read_text()); assert (d['frame_hash'],d['final_state_hash'])==expected[scene]
   assert len(d['frames'])==600
   k=(scene,side)
   if k in seen: assert d['counters']==seen[k]
   seen[k]=d['counters']
   values=[f['guest_ms'] for f in d['frames']];memory=[f['memory_bytes'] for f in d['frames']]
   assert max(memory[-100:])-min(memory[-100:])<=65536
   row={'scene':scene,'side':side,'round':repeat,'engine':d['engine'],'frame_hash':d['frame_hash'],'final_state_hash':d['final_state_hash'],'counters':d['counters'],'samples_ms':values,'mean_ms':statistics.mean(values),'median_ms':statistics.median(values),'p95_ms':sorted(values)[569],'p99_ms':sorted(values)[593],'memory_min':min(memory),'memory_max':max(memory),'last_100_growth':max(memory[-100:])-min(memory[-100:]),'process':json.loads(usage.read_text())}
   report['rows'].append(row);(root/'gdev-scores.json').write_text(json.dumps(report,indent=2)+'\n');print(scene,side,repeat,round(row['mean_ms'],3),row['process'],flush=True)
for name,pin in pins.items():assert hashlib.sha256((root/f'gdev-{name}.wasm').read_bytes()).hexdigest()==pin
report['complete']=True;report['finished']=time.time();(root/'gdev-scores.json').write_text(json.dumps(report,indent=2)+'\n')
