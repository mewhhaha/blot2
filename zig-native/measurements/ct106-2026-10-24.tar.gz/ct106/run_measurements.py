import subprocess, json, time, os, sys
from pathlib import Path
root=Path.cwd(); out=root/'build/bench/ct106'
env=os.environ.copy(); env['TMPDIR']=str(out/'tmp'); env['ZIG_ANALYZER']=str(root/'build/bench/ct105/tools/bin/zig-analyzer')
base=str(out/'baseline-blotc'); final=str(out/'identity-heap-blotc')
common=['--snapshot','build/bench/compile-cost-20261023/snapshot','--manifest','build/bench/compile-cost-20261023/manifest.json','--hashes','build/bench/ct103/wasm.json']
def bench(name,old,new,extra):
 return (name,['deno','task','bench:compile','--baseline',old,'--candidate',new,*common,'--runs','3',*extra,'--out',str(out/name)])
game=['--workload','game,devtools','--scenarios','literal_in_body,body_change','--guard-cpu']
jobs=[bench('profile-pairs',final,final,game+['--candidate-profile']),bench('semantic-2',final,final,game+['--candidate-semantic-workers','2']),bench('semantic-4',final,final,game+['--candidate-semantic-workers','4']),bench('native-cpu-pairs',str(out/'final-blotc'),str(out/'qualification-work/blot2/zig-native/zig-out-ct106-native-cpu/bin/blotc'),game),bench('synthetic-pairs',base,final,['--workload','synthetic'])]
for name,binary,affinity in [('pmu-base-1',base,None),('pmu-final-1',final,None),('pmu-final-2',final,None),('pmu-base-2',base,None),('pmu-physical-1',final,'0-4'),('pmu-smt-1',final,'0,1,2,8,9'),('pmu-smt-2',final,'0,1,2,8,9'),('pmu-physical-2',final,'0-4')]:
 command=['deno','run','-A','scripts/bench/process_pmu.ts','--binary',binary,*common,'--out',str(out/name)]
 if affinity: command=['taskset','-c',affinity,*command]
 jobs.append((name,command))
jobs.append(('development-cycles',['python3','scripts/bench/development_cycles.py','--out',str(out/'development-cycles')]))
start=sys.argv[1] if len(sys.argv)>1 else jobs[0][0]
active=False
for name,command in jobs:
 if name==start: active=True
 if not active:continue
 record={'name':name,'command':command,'started_at':time.time(),'load_before':os.getloadavg()}
 try:record['frequency_before_khz']={str(cpu):Path(f'/sys/devices/system/cpu/cpu{cpu}/cpufreq/scaling_cur_freq').read_text().strip() for cpu in range(os.cpu_count())}
 except OSError:pass
 print('Starting '+name,flush=True)
 with (out/(name+'.log')).open('wb') as log: result=subprocess.run(command,cwd=root,env=env,stdout=log,stderr=subprocess.STDOUT)
 record.update(exit_code=result.returncode,wall_seconds=time.time()-record['started_at'],load_after=os.getloadavg())
 with (out/'measurement-jobs.jsonl').open('a') as log:log.write(json.dumps(record)+'\n')
 print(json.dumps(record),flush=True)
 if result.returncode:
  evidence=out/name/'results.json'
  measured=json.loads(evidence.read_text()) if evidence.exists() else {}
  problems=measured.get('unexpected_problems',[])
  if problems and all(p.startswith('CPU guard: game fresh CPU regressed ') for p in problems):
   print('Completed negative CPU screen; retaining failure and continuing independent experiments',flush=True)
  else:sys.exit(result.returncode)
