"""Attribute complete CPU sampling intervals to project checking, not backend inference."""
from collections import Counter
import json
from pathlib import Path
import sys

root = Path(sys.argv[1])
windows = [b for b in map(json.loads, (root / 'builds.jsonl').read_text().splitlines()) if b['sampled']]
counters = {key: Counter() for key in ('inclusive', 'self', 'owner', 'alloc_owner')}
previous = {}
total = all_cpu = alloc_cpu = truncated = boundary = 0
for row in map(json.loads, (root / 'samples.jsonl').read_text().splitlines()):
    run, end = row['run'], row['wall_ns'] / 1e6
    start = previous.get(run)
    previous[run] = end
    if start is None or not any(b['run'] == run and b['started_ms'] <= start <= end <= b['finished_ms'] for b in windows):
        boundary += 1
        continue
    assert len(row['st']) == len(row['cpu_ns'])
    for stack, weight in zip(row['st'], row['cpu_ns']):
        if weight is None or weight <= 0:
            continue
        all_cpu += weight
        if not any('reuse.project_check.' in frame[0] for frame in stack):
            continue
        total += weight
        if len(stack) >= row.get('frame_limit', 4096):
            truncated += weight
        counters['self'][stack[0][0]] += weight
        owner = next((f for f in stack if '/zig-native/src/' in f[1]), None)
        if owner:
            counters['owner'][f'{owner[0]}:{owner[2]}'] += weight
        for name in set(f[0] for f in stack):
            counters['inclusive'][name] += weight
        alloc = next((i for i, f in enumerate(stack) if 'phase_profile.CountingAllocator.' in f[0] or 'runtime.session_heap.' in f[0]), None)
        if alloc is not None:
            alloc_cpu += weight
            caller = next((f for f in stack[alloc + 1:] if '/zig-native/src/' in f[1] and 'phase_profile.' not in f[0] and 'runtime.session_heap.' not in f[0]), None)
            if caller:
                counters['alloc_owner'][f'{caller[0]}:{caller[2]}'] += weight

assert total > 0
report = {
    'scope': 'CPU-weighted samples within complete measured intervals, restricted to stacks containing reuse.project_check. Inclusive rows overlap; profiler timing is diagnostic.',
    'builds': len(windows), 'boundary_intervals_discarded': boundary,
    'all_covered_cpu_ms': all_cpu / 1e6, 'project_check_cpu_ms': total / 1e6,
    'project_check_percent': 100 * total / all_cpu,
    'project_check_truncated_ms': truncated / 1e6,
    'allocator_inclusive_percent': 100 * alloc_cpu / total,
}
for key, counter in counters.items():
    report[key] = [{'name': name, 'cpu_ms': weight / 1e6, 'percent_of_project_check': 100 * weight / total}
                   for name, weight in counter.most_common(100)]
(root / 'frontend-cpu-report.json').write_text(json.dumps(report, indent=2) + '\n')
