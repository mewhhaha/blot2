from pathlib import Path
import subprocess,shutil,json,hashlib
root=Path('/home/mewhhaha/src/blot2');stage=root/'build/install/ct109';bench=root/'build/bench/ct109'
read=lambda p:json.loads(p.read_text())
assert read(bench/'qualification-work/blot2/build/bench/ct109-final-gate-3/timings.json')['success']
assert read(bench/'final-pairs/results.json')['success']
pins=read(bench/'final-pins.json')
assert hashlib.sha256((bench/'qualification-work/blot2/zig-native/zig-out/bin/blotc').read_bytes()).hexdigest()==pins['qualified_native_sha256']
assert hashlib.sha256((bench/'qualification-work/blot2/zig-native/zig-out/compiler-identity.bin').read_bytes()).hexdigest()==pins['compiler_identity_sha256']
assert read(bench/'memory-final/complete.json')['success']
assert read(bench/'review-execution.json')['success']
assert hashlib.sha256((bench/'candidate-10-blotc').read_bytes()).hexdigest()==pins['qualified_native_sha256']
for name,digest in pins['qualified_files'].items():assert hashlib.sha256((root/name).read_bytes()).hexdigest()==digest,name
for source,target in [(bench/'candidate-10-blotc',root/'zig-native/zig-out/bin/blotc'),(bench/'qualification-work/blot2/zig-native/zig-out/compiler-identity.bin',root/'zig-native/zig-out/compiler-identity.bin')]:shutil.copy2(source,target)
shutil.copy2(root/'zig-native/zig-out/bin/blotc',stage/'blotc')
commands=[['deno','task','package:pack'],['deno','compile','--allow-read','--allow-write','--allow-run','--allow-env=HOME,XDG_CACHE_HOME,BPM_CACHE_DIR','--include','generated/wasm','--include','generated/compiler','--include','std','--include','compiler/guide.md','--output',str(stage/'blot'),'compiler/installed_cli.ts']]
for i,cmd in enumerate(commands):
 with (stage/f'package-{i}.log').open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(cmd,r.returncode)
r=subprocess.run(['python3',str(stage/'smoke.py')],cwd=root)
raise SystemExit(r.returncode)
