#include <stdio.h>
#include <stdint.h>
void pair_test_word(uint32_t n){printf("%u ",n);}
void pair_test_end(void){putchar(10);}
