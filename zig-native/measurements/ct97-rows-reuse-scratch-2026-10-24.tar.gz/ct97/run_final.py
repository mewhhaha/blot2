import pathlib,subprocess,time,json,hashlib
root=pathlib.Path('/home/mewhhaha/src/blot2'); out=root/'build/bench/ct97'; src=out/'final-src'
candidate=src/'zig-native/zig-out/bin/blotc'; baseline=root/'build/bench/ct96-20261023/candidate/blotc'
work=root/'build/bench/compile-cost-20261023'
common=['deno','task','bench:compile','--baseline',str(baseline),'--candidate',str(candidate),'--snapshot',str(work/'snapshot'),'--manifest',str(work/'manifest.json'),'--hashes',str(work/'wasm.json')]
commands=[
 ('final-cold',common+['--workload','game,devtools','--runs','7','--no-retained','--guard-cpu','--out',str(out/'final-cold')]),
 ('final-retained',common+['--workload','game','--runs','7','--scenarios','trivia,literal_in_body,body_change','--restart-cache','--out',str(out/'final-retained')]),
 ('final-phases',common+['--workload','game,devtools','--runs','3','--no-retained','--profile','--out',str(out/'final-phases')]),
]
(out/'final-measurement-commands.json').write_text(json.dumps(commands,indent=2)+'\n')
(out/'final-binaries.json').write_text(json.dumps({k:{'path':str(v),'sha256':hashlib.sha256(v.read_bytes()).hexdigest()} for k,v in [('baseline',baseline),('candidate',candidate)]},indent=2)+'\n')
results=[]
for name,cmd in commands:
 print('START',name,flush=True); start=time.monotonic()
 with (out/(name+'.log')).open('w') as f: p=subprocess.run(cmd,cwd=src,stdout=f,stderr=subprocess.STDOUT)
 row={'name':name,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start}; results.append(row)
 (out/'final-measurements-status.json').write_text(json.dumps(results,indent=2)+'\n'); print(json.dumps(row),flush=True)
 if p.returncode: raise SystemExit(p.returncode)
print('START native screen',flush=True)
raise SystemExit(subprocess.run(['python3',str(out/'native_screen.py')],cwd=src).returncode)
