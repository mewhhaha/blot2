import {createZigProjectCompiler} from '../../../compiler/zig_project_client.ts';
import {verifySnapshotFiles} from '../../../scripts/bench/snapshot.ts';
import {gdevWorkloads,sessionOptions,editedSources} from '../../../scripts/bench/gdev.ts';
const root='/home/mewhhaha/src/blot2';
const [w]=await gdevWorkloads(root,root+'/build/bench/compile-cost-20261023/snapshot');
const manifest=JSON.parse(await Deno.readTextFile(root+'/build/bench/compile-cost-20261023/manifest.json'));
await verifySnapshotFiles(w.root,manifest);
let populationHash='';
const paths=JSON.parse(await Deno.readTextFile(root+'/build/bench/ct105/final-pins.json'));
const sessions = new Map<string,Awaited<ReturnType<typeof createZigProjectCompiler>>>();
const hz=Number(new TextDecoder().decode((await new Deno.Command('getconf',{args:['CLK_TCK'],stdout:'piped'}).output()).stdout));
async function cpu(pid:number){const s=await Deno.readTextFile(`/proc/${pid}/stat`);const a=s.slice(s.lastIndexOf(') ')+2).trim().split(/\s+/);return (Number(a[11])+Number(a[12]))*1000/hz;}
const digest=async(b:Uint8Array<ArrayBuffer>)=>Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b)),v=>v.toString(16).padStart(2,'0')).join('');
const out=root+'/build/bench/ct105/warm-series.jsonl';
await Deno.writeTextFile(out,'');
const original=w.scenarios.find(s=>s.name==='literal_in_body')!;
const body=w.scenarios.find(s=>s.name==='body_change')!;
const bodyEdits=['const walk_material = fn phase => first_material + from (ceil phase)','const walk_material = fn phase => first_material + from (@f32.floor phase)','const walk_material = fn phase => first_material + from (@f32.abs phase)'];
try{
 for(const variant of ['baseline','candidate']) sessions.set(variant,await createZigProjectCompiler({...sessionOptions(paths[variant].path,w),codegenWorkers:4,cacheDirectory:false,profileBackend:true}));
 for(let revision=0;revision<=7;revision++){
  const sources=revision===0||revision===7?{}:revision<=3?await editedSources(w,{...original,replacements:original.replacements.map(r=>({...r,replace:r.replace.replace('0.1876',`0.${1875+revision}`)}))}):await editedSources(w,{...body,replacements:body.replacements.map(r=>({...r,replace:bodyEdits[revision-4]}))});
  const hashes:string[]=[];
  for(const variant of (revision%2?['candidate','baseline']:['baseline','candidate'])){
   const c=sessions.get(variant)!;const before=await cpu(c.pid);const t=performance.now();const r=await c.build({sources});const wall_ms=performance.now()-t;const cpu_ms=(await cpu(c.pid))-before;
   if(!r.success)throw Error(JSON.stringify(r.diagnostics));
   const wasm_sha256=await digest(r.bytes);hashes.push(wasm_sha256);
   await Deno.writeTextFile(out,JSON.stringify({variant,revision,wall_ms,cpu_ms,wasm_sha256,stats:r.stats})+'\n',{append:true});console.log(variant,revision,wall_ms,cpu_ms);
  }
  if(hashes[0]!==hashes[1])throw Error('Paired output mismatch');
  if(revision===0)populationHash=hashes[0];
  if(revision===7&&hashes[0]!==populationHash)throw Error('Revert output mismatch');
  if(revision>0&&revision<7){
   const fresh=await createZigProjectCompiler({...sessionOptions(paths.candidate.path,w),codegenWorkers:4,cacheDirectory:false});
   try{const r=await fresh.build({sources});if(!r.success||await digest(r.bytes)!==hashes[0])throw Error('Fresh output mismatch');}finally{await fresh.dispose();}
  }
 }
 await verifySnapshotFiles(w.root,manifest);
 await Deno.writeTextFile(root+'/build/bench/ct105/warm-series-success.json',JSON.stringify({success:true,profiled:true,distinct_literal_edits:3,distinct_body_edits:3,paired_output_equal:true,fresh_edited_equal:true})+'\n');
}finally{for(const c of sessions.values())await c.dispose();}
