"""Audit and package CT115 diagnostics; run from the repository root."""
from pathlib import Path
import difflib
import hashlib
import json
import shutil
import tarfile

root = Path.cwd()
work = root / "build/bench/ct115"
baseline = root / "build/bench/ct114/qualification-work/blot2"
diagnostic = work / "diagnostic-work/blot2"
read = lambda p: json.loads(p.read_text())
sha = lambda p: hashlib.sha256(p.read_bytes()).hexdigest()
write = lambda p, data: p.write_text(json.dumps(data, indent=2) + "\n")
pins = read(work / "baseline-source-pins.json")
changed = read(work / "changed-files.json")
assert all(sha(baseline / n) == h for n, h in pins["source_files"].items())
main_deltas = [n for n, h in pins["source_files"].items() if sha(root / n) != h]
assert set(main_deltas) == set(pins["excluded_concurrent_files"]), main_deltas
assert set(n for n, h in pins["source_files"].items() if sha(diagnostic / n) != h) == set(changed)

for n in changed:
    target = work / "topology-trace-source" / n
    target.parent.mkdir(parents=True, exist_ok=True)
    shutil.copy2(diagnostic / n, target)

for label in ("release", "topology"):
    source_files = dict(pins["source_files"])
    source_files.update({n: sha(work / f"{label}-trace-source" / n) for n in changed})
    write(work / f"{label}-source-pins.json", {
        "source_head": pins["source_head"], "source_files": source_files,
        "changed_files": changed,
        "scope": "CT114 frozen source with observational tracing only. Separate source pins for each diagnostic binary."
    })

def patch(left, right, name):
    text = "".join("".join(difflib.unified_diff(
        (left / n).read_text().splitlines(keepends=True),
        (right / n).read_text().splitlines(keepends=True),
        fromfile=f"a/{n}", tofile=f"b/{n}")) for n in changed)
    (work / name).write_text(text)

patch(baseline, work / "release-trace-source", "release-trace.patch")
patch(work / "release-trace-source", work / "topology-trace-source", "topology-delta.patch")

builds = {}
for label, prefix, profiles in (("release", "zig-out", "profiles"), ("topology", "zig-out-dev", "topology")):
    binary = diagnostic / "zig-native" / prefix / "bin/blotc"
    identity = diagnostic / "zig-native" / prefix / "compiler-identity.bin"
    complete = read(work / profiles / "complete.json")
    assert complete["success"] and complete["inputs_unchanged"]
    assert sha(binary) == complete["compiler_sha256"]
    builds[label] = {"compiler_sha256": sha(binary), "identity_sha256": sha(identity),
                     "source_pins_sha256": sha(work / f"{label}-source-pins.json")}

manifest = root / "build/bench/compile-cost-20261023/manifest.json"
snapshot = manifest.parent / "snapshot"
wasm = root / "build/bench/ct103/wasm.json"
wasm_pins = read(wasm)
assert sha(manifest) == wasm_pins["manifest"]
assert all(sha(snapshot / n) == h for n, h in read(manifest).items())
shutil.copy2(manifest, work / "workload-manifest.json")
shutil.copy2(wasm, work / "strict-wasm-pins.json")
outputs = []
for directory in ("profiles", "topology"):
    for p in sorted((work / directory).glob("*-*.json")):
        sample = read(p)
        phase = sample["phase"]
        key = "game" if phase in ("fresh", "literal_revert", "body_revert") else f"game @ {phase}"
        assert sample["hash"] == wasm_pins["entries"][key]
        profile = sample["stats"]["phaseProfile"]
        assert profile["module_trace_overflow"] == 0
        assert all(not r["truncated"] for r in profile["module_trace"])
        outputs.append({"file": str(p.relative_to(work)), "wasm_sha256": sample["hash"]})
assert len(outputs) == 8

# Independently check the serialized schedules, including worker capacity.
topology = read(work / "topology/0-fresh.json")["stats"]["phaseProfile"]["module_trace"]
names = {r["name_key"]: r["filename"] for r in topology}
deps = {r["filename"]: [names[k] for k in r["dependencies"]] for r in topology}
assert len(names) == len(deps) == 189
assert sum(map(len, deps.values())) == 1604
analysis = read(work / "analysis.json")
schedules_checked = 0
for models in analysis["models"].values():
    for model in models:
        jobs = {j["unit"]: j for j in model["schedule"]}
        assert set(jobs) == set(deps)
        assert all(jobs[d]["end_ns"] <= j["start_ns"] for n, j in jobs.items() for d in deps[n])
        events = sorted([(j["start_ns"], 1) for j in jobs.values()] + [(j["end_ns"], -1) for j in jobs.values()])
        active = 0
        for _, delta in events:
            active += delta
            assert 0 <= active <= model["workers"]
        assert active == 0
        assert abs(max(j["end_ns"] for j in jobs.values()) / 1e6 - model["makespan_ms"]) < 1e-6
        if model["workers"] == 1:
            assert abs(model["makespan_ms"] - model["total_work_ms"]) < 1e-6
        if model["workers"] >= len(jobs):
            assert abs(model["makespan_ms"] - model["critical_path_ms"]) < 1e-6
        schedules_checked += 1

logs = work / "logs"
logs.mkdir(exist_ok=True)
for p in Path("/tmp").glob("blot-ct115-*.log"):
    shutil.copy2(p, logs / p.name)
(logs / "README.txt").write_text(
    "blot-ct115-dev-build.log is an initial main-worktree Safe/noLLVM build, not the diagnostic build.\n"
    "diagnostic-dev/release-build logs belong to the isolated observational compiler.\n"
    "topology-build uses Safe/noLLVM; topology clocks are excluded from release cost models.\n"
)
write(work / "evidence-audit.json", {
    "success": True, "baseline_files": len(pins["source_files"]),
    "main_source_deviations": main_deltas, "builds": builds,
    "workload_files": len(read(manifest)), "workload_manifest_sha256": sha(manifest),
    "outputs": outputs, "schedules_checked": schedules_checked,
    "scope": "Observational instrumentation, exact output controls and scheduling-model audit; not qualification of an optimized or parallel compiler."
})

archive = root / "zig-native/measurements/ct115-big-levers-2026-10-25.tar.gz"
files = sorted(p for p in work.rglob("*") if p.is_file()
               and "diagnostic-work" not in p.relative_to(work).parts
               and p.name not in ("archive-result.json", "evidence-manifest.json")
               and "__pycache__" not in p.parts)
write(work / "evidence-manifest.json", {str(p.relative_to(work)): sha(p) for p in files})
files.append(work / "evidence-manifest.json")
with tarfile.open(archive, "w:gz") as tar:
    for p in files:
        tar.add(p, arcname="ct115/" + str(p.relative_to(work)), recursive=False)
with tarfile.open(archive, "r:gz") as tar:
    members = tar.getmembers()
    assert len(members) == len(files)
    for p in files:
        member = tar.extractfile("ct115/" + str(p.relative_to(work)))
        assert hashlib.sha256(member.read()).hexdigest() == sha(p)
result = {"archive": str(archive.relative_to(root)), "sha256": sha(archive),
          "bytes": archive.stat().st_size, "members": len(files)}
write(work / "archive-result.json", result)
print(json.dumps(result, indent=2))
