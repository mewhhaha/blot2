import { createZigProjectCompiler } from '../../../compiler/zig_project_client.ts';
import { verifySnapshotFiles } from '../../../scripts/bench/snapshot.ts';
import { gdevWorkloads, sessionOptions, editedSources } from '../../../scripts/bench/gdev.ts';

const root = '/home/mewhhaha/src/blot2';
const out = `${root}/build/bench/ct105`;
const [w] = await gdevWorkloads(root, `${root}/build/bench/compile-cost-20261023/snapshot`);
const manifest = JSON.parse(await Deno.readTextFile(`${root}/build/bench/compile-cost-20261023/manifest.json`));
await verifySnapshotFiles(w.root, manifest);
const expected = (await Deno.readTextFile(`${root}/build/bench/ct103/warm-series.jsonl`)).trim().split('\n').map(l=>JSON.parse(l)).filter(r => r.variant === 'candidate');
const hz = Number(new TextDecoder().decode((await new Deno.Command('getconf', {args:['CLK_TCK'],stdout:'piped'}).output()).stdout));
const variant = Deno.args[0];
if (!['baseline','candidate'].includes(variant)) throw Error('Expected baseline or candidate');
const pins = JSON.parse(await Deno.readTextFile(`${out}/final-pins.json`));
const compiler = await createZigProjectCompiler({...sessionOptions(pins[variant].path,w),codegenWorkers:4,cacheDirectory:false,profileBackend:false});
const digest = async (b:Uint8Array<ArrayBuffer>) => Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',b)), v=>v.toString(16).padStart(2,'0')).join('');
const original = w.scenarios.find(s=>s.name==='literal_in_body')!;
const body = w.scenarios.find(s=>s.name==='body_change')!;
const bodyEdits = ['const walk_material = fn phase => first_material + from (ceil phase)','const walk_material = fn phase => first_material + from (@f32.floor phase)','const walk_material = fn phase => first_material + from (@f32.abs phase)'];
let monitor:Deno.ChildProcess|undefined;
let send:((s:string)=>Promise<void>)|undefined;
let receive:(()=>Promise<any>)|undefined;
let lastCounters:any;
await Deno.writeTextFile(`${out}/pmu-${variant}.jsonl`,'');
try {
  for(let revision=0;revision<=4;revision++) {
    const sources=revision===0||revision===7?{}:revision<=3?await editedSources(w,{...original,replacements:original.replacements.map(r=>({...r,replace:r.replace.replace('0.1876',`0.${1875+revision}`)}))}):await editedSources(w,{...body,replacements:body.replacements.map(r=>({...r,replace:bodyEdits[revision-4]}))});
    if(send){await send('start');await receive!();}
    const before=await Deno.readTextFile(`/proc/${compiler.pid}/stat`);
    const start=performance.now();
    const r=await compiler.build({sources});
    const wall_ms=performance.now()-start;
    const after=await Deno.readTextFile(`/proc/${compiler.pid}/stat`);
    if(send){await send('stop');lastCounters=await receive!();}
    const ticks=(s:string)=>s.slice(s.lastIndexOf(') ')+2).trim().split(/\s+/).map(Number);
    const bt=ticks(before),at=ticks(after);
    const user_ms=(at[11]-bt[11])*1000/hz,system_ms=(at[12]-bt[12])*1000/hz;
    if(!r.success)throw Error(JSON.stringify(r.diagnostics));
    const wasm_sha256=await digest(r.bytes);
    if(wasm_sha256!==expected.find(e=>e.revision===revision)?.wasm_sha256)throw Error(`Output mismatch revision ${revision}`);
    const record={revision,pid:compiler.pid,wall_ms,user_ms,system_ms,wasm_sha256,stats:r.stats,counters:lastCounters};
    await Deno.writeTextFile(`${out}/pmu-${variant}.jsonl`,JSON.stringify(record)+'\n',{append:true});
    console.log(JSON.stringify({revision,wall_ms,user_ms,system_ms}));
    if(revision===0){
      const tids: {tid:number,cpu:number}[]=[];
      for await(const entry of Deno.readDir(`/proc/${compiler.pid}/task`)){
        const cpu=Number((await Deno.readTextFile(`/proc/${compiler.pid}/task/${entry.name}/schedstat`)).split(' ')[0]);
        tids.push({tid:Number(entry.name),cpu});
      }
      tids.sort((a,b)=>b.cpu-a.cpu);
      monitor=new Deno.Command('python3',{args:[`${out}/pmu.py`,String(tids[0].tid)],stdin:'piped',stdout:'piped',stderr:'inherit'}).spawn();
      const writer=monitor.stdin.getWriter(),reader=monitor.stdout.getReader();let buffer='';
      send=async(s:string)=>{await writer.write(new TextEncoder().encode(s+'\n'));};
      receive=async()=>{while(!buffer.includes('\n')){const r=await reader.read();if(r.done)throw Error('Counter process closed');buffer+=new TextDecoder().decode(r.value);}const i=buffer.indexOf('\n');const r=JSON.parse(buffer.slice(0,i));buffer=buffer.slice(i+1);return r;};
      const ready=await receive();
      await Deno.writeTextFile(`${out}/pmu-${variant}-scope.json`,JSON.stringify({...ready,threads_at_attach:tids})+'\n');
    }

  }
  await verifySnapshotFiles(w.root,manifest);
  await Deno.writeTextFile(`${out}/pmu-${variant}-success.json`,JSON.stringify({success:true,revisions:5,profile_backend:false,inputs_unchanged:true,all_outputs_match_previous_fresh_controls:true})+'\n');
} finally { if(send)await send('quit');if(monitor)await monitor.status;await compiler.dispose(); }
