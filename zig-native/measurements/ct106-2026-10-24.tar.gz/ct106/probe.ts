import { createZigProjectCompiler } from '../../../compiler/zig_project_client.ts';
import { gdevWorkloads, sessionOptions, editedSources } from '../../../scripts/bench/gdev.ts';
const root='/home/mewhhaha/src/blot2';
const out=`${root}/build/bench/ct106`;
const [w]=await gdevWorkloads(root,`${root}/build/bench/compile-cost-20261023/snapshot`);
const binary=Deno.args[0]??`${root}/zig-native/zig-out-dev/bin/blotc`;
const name=Deno.args[1]??'diagnostics';
const c=await createZigProjectCompiler({...sessionOptions(binary,w),codegenWorkers:4,cacheDirectory:false,profileBackend:true});
const expected=['671b11e1a1fd909148cc0d71fd1abcbab24d7c008d1e94451fabe666cf201814','fed3453daf266d8f2c489e466f62e7b1c6b0a4767af86227ab9ead045f4da52d','8392e3288c1d28e2839ad36efa12343098f08983d71d7ffc19ada29ae88d93ff'];
await Deno.writeTextFile(`${out}/${name}.jsonl`,'');
try {
 for(const [i,scenario] of ['population','literal_in_body','body_change'].entries()) {
  const sources=i===0?{}:await editedSources(w,w.scenarios.find(s=>s.name===scenario)!);
  const start=performance.now();const r=await c.build({sources});
  if(!r.success)throw Error(JSON.stringify(r.diagnostics));
  const sha=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',r.bytes)),v=>v.toString(16).padStart(2,'0')).join('');
  if(sha!==expected[i])throw Error(`Output mismatch ${scenario}: ${sha}`);
  const record={scenario,wall_ms:performance.now()-start,wasm_sha256:sha,stats:r.stats};
  await Deno.writeTextFile(`${out}/${name}.jsonl`,JSON.stringify(record)+'\n',{append:true});
  console.log(JSON.stringify({scenario,wall_ms:record.wall_ms,attemptStats:r.stats.attemptStats,queries:r.stats.selectedQueries}));
 }
} finally {await c.dispose();}
