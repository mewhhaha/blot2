import support.project_packet;
import support.native;
import check.core;
import check.types;
import reuse.principal_interface;
import support.error;
extern fn packetSize(unit:u32,kind:u32)->i64="cp_size";
extern fn packetLoad(unit:u32,kind:u32,b:u8&,n:i64)="cp_load";
extern fn note(key:u32,size:i64,ns:u64)="cp_hit";
extern fn finish()="cp_end";
reusable[] var inputs:u8[>..];
fn profile<T>(data:const u8[:],seed:T,unit:u32,kind:u32) {
    var owner,error=blot_project_packet::initOwner();assert(error==blot_error::Error.none);
    var reader=blot_project_packet::Reader{data,owner};
    if kind==2 {var id:u32=0;blot_project_packet::get(reader,id);assert(id==unit);}
    let start=reader.at;
    var value=seed;
    let readStart=blot_native::clock_ns();
    blot_project_packet::get(reader,value);
    let readTime=blot_native::clock_ns()-readStart;
    assert(reader.failure==blot_error::Error.none && value.unit==unit);
    note(1800+kind,reader.at-start,readTime);
    var out:u8[>..<]=[];
    var writer=blot_project_packet::Writer{out};
    let writeStart=blot_native::clock_ns();
    blot_project_packet::put(writer,value);
    let writeTime=blot_native::clock_ns()-writeStart;
    assert(writer.failure==blot_error::Error.none);
    assert(out[..]==data[start..reader.at]);
    note(1802+kind,out.len,writeTime);
    inspect(value);
    owner.deinit();
}
fn inspect(v:const blot_check_core::Module&) {}
fn inspect(v:const blot_reuse_principal_interface::Interface&) {
    for b in v.bindings {
        var vacant=default<blot_reuse_principal_interface::Binding>();
        vacant.private=b.private;vacant.kind=b.kind;
        note(1810,1,0);
        if b==vacant {note(1811,1,0);}
        if b.scheme==default<blot_check_types::Scheme>() {note(1812,1,0);}
    }
}
fn main() {
    for i in 1..270 {
        let unit=i as u32;
        for k in 1..3 {
            let kind=k as u32;let n=packetSize(unit,kind);assert(n>0);
            let bytes=inputs.alloc_slice(n);packetLoad(unit,kind,bytes[0],n);
            if kind==1 {profile(bytes,default<blot_reuse_principal_interface::Interface>(),unit,kind);}
            else {profile(bytes,default<blot_check_core::Module>(),unit,kind);}
            inputs.free_slice(bytes);
        }
    }
    finish();
}
