import gdb
import json
import os
import time
from pathlib import Path

root = Path(os.environ['PROBE_OUT'])
for command in ('set pagination off', 'set confirm off', 'set debuginfod enabled off'):
    gdb.execute(command)
gdb.execute('file ' + os.environ['PROBE_BINARY'])
gdb.execute('attach ' + os.environ['PROBE_PID'])
gdb.execute('handle SIGUSR1 nopass stop print')

class Probe(gdb.Breakpoint):
    def stop(self):
        record = {'frame': gdb.newest_frame().name()}
        for name in ('left', 'right'):
            try:
                graph = gdb.newest_frame().read_var(name).dereference()
                record[name] = {field: int(graph[field]['len']) for field in ('nodes', 'rows')}
                record[name]['row_variable_count'] = int(graph['row_variable_count'])
            except Exception as error:
                record[name] = {'error': str(error)}
        frame = gdb.newest_frame()
        record['callers'] = []
        for _ in range(8):
            if frame is None: break
            record['callers'].append(frame.name())
            frame = frame.older()
        with (root/'graph-probe.jsonl').open('a') as output:
            output.write(json.dumps(record)+'\n')
        return False

probe = Probe('frontend_graph_correspondence.zig:53')
(root/'probe-attached').write_text('1')
while not (root/'probe-stop').exists():
    gdb.execute('continue', to_string=True)
gdb.execute('detach')
(root/'probe-detached').write_text('1')
