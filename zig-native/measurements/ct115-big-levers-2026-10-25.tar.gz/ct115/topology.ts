import { strict as assert } from "node:assert";
import { createZigProjectCompiler } from "../../../compiler/zig_project_client.ts";
import { editedSources, gdevWorkloads, sessionOptions } from "../../../scripts/bench/gdev.ts";
import { verifySnapshotFiles } from "../../../scripts/bench/snapshot.ts";

const root = Deno.cwd();
const out = `${root}/build/bench/ct115/topology`;
await Deno.mkdir(out, { recursive: true });
const snapshot = `${root}/build/bench/compile-cost-20261023/snapshot`;
const manifest = JSON.parse(await Deno.readTextFile(`${root}/build/bench/compile-cost-20261023/manifest.json`));
const pins = JSON.parse(await Deno.readTextFile(`${root}/build/bench/ct103/wasm.json`)).entries;
const [workload] = await gdevWorkloads(root, snapshot);
const executable = `${root}/build/bench/ct115/diagnostic-work/blot2/zig-native/zig-out-dev/bin/blotc`;
async function sha(bytes: Uint8Array) {
  return Array.from(new Uint8Array(await crypto.subtle.digest("SHA-256", bytes)), n => n.toString(16).padStart(2, "0")).join("");
}
const binaryHash = await sha(await Deno.readFile(executable));
await verifySnapshotFiles(snapshot, manifest);
const started = new Date().toISOString();
for (let run = 0; run < 1; run++) {
  const compiler = await createZigProjectCompiler({ ...sessionOptions(executable, workload), codegenWorkers: 4, cacheDirectory: false, profileBackend: true });
  try {
    for (const phase of ["fresh"]) {
      const scenario = workload.scenarios.find(s => s.name === phase);
      const sources = scenario ? await editedSources(workload, scenario) : {};
      const result = await compiler.build({ sources });
      assert(result.success, JSON.stringify(result.diagnostics));
      const hash = await sha(result.bytes);
      assert.equal(hash, pins[scenario ? `game @ ${phase}` : "game"]);
      const profile = result.stats.phaseProfile as Record<string, unknown>;
      assert.equal(profile.module_trace_overflow, 0);
      const trace = profile.module_trace as { truncated: boolean }[];
      assert(trace.every(row => !row.truncated));
      const sample = { run, phase, at: new Date().toISOString(), hash, stats: result.stats };
      await Deno.writeTextFile(`${out}/${run}-${phase}.json`, JSON.stringify(sample, null, 2) + "\n");
      console.log(run, phase, "checked modules", trace.length);
    }
  } finally { await compiler.dispose(); }
}
await verifySnapshotFiles(snapshot, manifest);
assert.equal(await sha(await Deno.readFile(executable)), binaryHash);
await Deno.writeTextFile(`${out}/complete.json`, JSON.stringify({ success: true, started_at: started, completed_at: new Date().toISOString(), compiler_sha256: binaryHash, samples: 1, inputs_unchanged: true, scope: "Safe/noLLVM topology probe only; its clocks are not release costs. Stable filename keys bridge module renumbering." }, null, 2) + "\n");
