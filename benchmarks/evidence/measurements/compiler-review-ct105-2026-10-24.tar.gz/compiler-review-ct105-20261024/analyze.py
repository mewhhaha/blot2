from pathlib import Path
import hashlib
import json
import statistics as st

root = Path('/home/mewhhaha/src/blot2')
out = root/'build/bench/compiler-review-ct105-20261024'
read = lambda p: [json.loads(line) for line in p.read_text().splitlines()]
samples = read(out/'phases/samples.jsonl')
result = {'scope': 'Same compiler; baseline=profiling off, candidate=profiling on.', 'phases': [], 'stacks': {}}
for workload in ('game', 'devtools'):
    for phase in dict.fromkeys(r['phase'] for r in samples if r['workload'] == workload):
        rows = [r for r in samples if r['workload'] == workload and r['phase'] == phase]
        a = [r for r in rows if r['variant'] == 'baseline']
        b = [r for r in rows if r['variant'] == 'candidate']
        row = {'workload': workload, 'phase': phase, 'n_per_mode': len(a)}
        for name, group in (('off', a), ('on', b)):
            row[name] = {k: st.median(r[k] for r in group) for k in ('wall_ms', 'cpu_ms', 'peak_rss_kib')}
        row['profile_cpu_ratio'] = row['on']['cpu_ms']/row['off']['cpu_ms'] if row['off']['cpu_ms'] else None
        profile = b[0]['stats']['phaseProfile']
        if profile:
            row['top_level_ms'] = {k: st.median(r['stats']['phaseProfile']['phases'][k]['us']/1000 for r in b) for k in profile['phases']}
        work = b[0]['stats']['backendTiming'].get('work', {})
        row['nested_ms'] = {k: st.median(r['stats']['backendTiming']['work'][k]/1000 for r in b) for k in work if k.endswith('_us')}
        row['assemble_ms'] = st.median(r['stats']['backendTiming']['assemble_us']/1000 for r in b)
        if 'inference_us' in work:
            row['profile_non_inference_ms'] = st.median((r['stats']['phaseProfile']['total_us']-r['stats']['backendTiming']['work']['inference_us'])/1000 for r in b)
        result['phases'].append(row)

expected = {r['phase']: r['wasm_sha256'] for r in samples if r['workload'] == 'game'}
labels = {'population':'population', 'cold build':'fresh', 'edit literal_in_body':'edit:literal_in_body', 'revert literal_in_body':'revert:literal_in_body', 'edit body_change':'edit:body_change', 'revert body_change':'revert:body_change'}
for scenario in ('fresh','literal','body'):
    p = out/f'stacks-{scenario}'
    for r in read(p/'builds.jsonl'):
        assert r['wasm_sha256'] == expected[labels[r['label']]], (scenario, r['label'])
    d = json.loads((p/'cpu-report.json').read_text())
    result['stacks'][scenario] = {k:d[k] for k in ('builds','complete_intervals','coverage_ratio','missing_stack_cpu_ms','truncated_stack_cpu_ms','compiler_directory','self','compiler_owner')}

memory = read(out/'memory-series.jsonl')
assert len(memory)==40 and json.loads((out/'memory-series-success.json').read_text())['success']
kib = lambda record, field: int(record['status'][field].split()[0])
summaries=[]
for row in memory:
    before, after = row['samples'][0],row['samples'][-1]
    threads={tid:max(0, value[0]-before['threads'].get(tid,[0])[0])/1e6 for tid,value in after['threads'].items()}
    summaries.append({'iteration':row['iteration'],'revision':row['revision'],'wall_ms':row['wall_ms'],'cpu_ms':row['cpu_ms'],'post_rss_mib':kib(after,'VmRSS')/1024,'lifetime_hwm_mib':kib(after,'VmHWM')/1024,'minor_faults':after['minor_faults']-before['minor_faults'],'major_faults':after['major_faults']-before['major_faults'],'swap_kib':kib(after,'VmSwap'),'dominant_live_thread_cpu_fraction':max(threads.values(),default=0)/row['cpu_ms'] if row['cpu_ms']>=100 else None,'runqueue_wait_ms':sum(max(0,v[1]-before['threads'].get(tid,[0,0])[1])/1e6 for tid,v in after['threads'].items())})
result['memory']={'scope':'Five cycles over eight fixed forms; seven distinct source texts including the original, which appears at revisions 0 and 7. This is not a distinct-query memory bound.','revisions':summaries,'cycles':[]}
for cycle in range(5):
    s=summaries[cycle*8:(cycle+1)*8]
    result['memory']['cycles'].append({'cycle':cycle+1,'post_rss_range_mib':[min(r['post_rss_mib'] for r in s),max(r['post_rss_mib'] for r in s)],'final_rss_mib':s[-1]['post_rss_mib'],'lifetime_hwm_mib':s[-1]['lifetime_hwm_mib'],'minor_faults':sum(r['minor_faults'] for r in s)})
pins=json.loads((out/'pins.json').read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
for path,digest in pins['source'].items(): assert sha(root/path)==digest,path
assert sha(Path(pins['compiler']))==pins['compiler_sha256']
assert sha(root/'zig-native/zig-out/bin/blotc')==pins['compiler_sha256']
result['verification']={'all_stack_outputs_match_strict_benchmark_pins':True,'memory_outputs_match_fresh_controls':True,'compiler_source_unchanged':True,'installed_and_release_binary_match':True}
probe=json.loads((out/'graph-probe-result.json').read_text())
assert probe['success'] and probe['wasm_sha256']==expected['edit:literal_in_body']
result['frontend_probe']={'graph_sizes':read(out/'graph-probe.jsonl'),'expected_output':True,'scope':'Graph-size guard only; this probe does not identify the exact declining branch.'}
assert len({r['wasm_sha256'] for r in memory})==7
(out/'analysis.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'verification':result['verification'],'cycles':result['memory']['cycles'],'literal_non_inference_ms':[r['profile_non_inference_ms'] for r in result['phases'] if r['workload']=='game' and r['phase']=='revert:literal_in_body']},indent=2))
