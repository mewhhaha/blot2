from pathlib import Path
import concurrent.futures,hashlib,json,os,subprocess,time
root=Path('/home/mewhhaha/src/blot2');base=root/'build/bench/ct97';out=base/'native-screen';out.mkdir(exist_ok=True)
names=[
'backend.structural_record_tests.test.typed paths keep unobserved generic accessors staged through allocation failure',
'reuse.retained_capture_tests.test.retained State callable backend every allocation failure preserves frozen Core and semantic types',
'backend.request_backend_tests.test.request backend frozen Core teardown and every allocation failure preserve owners and types']
sources={'baseline':root/'build/bench/ct96-20261023/blot2','candidate':base/'final-src'}
results=[]
for variant,source in sources.items():
 binary=source/'zig-native/zig-out-native-dev/bin/blot-tests'
 assert binary.is_file()
 def run(item):
  i,name=item;cmd=[str(binary),'--allocation-failures=full','--fail-fast','--test='+name];start=time.monotonic()
  with (out/f'{variant}-{i}.stdout.log').open('w') as stdout,(out/f'{variant}-{i}.stderr.log').open('w') as stderr:
   process=subprocess.Popen(cmd,cwd=source,stdout=stdout,stderr=stderr)
   _,status,usage=os.wait4(process.pid,0); process.returncode=os.waitstatus_to_exitcode(status)
  return dict(name=name,variant=variant,command=cmd,exit_code=process.returncode,wall_seconds=time.monotonic()-start,cpu_seconds=usage.ru_utime+usage.ru_stime,peak_rss_kib=usage.ru_maxrss)
 print('START native screen',variant,flush=True)
 with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool: rows=list(pool.map(run,enumerate(names)))
 assert all(r['exit_code']==0 for r in rows),rows
 results.append({'variant':variant,'source':str(source),'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'tests':rows})
 (out/'results.json').write_text(json.dumps({'purpose':'One bounded same-session screen, not a seven-pair speedup claim or a whole-gate comparison','parallel_tests':3,'rss_scope_note':'Raw wait4 max RSS includes pre-exec fork inheritance; parent binary hashing between variants confounds memory comparison. Do not compare these RSS values.','variants':results},indent=2)+'\n')
 print(json.dumps(results[-1]),flush=True)
