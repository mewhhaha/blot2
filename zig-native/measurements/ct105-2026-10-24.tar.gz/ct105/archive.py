from pathlib import Path
import hashlib,json,subprocess,shutil,tarfile,io
root=Path(__file__).resolve().parents[3];p=root/'build/bench/ct105';stage=root/'build/install/ct105'
assert json.loads((p/'release-checks-success.json').read_text())['success']
assert json.loads((stage/'installed.json').read_text())['native_matches_qualified_release']
sha=lambda b:hashlib.sha256(b).hexdigest()
(p/'source.patch').write_bytes(subprocess.check_output(['git','diff',json.loads((p/'final-pins.json').read_text())['base_commit'],'--','zig-native/src'],cwd=root))
for original,name in [(root/'build/bench/compile-cost-20261023/manifest.json','workload-manifest.json'),(root/'build/bench/ct103/wasm.json','prior-wasm-pins.json')]:shutil.copy2(original,p/name)
(p/'diagnostic-binaries.json').write_text(json.dumps({f.parent.name:sha(f.read_bytes()) for f in sorted(p.glob('release-*/blotc'))},indent=2)+'\n')
allowed={'.json','.jsonl','.log','.ts','.py','.md','.txt','.patch'}
files={}
for f in sorted(p.rglob('*')):
 if not f.is_file() or f.is_symlink() or f.suffix not in allowed or f.name=='WORK_STATE.md':continue
 parts=f.relative_to(p).parts
 if parts[0] in ['tools','baseline','__pycache__'] or (len(parts)>1 and parts[0].startswith('release-')) or any(x in ['cache','.cache','node_modules'] for x in parts):continue
 files['ct105/'+f.relative_to(p).as_posix()]=f.read_bytes()
for f in sorted(stage.iterdir()):
 if f.is_file() and f.suffix in allowed:files['install/'+f.name]=f.read_bytes()
for name in ['README.md','CONTINUE.md','COMPILE_HILLS.md','COMPILE_MEASUREMENTS.md','BUILD_HILLS.md','PERFORMANCE_REVIEW.md','FINISH_PLAN.md','DEVELOPMENT_TURNAROUND.md','zig-native/CT105_QUALIFICATION.md','zig-native/CONTRACT.md','zig-native/PROJECT_CLIENT.md','zig-native/README.md','zig-native/STATUS.md']:
 files['docs/'+name]=(root/name).read_bytes()
dev=root/'build/bench/check-dev/run-f10d8b9ddb39dbf9'
for f in sorted(dev.rglob('*')):
 if f.is_file() and f.suffix in allowed:files['development/'+f.relative_to(dev).as_posix()]=f.read_bytes()
for required in ['ct105/release-checks-success.json','ct105/final-pins.json','ct105/gate/timings.json','ct105/pmu-summary.json','install/installed.json','ct105/source.patch']:
 assert required in files,required
files['SHA256SUMS']=(''.join(sha(b)+'  '+name+'\n' for name,b in sorted(files.items()))).encode()
output=root/'zig-native/measurements/ct105-2026-10-24.tar.gz'
with tarfile.open(output,'w:gz',compresslevel=9) as tar:
 for name,b in sorted(files.items()):
  info=tarfile.TarInfo(name);info.size=len(b);info.mode=0o644;info.mtime=0;tar.addfile(info,io.BytesIO(b))
output.with_name(output.name+'.sha256').write_text(sha(output.read_bytes())+'  '+output.name+'\n')
with tarfile.open(output) as tar:
 for name,b in files.items():assert tar.extractfile(name).read()==b,name
print(json.dumps({'files':len(files),'bytes':output.stat().st_size,'sha256':sha(output.read_bytes())}))
