from pathlib import Path
import subprocess,time,json,hashlib,os
root=Path('/home/mewhhaha/src/blot2');out=root/'build/bench/compiler-review-ct105-20261024';work=root/'build/bench/compile-cost-20261023';binary=Path('/home/mewhhaha/.local/bin/blotc')
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
pins={'commit':subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),'compiler':str(binary),'compiler_sha256':sha(binary),'manifest_sha256':sha(work/'manifest.json'),'source':{str(p.relative_to(root)):sha(p) for p in sorted((root/'zig-native/src').rglob('*.zig'))},'scope':'diagnostic refresh on one unchanged release; baseline and candidate denote profiling off/on, not an optimization comparison'}
assert pins['compiler_sha256']=='0eadf4bb1a0cc7448f59156091a7287e2456aedfd4b31452197a0a3437a1da78'
(out/'pins.json').write_text(json.dumps(pins,indent=2)+'\n')
bench=['deno','task','bench:compile','--baseline',str(binary),'--candidate',str(binary),'--snapshot',str(work/'snapshot'),'--manifest',str(work/'manifest.json'),'--hashes',str(root/'build/bench/ct103/wasm.json'),'--workload','game,devtools','--runs','3','--scenarios','literal_in_body,body_change','--candidate-profile','--out',str(out/'phases')]
profile=['deno','task','profile:compile','--blotc',str(binary),'--snapshot',str(work/'snapshot'),'--manifest',str(work/'manifest.json'),'--verify-manifest','--runs','1','--reps','1','--min-ms','5','--max-ms','15','--top','50']
commands=[('phases',bench),('stacks-fresh',profile+['--out',str(out/'stacks-fresh')]),('stacks-literal',profile+['--edit','literal_in_body','--out',str(out/'stacks-literal')]),('stacks-body',profile+['--edit','body_change','--out',str(out/'stacks-body')])]
(out/'commands.json').write_text(json.dumps(commands,indent=2)+'\n');status=[]
for name,cmd in commands:
 assert sha(binary)==pins['compiler_sha256']
 print('START',name,flush=True);start=time.monotonic()
 with (out/(name+'.log')).open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 row={'name':name,'exit_code':r.returncode,'wall_seconds':time.monotonic()-start,'load':os.getloadavg()};status.append(row);(out/'status.json').write_text(json.dumps(status,indent=2)+'\n');print(json.dumps(row),flush=True)
 if r.returncode:raise SystemExit(r.returncode)
 if name.startswith('stacks'):
  with (out/(name+'-summary.log')).open('w') as log:r=subprocess.run(['python3','scripts/bench/summarize_stacks.py',str(out/name)],cwd=root,stdout=log,stderr=subprocess.STDOUT)
  if r.returncode:raise SystemExit(r.returncode)
assert sha(binary)==pins['compiler_sha256']

for name,digest in pins['source'].items():assert sha(root/name)==digest,name
(out/'complete.json').write_text(json.dumps({'success':True,'source_unchanged':True,'binary_unchanged':True})+'\n')
