import json,statistics
from pathlib import Path
base=Path('build/bench/ct106');names=['pmu-base-1','pmu-final-1','pmu-final-2','pmu-base-2','pmu-physical-1','pmu-smt-1','pmu-smt-2','pmu-physical-2'];out={}
for name in names:
 p=base/name
 if not (p/'complete.json').exists():continue
 rows=[]
 for line in (p/'samples.jsonl').read_text().splitlines():
  x=json.loads(line);events={}
  for c in x['counters']['counters']:
   e=events.setdefault(c['event'],{'raw':0,'scaled':0,'enabled_ns':0,'running_ns':0})
   assert c['raw']==0 or c['scaled'] is not None
   e['raw']+=c['raw'];e['scaled']+=c['scaled'] or 0;e['enabled_ns']+=c['time_enabled_ns'];e['running_ns']+=c['time_running_ns']
  for e in events.values():e['scheduled_ratio']=e['running_ns']/e['enabled_ns'] if e['enabled_ns'] else None
  stat=lambda s:s[s.rfind(')')+2:].split()
  a,b=stat(x['before_stat']),stat(x['after_stat'])
  cpu_ms=(int(b[11])+int(b[12])-int(a[11])-int(a[12]))*10
  rows.append({'phase':x['phase'],'wall_ms':x['wall_ms'],'cpu_ms':cpu_ms,'events':events,'instructions_per_cycle':events['instructions']['scaled']/events['cycles']['scaled'],'branch_miss_rate':events['branch_misses']['scaled']/events['branches']['scaled'],'generic_cache_miss_rate':events['cache_misses']['scaled']/events['cache_references']['scaled']})
 out[name]={'pins':json.loads((p/'pins.json').read_text()),'rows':rows}
comparison=[]
for old,new in [('pmu-base-1','pmu-final-1'),('pmu-base-2','pmu-final-2'),('pmu-physical-1','pmu-smt-1'),('pmu-physical-2','pmu-smt-2')]:
 if old not in out or new not in out:continue
 for a,b in zip(out[old]['rows'],out[new]['rows']):
  assert a['phase']==b['phase'];row={'baseline':old,'candidate':new,'phase':a['phase'],'wall_ratio':b['wall_ms']/a['wall_ms'],'cpu_ratio':b['cpu_ms']/a['cpu_ms'],'event_ratios':{k:b['events'][k]['scaled']/v['scaled'] for k,v in a['events'].items()}};comparison.append(row)
(base/'pmu-summary.json').write_text(json.dumps({'runs':out,'comparisons':comparison},indent=2)+'\n')
for key,group in [('compiler',[r for r in comparison if r['baseline'].startswith('pmu-base')]),('SMT set',[r for r in comparison if r['baseline'].startswith('pmu-physical')])]:
 for phase in ['fresh','literal_in_body','literal_revert','body_change','body_revert']:
  rows=[r for r in group if r['phase']==phase]
  if rows:print(key,phase,'instructions',round(statistics.median(r['event_ratios']['instructions'] for r in rows),4),'cycles',round(statistics.median(r['event_ratios']['cycles'] for r in rows),4),'CPU',round(statistics.median(r['cpu_ratio'] for r in rows),4),'wall',round(statistics.median(r['wall_ratio'] for r in rows),4))
