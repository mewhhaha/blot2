import hashlib,json
from pathlib import Path
root=Path('build/remaining-runtime'); out={}
metrics=['allocations','requested_bytes','retired_objects','copy_bytes','retains','releases','cycle_candidates','cycle_vertices','cycle_edges']
for scene in ['maxed-day-hitting','maxed-piles2000']:
 for side,stem in [('candidate','final-profile-memory-short'),('cycle_ablation','cycle-ablation-memory-short')]:
  p=root/f'{scene}-{stem}.json';d=json.loads(p.read_text());assert d['complete'] and d['status']==0 and not d['reconciliationErrors']
  active=[]
  for row in d['sites']:
   if not any(int(n) for n in row['counts'].values()):continue
   s=dict(row);source=Path(s['filename']);data=source.read_bytes();s['line']=data[:s['start']].count(b'\n')+1;s['column']=s['start']-data.rfind(b'\n',0,s['start']);s['source_sha256']=hashlib.sha256(data).hexdigest();s['source_blake3']=bytes(s['source_blake3']).hex() if s['source_blake3'] is not None else None
   marker='/architecture-slots/sources/';s['filename']=s['filename'].split(marker)[-1]
   s['counts']={k:v for k,v in s['counts'].items() if int(v)}
   for frame in s['inline_context']:frame['filename']=frame['filename'].split(marker)[-1]
   active.append(s)
  summary={k:v for k,v in d.items() if k!='sites'};summary.update(raw_report_sha256=hashlib.sha256(p.read_bytes()).hexdigest(),raw_site_count=len(d['sites']),active_sites=active,top_sites={metric:[{'site_id':s['id'],'filename':s['filename'],'line':s['line'],'value':s['counts'].get(metric,'0')} for s in sorted(active,key=lambda s:int(s['counts'].get(metric,'0')),reverse=True)[:12]] for metric in metrics},scope='Complete lifetime of a 20-frame diagnostic replay (4 warmup + 16 measured); totals include initialization, restore and teardown. Timing is not scored.')
  out[f'{scene}/{side}']=summary
(root/'gdev-memory-attribution.json').write_text(json.dumps(out,indent=2)+'\n')
print({k:{m:v['totals'][m] for m in ['allocations','requested_bytes','peak_live_bytes','copy_bytes','cycle_vertices','cycle_candidates']} for k,v in out.items()})
