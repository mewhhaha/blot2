import { chainGeneric } from '../../../scripts/bench/corpus.ts';
const root=Deno.cwd(), dir=root+'/build/bench/ct109/budget-probe';
await Deno.mkdir(dir,{recursive:true});
const input=dir+'/main.blot';await Deno.writeTextFile(input,chainGeneric(64).source);
for (const [variant,binary] of [['baseline','baseline-blotc'],['candidate','candidate-9-blotc']]) {
 for(const profile of [false,true]){
  const result=await new Deno.Command(root+'/build/bench/ct109/'+binary,{args:['build',input,dir+'/'+variant+'.wasm','--prelude',root+'/std/prelude.blot',...(profile?['--profile']:[])],stdout:'piped',stderr:'piped'}).output();
  await Deno.writeFile(dir+'/'+variant+(profile?'-profile':'')+'.jsonl',result.stdout);
  if(!result.success)throw Error(new TextDecoder().decode(result.stderr));
  const metrics=new TextDecoder().decode(result.stdout).trim().split('\n').map(x=>JSON.parse(x)).find(x=>x.kind==='compilation');
  console.log(variant,profile,metrics.memory,metrics.phase_profile);
 }
}
