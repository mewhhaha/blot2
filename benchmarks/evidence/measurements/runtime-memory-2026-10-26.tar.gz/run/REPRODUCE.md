# Reproduce the runtime memory batch

Use the repository revision containing `zig-native/RUNTIME_MEMORY_QUALIFICATION.md`
and Zig 0.17.0. Release measurements use `deno task build:compiler` (LLVM);
native correctness compilation uses Safe/noLLVM. The baseline is commit
`fdfaa899aa57ae80ab1b2a50b4eefcd995472a5f` and its original standard library.
Compiler and Wasm SHA-256 pins are in the report and JSON results.

Run the public comparison with:

```
deno run -A scripts/bench/runtime_boundaries.ts \
  --baseline /baseline/zig-native/zig-out/bin/blotc \
  --baseline-std /baseline/std \
  --candidate zig-native/zig-out/bin/blotc --output build/bench/runtime-memory
python scripts/bench/runtime_boundaries_wasmtime.py build/bench/runtime-memory
deno run -A scripts/bench/runtime_boundaries_browser.ts build/bench/runtime-memory
```

Wasmtime was 50.0.1, Firefox 157.0, and Deno 2.9.7/V8 15.0.245.2-rusty. The
archive's `kernels/` contains exact public Wasm and reference results, so the
Wasmtime and Firefox runners can also replay those bytes directly. Firefox
calibrates per-case batches to avoid zero-duration browser samples. Other
engines use 31 samples of five invocations. All calls check exact output and
zero outstanding roots/leases.

`run/cycle-ablation.patch` disables only the two acyclic-copy propagation steps.
Build that control with the same release settings; the test-only differences
are listed in `run/ablation-source-differences.json`. The reduction source and
exact three Wasm files are included. `run/measure-reduction.ts` records its
counter, memory and timing comparisons.

Application results require the separately pinned gdev capture, assets, saved
states and input tapes referenced in `application/*config.json`. Those project
sources/assets and large application Wasm are not redistributed here. The
compile results pin input files; runtime results pin Wasm, engine and every
frame/save witness. Adapt the absolute paths in the included runners/configs to
that capture. The application screen runs 600 warmup plus 600 measured frames,
three counterbalanced process rounds, without other compiler/test processes.
`os.wait4` records each Node process's CPU and peak RSS; guest wall time excludes
between-frame host work. Inspector CPU sampling is enabled identically on all
sides; guest bodies have no diagnostic instrumentation or external wasm-opt pass.

`run/gdev-memory-attribution.json.gz` retains every nonzero source row and its
source digests/coordinates from the 20-frame diagnostic replays. Zero rows are
omitted; all totals, unknown rows and helper categories remain. Per-source peaks
must not be summed. Public diagnostic reports are in `profiles/`; overhead is
measured separately. Original large diagnostic report hashes are retained.

The full gate ran with `--resume --oom-profile --native-shards 4
--budget-seconds 3600 --phase-seconds 3000`; exact commands, source fingerprints,
native inventory, four shard logs and release guest logs are in `gate/` and
`native/`. Every archived payload is listed in `manifest.json` with a verified
SHA-256. The native-only scheduler's `qualifies_release: false` is intentional:
release qualification also requires the successful LLVM build and guest phase,
recorded by the enclosing full gate.
