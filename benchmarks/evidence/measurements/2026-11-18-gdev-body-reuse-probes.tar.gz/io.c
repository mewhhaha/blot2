#include <inttypes.h>
#include <stdint.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <sys/stat.h>

static void packet_path(char *path, size_t size, uint32_t version, uint32_t unit) {
    const char *root=getenv(version == 0 ? "BLOT_BASE" : "BLOT_EDIT");
    if (!root || snprintf(path,size,"%s/%u-2.bin",root,unit)>=(int)size) abort();
}
int64_t body_packet_size(uint32_t version,uint32_t unit) {
    char path[4096]; struct stat st;
    packet_path(path,sizeof path,version,unit);
    if (stat(path,&st)) abort();
    return st.st_size;
}
void body_packet_read(uint32_t version,uint32_t unit,uint8_t *data,int64_t n) {
    char path[4096]; packet_path(path,sizeof path,version,unit);
    FILE *f=fopen(path,"rb");
    if (!f || fread(data,1,n,f)!=(size_t)n || fclose(f)) abort();
}
void body_stat(uint32_t metric,uint64_t value) {printf("%u %" PRIu64 "\n",metric,value);}
void body_save(uint32_t kind,const uint8_t *data,int64_t n) {
    const char *dir=getenv("BLOT_SAVE");
    if(!dir)return;
    char path[4096];snprintf(path,sizeof path,"%s/%u.wasm",dir,kind);
    FILE *f=fopen(path,"wb");
    if(!f || fwrite(data,1,n,f)!=(size_t)n || fclose(f))abort();
}
#include <stdbool.h>
static uint8_t inference[65536];
void body_remember_inference(uint32_t function) {if(function>=sizeof inference)abort();inference[function]=1;}
bool body_inferred(uint32_t function) {if(function>=sizeof inference)abort();return inference[function]!=0;}
// One edge for each scalar read, including reads in imported #run calls.
enum { unit_count=269, max_instances=65536, words=max_instances/64 };
struct Read {uint32_t unit,node,instance;};
static struct Read *reads;
static size_t count,capacity;
static uint8_t *changed[unit_count+1];
static uint32_t lengths[unit_count+1];
static uint64_t affected[words];
static bool sealed,unsupported;
static uint32_t current=UINT32_MAX;
uint32_t body_enter(uint32_t id){uint32_t old=current;current=id;return old;}
void body_leave(uint32_t parent){current=parent;}
void body_read(uint32_t unit,uint32_t node){
    if(sealed)return;
    if(unit>unit_count || (current!=UINT32_MAX && current>=max_instances))abort();
    if(count==capacity){
        capacity=capacity?2*capacity:4096;
        reads=realloc(reads,capacity*sizeof *reads);if(!reads)abort();
    }
    reads[count++]=(struct Read){unit,node,current};
}
void body_changed_node(uint32_t unit,uint32_t node,uint32_t length){
    if(unit>unit_count || node>=length)abort();
    if(!changed[unit]){changed[unit]=calloc(length,1);if(!changed[unit])abort();lengths[unit]=length;}
    changed[unit][node]=1;
}
void body_seal(void){
    sealed=true;
    for(size_t i=0;i<count;i++){
        struct Read r=reads[i];
        if(!changed[r.unit])continue;
        if(r.node>=lengths[r.unit])abort();
        if(!changed[r.unit][r.node])continue;
        if(r.instance==UINT32_MAX){unsupported=true;continue;}
        affected[r.instance/64]|=UINT64_C(1)<<(r.instance%64);
    }
    body_stat(16,count);body_stat(17,capacity*sizeof *reads);
}
bool body_decline(void){return unsupported;}
bool body_affected(uint32_t id){if(id>=max_instances)abort();return (affected[id/64]>>(id%64))&1;}
#include <unistd.h>
uint64_t body_rss(void){
    long pages=0;FILE *f=fopen("/proc/self/statm","r");
    if(!f || fscanf(f,"%*d %ld",&pages)!=1 || fclose(f))abort();
    return pages*(uint64_t)sysconf(_SC_PAGESIZE);
}
bool body_reference_first(void){return getenv("BLOT_REFERENCE_FIRST")!=NULL;}
uint32_t body_repetitions(void) {const char *value=getenv("BLOT_REPEAT");if(!value)return 0;return strtoul(value,NULL,10);}
void body_verify(uint32_t version,const uint8_t *data,int64_t n) {
    const char *name=getenv(version?"BLOT_EDIT_WASM":"BLOT_BASE_WASM");
    FILE *f=fopen(name,"rb");if(!f)abort();
    uint8_t buf[16384];size_t pos=0;
    while(pos<(size_t)n){
        size_t want=(size_t)n-pos;if(want>sizeof buf)want=sizeof buf;
        if(fread(buf,1,want,f)!=want || memcmp(data+pos,buf,want))abort();
        pos+=want;
    }
    if(fgetc(f)!=EOF || fclose(f))abort();
}

#include <sys/wait.h>
#include <errno.h>

static int response_fd;
static uint8_t *response;
static size_t response_size, response_capacity;
bool body_snapshot_test(void) {return getenv("BLOT_SNAPSHOT")!=NULL;}

static void transfer(int fd, uint8_t *buffer, size_t count, bool send) {
    while (count) {
        ssize_t n;
        if (send) n=write(fd,buffer,count);
        else n=read(fd,buffer,count);
        if(n<0 && errno==EINTR) continue;
        if(n<=0) abort();
        buffer+=n;
        count-=(size_t)n;
    }
}

// The caller forks before it changes any emitter state. The parent waits for
// a complete reply and the child exit before exposing its bytes to the test.
bool body_snapshot(void) {
    int fds[2];if(pipe(fds)<0)abort();
    pid_t pid=fork();if(pid<0)abort();
    if(pid==0){close(fds[0]);response_fd=fds[1];return true;}
    close(fds[1]);
    uint64_t size;transfer(fds[0],(uint8_t *)&size,sizeof size,false);
    if(size>128*1024*1024 || !size)abort();
    if(response_capacity<size){response=realloc(response,size);if(!response)abort();response_capacity=size;}
    transfer(fds[0],response,size,false);close(fds[0]);
    int status;while(waitpid(pid,&status,0)<0){if(errno!=EINTR)abort();}
    if(!WIFEXITED(status) || WEXITSTATUS(status)!=0)abort();
    response_size=size;return false;
}
void body_reply(const uint8_t *bytes,int64_t count) {
    uint64_t size=count;
    transfer(response_fd,(uint8_t *)&size,sizeof size,true);
    transfer(response_fd,(uint8_t *)bytes,size,true);
    close(response_fd);_exit(0);
}
void body_verify_reply(uint32_t version) {body_verify(version,response,response_size);}
