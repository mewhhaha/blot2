"""Build the edit comparison from the compiler's portable Core schema."""
from pathlib import Path
import json
import re


def write_guard(root, output):
    model = json.loads((root / "compiler-goose/tools/dependency-wire-model.json").read_text())
    types = {item["name"]: item for item in model["descriptors"]}
    out = ["namespace body_guard;", "import check.core;", "import support.option;"]
    visited = set()

    def function(name):
        return "same_" + re.sub(r"\W", "_", name)

    def emit(name):
        if name in visited:
            return
        visited.add(name)
        item = types[name]
        for child in item.get("children", []):
            emit(child)
        for _, child, _ in item.get("fields", []):
            emit(child)
        t = item["goose"]
        body = []
        kind = item["kind"]
        if name == "parse.ast.Span":
            body.append("return !exact || a==b;")
        elif kind == "struct":
            for _, child, field in item["fields"]:
                if (name, field) in {("check.core.RuntimeName", "point"),
                                     ("check.core.Projection", "diagnostic_point")}:
                    body.append(f"if exact && a.{field}!=b.{field} {{return false;}}")
                    continue
                check = f"!{function(child)}(a.{field},b.{field},exact)"
                if (name, field) == ("check.core.Node", "a"):
                    check = "(exact || a.tag!=blot_check_core::Tag.constant) && " + check
                body.append("if " + check + " {return false;}")
            body.append("return true;")
        elif kind in ("slice", "array"):
            child = item["children"][0]
            body.extend(["if a.len!=b.len {return false;}",
                         f"for i in 0..a.len {{if !{function(child)}(a[i],b[i],exact) {{return false;}}}}",
                         "return true;"])
        elif kind == "optional":
            body.append(f"return a.present==b.present && (!a.present || {function(item['children'][0])}(a.value,b.value,exact));")
        elif kind in ("primitive", "enum", "union"):
            # Core's two union payloads contain only scalars and identities.
            body.append("return a==b;")
        else:
            raise ValueError(item)
        out.append(f"fn {function(name)}(a:{t},b:{t},exact:bool)->bool {{\n    " + "\n    ".join(body) + "\n}")

    emit("check.core.Module")
    output.write_text("\n".join(out) + "\n")
