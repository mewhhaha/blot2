"""Archive compiler evidence without binaries, caches or private workload sources."""
from pathlib import Path
import gzip, hashlib, io, json, subprocess, tarfile

base = Path(__file__).resolve().parent
repo = base.parents[2]
payload = {}
sha = lambda data: hashlib.sha256(data).hexdigest()
suffixes = {'.json', '.jsonl', '.log', '.xml', '.txt', '.py', '.ts', '.patch', '.sha256'}

def redact(value):
    if isinstance(value, dict):
        if 'native_qualification' in value:
            for item in value['native_qualification'].values():
                if 'key' in item:
                    item['key_sha256'] = sha(item.pop('key').encode())
        for child in value.values():
            redact(child)
    elif isinstance(value, list):
        for child in value:
            redact(child)

def add(path, name):
    data = path.read_bytes()
    if path.suffix == '.json':
        value = json.loads(data)
        redact(value)
        data = (json.dumps(value, indent=2) + '\n').encode()
    payload[name] = data

for p in base.iterdir():
    if p.is_file() and p.suffix in suffixes and p.name not in {'archive-report.json', 'archive-report.log', 'WORK_STATE.md'}:
        add(p, 'ct102/' + p.name)
add(base / 'HYPOTHESIS.md', 'ct102/HYPOTHESIS.md')
for directory in ['cold', 'retained', 'phases', 'gate', 'reuse-profile']:
    for p in (base / directory).rglob('*'):
        if p.is_file() and p.suffix in suffixes:
            add(p, 'ct102/' + str(p.relative_to(base)))
for p in (base / 'candidate-src/build/bench/check-dev').rglob('*'):
    if p.is_file() and p.suffix in suffixes:
        add(p, 'ct102/' + str(p.relative_to(base)))
pins = json.loads((base / 'final-inputs.json').read_text())
for name, digest in pins['files'].items():
    p = base / 'candidate-src' / name
    assert sha(p.read_bytes()) == digest
    add(p, 'candidate-source/' + name)
for name in ['manifest.json', 'wasm.json', 'host.json']:
    add(repo / 'build/bench/compile-cost-20261023' / name, 'workload-pins/' + name)
for p in (repo / 'build/install/ct102').iterdir():
    if p.is_file() and p.suffix in suffixes:
        add(p, 'installation/' + p.name)
summary = json.loads((base / 'summary.json').read_text())
assert summary['qualification']['native'] == 2541
assert all(summary['targets'][k] for k in ['literal_gain', 'unaffected_game', 'unaffected_devtools', 'unaffected_body'])
assert json.loads((base / 'warm-series-success.json').read_text())['success']
assert json.loads((repo / 'build/install/ct102/installed.json').read_text())['native_matches_qualified_release']
payload['SHA256SUMS'] = ''.join(f'{sha(data)}  {name}\n' for name, data in sorted(payload.items())).encode()
archive = repo / 'zig-native/measurements/ct102-principal-replay-2026-10-24.tar.gz'
with archive.open('wb') as raw, gzip.GzipFile(fileobj=raw, mode='wb', filename='', mtime=0) as gz, tarfile.open(fileobj=gz, mode='w') as tar:
    for name, data in sorted(payload.items()):
        info = tarfile.TarInfo(name)
        info.size = len(data)
        info.mode = 0o644
        tar.addfile(info, io.BytesIO(data))
with tarfile.open(archive) as tar:
    for line in tar.extractfile('SHA256SUMS').read().decode().splitlines():
        digest, name = line.split('  ', 1)
        assert sha(tar.extractfile(name).read()) == digest, name
report = {'archive': str(archive.relative_to(repo)), 'bytes': archive.stat().st_size,
          'sha256': sha(archive.read_bytes()), 'files': len(payload)}
(base / 'archive-report.json').write_text(json.dumps(report, indent=2) + '\n')
print(json.dumps(report, indent=2))
