from pathlib import Path
import subprocess,shutil,json,hashlib
root=Path('/home/mewhhaha/src/blot2');stage=root/'build/install/ct105';bench=root/'build/bench/ct105'
assert json.loads((bench/'release-checks-success.json').read_text())['success']
pins=json.loads((bench/'final-pins.json').read_text())
assert hashlib.sha256((root/'zig-native/zig-out/bin/blotc').read_bytes()).hexdigest()==pins['candidate']['sha256']
shutil.copy2(root/'zig-native/zig-out/bin/blotc',stage/'blotc')
commands=[['deno','task','package:pack'],['deno','compile','--allow-read','--allow-write','--allow-run','--allow-env=HOME,XDG_CACHE_HOME,BPM_CACHE_DIR','--include','generated/wasm','--include','generated/compiler','--include','std','--include','compiler/guide.md','--output',str(stage/'blot'),'compiler/installed_cli.ts']]
for i,cmd in enumerate(commands):
 with (stage/f'package-{i}.log').open('w') as log:r=subprocess.run(cmd,cwd=root,stdout=log,stderr=subprocess.STDOUT)
 assert r.returncode==0,(cmd,r.returncode)
r=subprocess.run(['python3',str(stage/'smoke.py')],cwd=root)
raise SystemExit(r.returncode)
