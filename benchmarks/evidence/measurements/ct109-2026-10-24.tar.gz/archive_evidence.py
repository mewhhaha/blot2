from pathlib import Path
import hashlib, io, json, re, tarfile
root=Path('/home/mewhhaha/src/blot2');bench=root/'build/bench/ct109'
read=lambda p:json.loads(p.read_text())
assert read(bench/'final-pairs/results.json')['success']
assert read(bench/'review-pairs-final/results.json')['success']
assert read(bench/'review-execution.json')['success']
assert read(bench/'memory-final/complete.json')['success']
assert read(bench/'qualification-work/blot2/build/bench/ct109-final-gate-3/timings.json')['success']
files={}
def add(path, name):
 assert path.is_file(),path
 assert path.suffix not in ['.wasm'],path
 files[str(name)]=path
def directory(path,name):
 for f in sorted(path.rglob('*')):
  if f.is_file() and f.suffix in ['.json','.jsonl','.log','.txt','.xml','.py','.ts','.patch','.md'] and 'synthetic' not in f.relative_to(path).parts:
   add(f,Path(name)/f.relative_to(path))
for f in sorted(bench.iterdir()):
 if f.is_file() and (f.suffix in ['.json','.jsonl','.log','.txt','.py','.ts','.patch'] or f.name.endswith('-source.tar.gz') or f.name.endswith('-identity.bin')):add(f,f.name)
for name in ['profile-1','profile-2','profile-3','profile-4','profile-5','profile-6','assets-4','row-ablation-pairs','composite-ablation-pairs','hot-cache-pairs','quantified-5','quantified-5-staged','quantified-5-lexical','final-pairs','review-pairs-final','memory-final','budget-probe']:
 directory(bench/name,name)
for name in ['ct109-final-gate','ct109-final-gate-2','ct109-final-gate-3']:
 directory(bench/'qualification-work/blot2/build/bench'/name,Path('qualification')/name)
for log in bench.glob('dev-*.log'):
 for result in re.findall(r'Report: (\S+/results.json)',log.read_text()):
  path=Path(result).parent
  if path.exists():directory(path,Path('development')/path.name)
add(bench/'qualification-work/frozen-fixtures.json','frozen-fixtures.json')
for name in ['asset_reply.ts','costs.ts','review_corpus.ts']:
 add(root/'scripts/bench'/name,Path('tools')/name)
directory(root/'build/install/ct109','installation')
# Native binaries, private workloads, synthetic source/output trees and caches
# are excluded. Archived compiler sources are public repository inputs only.
manifest=''.join(f'{hashlib.sha256(p.read_bytes()).hexdigest()}  {n}\n' for n,p in sorted(files.items())).encode()
archive=root/'zig-native/measurements/ct109-2026-10-24.tar.gz'
with tarfile.open(archive,'x:gz',compresslevel=6) as t:
 for name,p in sorted(files.items()):t.add(p,arcname=name,recursive=False)
 info=tarfile.TarInfo('SHA256SUMS');info.size=len(manifest);t.addfile(info,io.BytesIO(manifest))
sha=hashlib.sha256(archive.read_bytes()).hexdigest()
archive.with_suffix(archive.suffix+'.sha256').write_text(f'{sha}  {archive.name}\n')
print(json.dumps({'archive':str(archive),'sha256':sha,'files':len(files),'bytes':archive.stat().st_size},indent=2))
