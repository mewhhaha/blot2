from pathlib import Path
import json,statistics as st,hashlib,re,xml.etree.ElementTree as ET
base=Path(__file__).resolve().parent
read=lambda p:json.loads(p.read_text())
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
result={}
for group in ['cold','retained','phases']:
 report=read(base/group/'results.json');assert report['success'] and report['inputs_unchanged'] and not report['unexpected_problems'],group
 rows=[json.loads(s) for s in (base/group/'samples.jsonl').read_text().splitlines()]
 summary={}
 for workload,phase in sorted({(s['workload'],s['phase']) for s in rows}):
  selected=[s for s in rows if s['workload']==workload and s['phase']==phase]
  pairs=[{s['variant']:s for s in selected if s['run']==i} for i in sorted({s['run'] for s in selected})]
  assert all(set(p)=={'baseline','candidate'} for p in pairs)
  ratios=[p['candidate']['cpu_ms']/p['baseline']['cpu_ms'] for p in pairs if p['baseline']['cpu_ms']>0]
  entry={'pairs':len(pairs),'paired_cpu_ratios':ratios,'paired_cpu_ratio_median':st.median(ratios) if ratios else None}
  for variant in ['baseline','candidate']:
   samples=[p[variant] for p in pairs]
   entry[variant]={k:{'median':st.median([r[k] for r in samples]),'min':min(r[k] for r in samples),'max':max(r[k] for r in samples)} for k in ['cpu_ms','wall_ms','peak_rss_kib']}
   entry[variant]['backend']=samples[-1]['stats']['backend'];entry[variant]['principals']=samples[-1]['stats']['principals']
   if group=='phases' and 'work' in samples[-1]['stats']['backendTiming']:
    entry[variant]['work_us']={k:st.median([r['stats']['backendTiming']['work'][k] for r in samples]) for k,v in samples[-1]['stats']['backendTiming']['work'].items() if isinstance(v,(int,float))}
    entry[variant]['phases']=samples[-1]['stats']['phaseProfile']['phases'];entry[variant]['regions']=samples[-1]['stats']['backendTiming']['work']['regions']
  summary[workload+'/'+phase]=entry
 result[group]=summary
cold=result['cold'];retained=result['retained']
result['targets']={'literal_gain':retained['game/edit:literal_in_body']['paired_cpu_ratio_median']<=.90,'unaffected_game':cold['game/fresh']['paired_cpu_ratio_median']<=1.05,'unaffected_devtools':cold['devtools/fresh']['paired_cpu_ratio_median']<=1.05,'unaffected_body':retained['game/edit:body_change']['paired_cpu_ratio_median']<=1.05,'under_one_second':all(retained['game/edit:'+s]['candidate']['wall_ms']['median']<1000 for s in ['literal_in_body','body_change'])}
if (base/'gate/timings.json').exists() and read(base/'gate/timings.json')['success'] and not read(base/'gate/timings.json')['active']:
 gate=read(base/'gate/timings.json');native=read(base/'gate/native-execution/results.json')
 assert gate['success'] and not gate['active'] and native['success'] and native['allocation_failures']=='full'
 pmap={p['name']:p for p in gate['phases']};assert all(p['code']==0 for p in pmap.values())
 nrun=Path(next(p for p in native['artifacts'] if p.endswith('inventory.stdout.log'))).parent
 laws=[json.loads(l.split('\t',1)[1]) for p in nrun.glob('shard-*.stderr.log') for l in p.read_text().splitlines() if l.startswith('BLOT_NATIVE_TEST\t')]
 assert len(laws)==len({r['name'] for r in laws})==2541
 assert all(r['status']=='passed' and r['allocation_failures']=='full' and not r['leaks'] and not r['logged_errors'] for r in laws)
 def cases(name):
  rows=list(ET.parse(Path(pmap[name]['stdout']).parent/(name+'.junit.xml')).iter('testcase'));assert rows and all(all(c.find(k) is None for k in ['failure','error','skipped']) for c in rows);return len(rows)
 result['qualification']={'native':len(laws),'guests':cases('guests'),'smoke':cases('smoke'),'harness':int(re.findall(r'ok \| (\d+) passed \| 0 failed',Path(pmap['harness']['stdout']).read_text())[-1]),'wall_seconds':gate['wall_seconds'],'phases':{n:p['wall_seconds'] for n,p in pmap.items()},'top_native':sorted(laws,key=lambda r:r['duration_ns'],reverse=True)[:10]}
for name,h in read(base/'final-inputs.json')['files'].items():assert sha(base/'candidate-src'/name)==h,name
result['pins']=read(base/'binaries.json');result['runs']=read(base/'status.json')
(base/'summary.json').write_text(json.dumps(result,indent=2)+'\n')
print(json.dumps({'targets':result['targets'],'qualification':result.get('qualification')},indent=2))
