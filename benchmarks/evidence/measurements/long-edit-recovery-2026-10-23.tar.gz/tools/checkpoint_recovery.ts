import { strict as assert } from "node:assert";
import { createZigProjectCompiler } from "/workspace/.numeric-tuning/compiler/zig_project_client.ts";
import { gdevWorkloads, editedSources, sessionOptions } from "/workspace/.numeric-tuning/scripts/bench/gdev.ts";
const root='/workspace/.numeric-tuning';const source=`${root}/build/bench/long-edits-final`;const out=`${root}/build/bench/long-checkpoint-recovery`;await Deno.mkdir(out);
const report=JSON.parse(await Deno.readTextFile(`${source}/report.json`));const original=report.rows.find((x:any)=>x.label==='population').wasm_sha256;const changed=report.rows.find((x:any)=>x.label==='edit:1').wasm_sha256;
const [workload]=await gdevWorkloads(root,'/workspace/.finish-integration/build/bench/gdev-current');const scenario=workload.scenarios.find(x=>x.name==='literal_constant');assert(scenario);const edited=await editedSources(workload,scenario);
const sha=async(bytes:Uint8Array<ArrayBuffer>)=>[...new Uint8Array(await crypto.subtle.digest('SHA-256',bytes))].map(x=>x.toString(16).padStart(2,'0')).join('');
async function copy(from:string,to:string):Promise<string[]>{await Deno.mkdir(to);const files=[];for await(const e of Deno.readDir(from)){const a=`${from}/${e.name}`,b=`${to}/${e.name}`;if(e.isDirectory)files.push(...await copy(a,b));else if(e.isFile){await Deno.copyFile(a,b);files.push(b);}}return files;}
const checks=[];
for(const extension of ['none','.blotcache','.blotseed','.blotout']){
 const directory=`${out}/${extension.replace('.','')}`;const files=await copy(`${source}/checkpoint`,directory);
 let corrupted:unknown=null;
 if(extension!=='none'){const path=files.find(x=>x.endsWith(extension));assert(path);const bytes=await Deno.readFile(path);const before=await sha(bytes);bytes[Math.floor(bytes.length/2)]^=1;await Deno.writeFile(path,bytes);corrupted={path,before,after:await sha(bytes)};}
 const compiler=await createZigProjectCompiler({...sessionOptions(report.options.executable,workload),cacheDirectory:directory,codegenWorkers:1,semanticWorkers:1});
 const rows=[];
 try{for(const [label,input,expected] of [['restart',{},original],['edit',edited,changed],['revert',{},original]] as const){const started=performance.now();const result=await compiler.build({sources:{...workload.overlay,...input}});assert(result.success,JSON.stringify(result));const hash=await sha(result.bytes);assert.equal(hash,expected);rows.push({label,wasm_sha256:hash,wall_ms:performance.now()-started,stats:result.stats});}}finally{await compiler.dispose();}
 if(extension==='none')assert.equal(rows[0].stats.restartCacheLoaded,true);
 checks.push({extension,corrupted,rows});await Deno.writeTextFile(`${out}/report.json`,JSON.stringify({source:`${source}/report.json`,checks},null,2)+'\n');console.log(`${extension}: restart/edit/revert hashes passed`);
}
