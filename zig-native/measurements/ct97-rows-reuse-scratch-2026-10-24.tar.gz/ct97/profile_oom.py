import concurrent.futures, hashlib, json, pathlib, subprocess, time
root=pathlib.Path('/home/mewhhaha/src/blot2')
source=root/'build/bench/ct97/candidate-src'
binary=source/'zig-native/zig-out-native-profile/bin/blot-tests'
out=root/'build/bench/ct97/prefix-oom'
names=[
'backend.structural_record_tests.test.typed paths keep unobserved generic accessors staged through allocation failure',
'reuse.retained_capture_tests.test.retained State callable backend every allocation failure preserves frozen Core and semantic types',
'backend.request_backend_tests.test.request backend frozen Core teardown and every allocation failure preserve owners and types',
]
meta={'compiler_commit':'d98e84c plus row-prefix candidate','source':'isolated row-prefix candidate','zig_version':subprocess.check_output(['zig','version'],text=True).strip(),'build_command':['zig','build','test-compile','-Doptimize=safe','-Dllvm=false','-Doom-profile=true','--prefix','zig-out-native-profile','--summary','all'],'binary_sha256':hashlib.sha256(binary.read_bytes()).hexdigest(),'parallel_tests':3,'purpose':'diagnostic sweep attribution, not a paired throughput comparison'}
def run(item):
 i,name=item;cmd=[str(binary),'--allocation-failures=full','--fail-fast','--test='+name]
 start=time.monotonic()
 with (out/f'test-{i}.stdout.log').open('w') as stdout,(out/f'test-{i}.stderr.log').open('w') as stderr:
  p=subprocess.run(cmd,cwd=source,stdout=stdout,stderr=stderr)
 result={'name':name,'exit_code':p.returncode,'wall_seconds':time.monotonic()-start,'stdout':f'test-{i}.stdout.log','stderr':f'test-{i}.stderr.log','arguments':cmd[1:]}
 print(json.dumps(result),flush=True);return result
with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:meta['tests']=list(pool.map(run,enumerate(names)))
(out/'metadata.json').write_text(json.dumps(meta,indent=2)+'\n')
assert all(t['exit_code']==0 for t in meta['tests'])
