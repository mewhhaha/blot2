from pathlib import Path
import shutil,json,subprocess,os
import sys
d=Path(sys.argv[1] if len(sys.argv)>1 else 'build/resolve-hill').resolve();d.mkdir(parents=True,exist_ok=True);src=d/'probe-src';shutil.copytree('compiler-goose/src',src,dirs_exist_ok=True)
p=src/'check/types.goose';s=p.read_text();i=s.index('recursive fn resolveRoot(');s=s[:i]+'''extern fn probeVisit(stage:u32,owner:u64,root:u32,at:u32,depth:i64,mutation:u64,effects:u64,clock:u32,physical:u64,generation:u16,limit:i64,is_variable:bool,closed:u8,projections:bool)="rh_visit";
'''+s[i:]
for idx,fn in enumerate(['resolveRoot','resolveDepth','resolveNode']):
 i=s.index('{',s.index('recursive fn '+fn+'('))+1
 depth='0' if idx==0 else 'depth'
 s=s[:i]+f'\n    probeVisit({idx},self_.owner_id,root,at,{depth},self_.mutation_epoch,self_.effects.mutation_epoch,cursor(self_),self_.effects.physical_epoch,self_.closed_generation,self_.resolution_depth_limit,node(self_,root).tag==Tag.variable,closedHeight(self_,root),self_.has_projections);'+s[i:]
p.write_text(s);p=src/'reuse/persistent_unit.goose';s=p.read_text().replace('    let error=self_.checkModule(unit);','    beginProbe();let error=self_.checkModule(unit);endProbe(unit);');p.write_text(s+'\nextern fn beginProbe()="rh_begin";\nextern fn endProbe(unit:u32)="rh_end";\n')
read=lambda n:json.load(open('compiler-goose/build/stages/'+n+'.json'))['command']
cmd=read('emit-program');cmd[cmd.index('-o')+1]=str(d/'probe.c.generated.c');cmd[cmd.index('--header')+1]=str(d/'probe.h');cmd[cmd.index('-O2')]='-O0';cmd[-1]=str(src/'main.goose')
with (d/'probe-build.log').open('w') as f:
 subprocess.run(cmd,stdout=f,stderr=f,check=True)
 cmd=read('compile-and-link-program');cmd[cmd.index('-O2')]='-O0';cmd[cmd.index(next(a for a in cmd if a.endswith('blot_goose.c')))]=str(d/'probe.c.generated.c');cmd.insert(-2,str(Path(__file__).resolve().parent/'probe.c'));cmd[-1]=str(d/'probe');subprocess.run(cmd,stdout=f,stderr=f,check=True)
w=d/'traced';w.write_text(f'#!/bin/sh\nexport BLOT_RESOLVE_TRACE={d}/keys.log\nexec {d}/probe "$@"\n');w.chmod(0o755)
with (d/'traced.json').open('w') as f:subprocess.run(['deno','run','-A','scripts/integration/build_gdev.ts','--compiler',w,'--timeout-ms','45000',d/'traced-wasm'],stdout=f,check=True)
